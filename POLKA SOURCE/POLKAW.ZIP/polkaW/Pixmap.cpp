/***************************************************************/
/*							                                   */
/*	       		Pixmap.cpp			                           */
/*							                                   */
/***************************************************************/
/*       Copyright 1997 Georgia Institute of Technology 
                     -- Roman S. Khramets                      */

#include "Pixmap.h"
#include "GC.h"

#define RED_MASK    0x000000ff
#define GREEN_MASK  0x0000ff00
#define BLUE_MASK   0x00ff0000


Pixmap XCreatePixmap( Window wnd,
					  int w,
					  int h ) {
	return new __Pixmap( wnd, w, h );
}


Pixmap XCreatePixmap( Drawable drawable,
					  int w,
					  int h ) {
	return new __Pixmap( drawable, w, h );
}


void XFreePixmap( Pixmap window ) {
	window->XFreePixmap();
	delete window;
}


Pixmap XCreatePixmapFromBitmapData( Drawable drawable,
								    char data[],
									unsigned int width,
									unsigned int height,
									unsigned long fg,
									unsigned long bg,
									unsigned int depth ) {
	Pixmap pm;
	BITMAPINFOHEADER *pbihFace;
	char *biMemory;
	unsigned char *biBits;
	LONG biSizeImage;
	int i;

	if( (pm = XCreatePixmap(drawable, width, height)) == NULL ) {
		return NULL;
	}

	if( (biMemory = new char[sizeof(BITMAPINFO)]) == NULL ) {
		XFreePixmap(pm);
		return NULL;
	}

	memset(biMemory, 0, sizeof(BITMAPINFO));

	biSizeImage = width * height * 3;
	if( (biBits = new unsigned char[biSizeImage]) == NULL ) {
		XFreePixmap(pm);
		delete biMemory;
		return NULL;
	}

	// put color bytes in reverse order: blue, green, red
	for( i = 0; i < biSizeImage; i += 3 ) {
		int j;
		int b;

		b = i / 3; // bit number
		j = b % 8; // bit number within the byte of the data array
		b = b / 8; // byte number within the data array
		if( ((unsigned char)data[b]) & (((unsigned char)0x01) << j) ) {
			biBits[i + 0] = unsigned char((fg & BLUE_MASK) >> 16);
			biBits[i + 1] = unsigned char((fg & GREEN_MASK) >> 8);
			biBits[i + 2] = unsigned char(fg & RED_MASK);
		} else {
			biBits[i + 0] = unsigned char((bg & BLUE_MASK) >> 16);
			biBits[i + 1] = unsigned char((bg & GREEN_MASK) >> 8);
			biBits[i + 2] = unsigned char(bg & RED_MASK);
		}
	}

	pbihFace = (BITMAPINFOHEADER *)biMemory;
	pbihFace->biSize  = sizeof(BITMAPINFOHEADER);
	pbihFace->biWidth = width;
	pbihFace->biHeight = -height; // origin - upper left corner
	pbihFace->biPlanes = 1;
	pbihFace->biBitCount = 24;
	pbihFace->biCompression = BI_RGB;
	pbihFace->biSizeImage = biSizeImage;
	pbihFace->biXPelsPerMeter = 0;
	pbihFace->biYPelsPerMeter = 0;
	pbihFace->biClrUsed = 0;
	pbihFace->biClrImportant = 0;
	POINT ptPreviousOrigin;

	SetStretchBltMode(pm->getDC(), STRETCH_HALFTONE);
	SetBrushOrgEx(pm->getDC(), 0, 0, &ptPreviousOrigin);
	StretchDIBits(pm->getDC(),
	              0, 0, width, height,
				  0, 0, width, height,
				  (LPVOID)biBits,
				  (BITMAPINFO *)biMemory,
				  DIB_RGB_COLORS,
				  SRCCOPY);

	delete biBits;
	delete biMemory;
	return pm;
}


__Pixmap::__Pixmap() {
	hBitmap = NULL;
	hdc     = NULL;
	nWidth  = 0;
	nHeight = 0;
}


__Pixmap::__Pixmap( Window wnd ) {
	createCompatiblePixmap( wnd->getWnd() );
}


__Pixmap::__Pixmap( HWND hwnd ) {
	createCompatiblePixmap( hwnd );
}


__Pixmap::__Pixmap( Window wnd,
			        int aWidth,
				    int aHeight ) {
	createCompatiblePixmap( wnd->getWnd(), aWidth, aHeight );
}


__Pixmap::__Pixmap( Drawable wnd,
				    int aWidth,
				    int aHeight ) {
	createCompatiblePixmap( wnd->getDC(), aWidth, aHeight, 0 );
}


__Pixmap::__Pixmap( HWND hwnd,
			        int aWidth,
				    int aHeight ) {
	createCompatiblePixmap( hwnd, aWidth, aWidth );
}


__Pixmap::~__Pixmap() {
	DeleteDC( hdc );
	DeleteObject( hBitmap );
	hBitmap = NULL;
	hdc     = NULL;
	nWidth  = 0;
	nHeight = 0;
}


void __Pixmap::XFreePixmap() {
	DeleteDC( hdc );
	DeleteObject( hBitmap );
	hBitmap = NULL;
    hdc     = NULL;
	nWidth  = 0;
    nHeight = 0;
}


void __Pixmap::createCompatiblePixmap( HWND hwnd ) {
	RECT clientRect;

    GetClientRect( hwnd, &clientRect );
	createCompatiblePixmap( hwnd,
		                    clientRect.right,
							clientRect.bottom );
}


void __Pixmap::createCompatiblePixmap( HWND hwnd,
									   int aWidth,
									   int aHeight ) {
	HDC wHdc;

 	nWidth  = aWidth;
	nHeight = aHeight;

	// get the device context of the
	// window
    wHdc = GetDC( hwnd );
	// create a memory device context
	// compatible wuth the window
	// device context
    hdc = CreateCompatibleDC( wHdc );
	// create a bitmap compatible with
	// the screen window (i.e., if the
	// window is rendered on a color
	// display, the bitmap will be rgb)
	hBitmap = CreateCompatibleBitmap( wHdc, nWidth, nHeight );
	// select the newly created bitmap into
	// the memory device context, all compatible
	// with the screen;
	// all the drawing on the bitmap
	// will be done using the memory
	// device context hdc
	SelectObject( hdc, hBitmap );
	ReleaseDC( hwnd, wHdc );

	SetBkMode( hdc, OPAQUE );
	SetPolyFillMode( hdc, WINDING );
}


void __Pixmap::createCompatiblePixmap( HDC wHdc,
									   int aWidth,
									   int aHeight,
									   int ) {
 	nWidth  = aWidth;
	nHeight = aHeight;

	// create a memory device context
	// compatible wuth the window
	// device context
    hdc = CreateCompatibleDC( wHdc );
	// create a bitmap compatible with
	// the screen window (i.e., if the
	// window is rendered on a color
	// display, the bitmap will be rgb)
	hBitmap = CreateCompatibleBitmap( wHdc, nWidth, nHeight );
	// select the newly created bitmap into
	// the memory device context, all compatible
	// with the screen;
	// all the drawing on the bitmap
	// will be done using the memory
	// device context hdc
	SelectObject( hdc, hBitmap );

	SetBkMode( hdc, OPAQUE );
	SetPolyFillMode( hdc, WINDING );
}
