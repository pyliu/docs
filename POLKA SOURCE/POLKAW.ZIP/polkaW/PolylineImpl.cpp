/***************************************************************/
/*							                                   */
/*	       		PolylineImpl.cpp	                           */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#include "PolylineImpl.h"
#include "View.h"
#include "Pixmap.h"


PolylineImpl::PolylineImpl(View *an, int v, double lx, double ly, int ve, 
               double vtx[], double vty[], COLOR c, double w, double s, 
               int a) 
               : AnimObjectImpl(an,v,lx,ly)
{
   int i;
   double fx,fy,bx,by;

   type = P_Polyline;
   vertices = ve;
   for (i=0; i<vertices-1; i++) {
       vx[i] = vtx[i];
       vy[i] = vty[i];
     }
   strcpy(colorname,c);
   color = load_color(colorname);
   width = w;
   style = s;
   arrow = a;
   if (arrow != 0)
      arrow_poly_direction(vertices,vx,vy,&fx,&fy,&bx,&by);
   if ((arrow == 1) || (arrow == 3))
      compute_arrow_off(fx,fy,&arrowf1x,&arrowf1y,&arrowf2x,&arrowf2y);
   if ((arrow == 2) || (arrow == 3))
      compute_arrow_off(bx,by,&arrowf3x,&arrowf3y,&arrowf4x,&arrowf4y);
   /* do arrows here */
}


PolylineImpl::PolylineImpl(const PolylineImpl& p) : AnimObjectImpl( p )
{
   vertices = p.vertices;
   for (int i=0; i<vertices-1; i++) {
       vx[i] = p.vx[i];
       vy[i] = p.vy[i];
     }
   strcpy(colorname,p.colorname);
   color = p.color;
   width = p.width;
   style = p.style;
   arrow = p.arrow;
   if ((arrow == 1) || (arrow == 3)) {
      arrowf1x = p.arrowf1x;
      arrowf1y = p.arrowf1y;
      arrowf2x = p.arrowf2x;
      arrowf2y = p.arrowf2y;
      }
   if ((arrow == 2) || (arrow == 3)) {
      arrowf3x = p.arrowf3x;
      arrowf3y = p.arrowf3y;
      arrowf4x = p.arrowf4x;
      arrowf4y = p.arrowf4y;
      }
}


PolylineImpl::~PolylineImpl()
{
   Erase();
}   


void 
PolylineImpl::GetValues(View* *vi, int *v, double *lx, double *ly, int *ve, 
                double vtx[], double vty[], COLOR c, 
                double *w, double *s, int *a)
{
   if (vi) *vi=view;
   if (v) *v=visibility;
   if (lx) *lx=locx;
   if (ly) *ly=locy;
   if (ve) *ve=vertices;
   for (int i=0; i<vertices; i++) {
       if (vtx) vtx[i] = vx[i];
       if (vty) vty[i] = vy[i];
   }
   if (c) strcpy(c,colorname);
   if (w) *w=width;
   if (s) *s=style;
   if (a) *a=arrow;
}


LocPtr
PolylineImpl::Where(PART p)
{
   double	   xmin,ymin,xmax,ymax;

   BoundBox(&xmin,&ymin,&xmax,&ymax);

   switch (p)
   {
      case PART_C :
	 return( new Loc((xmin + xmax)/2.0,(ymin + ymax)/2.0) );
      case PART_NW :
	 return( new Loc(xmin,ymax) );
      case PART_N :
	 return( new Loc((xmin+ xmax)/2.0,ymax) );
      case PART_NE :
	 return( new Loc(xmax,ymax) );
      case PART_E :
	 return( new Loc(xmax,(ymin + ymax)/2.0) );
      case PART_SE :
	 return( new Loc(xmax,ymin) );
      case PART_S :
	 return( new Loc((xmin + xmax)/2.0,ymin) );
      case PART_SW :
	 return( new Loc(xmin,ymin) );
      case PART_W :
	 return( new Loc(xmin,(ymin + ymax)/2.0) );
   }
   return( new Loc(0.0,0.0) );
}


void
PolylineImpl::BoundBox(double *lx, double *by, double *rx, double *ty)
{
   double x,y,xmin,xmax,ymin,ymax,tox,toy,ax0,ax1,ay0,ay1;
   int i;

   xmin = xmax = locx;
   ymin = ymax = locy;   /* Find the bounding box */
   for (i=0; i<(vertices - 1); ++i)
      { if ((x = (locx+vx[i])) > xmax) xmax = x;
	if ((x = (locx+vx[i])) < xmin) xmin = x;
	if ((y = (locy+vy[i])) > ymax) ymax = y;
	if ((y = (locy+vy[i])) < ymin) ymin = y;
      }
   *lx = xmin; *rx = xmax; *ty = ymax; *by = ymin;
   if ((arrow & 0x1) != 0)    // below is dumb, but it works
      {        // need to take arrows into account on boundbox
        tox = locx + vx[vertices-2];
        toy = locy + vy[vertices-2];
        ax0 = tox+arrowf1x;
        ax1 = tox+arrowf2x;
        if (ax0 < *lx) *lx = ax0;
        if (ax1 < *lx) *lx = ax1;
        if (ax0 > *rx) *rx = ax0;
        if (ax1 > *rx) *rx = ax1;
        ay0 = toy+arrowf1y;
        ay1 = toy+arrowf2y;
        if (ay0 < *by) *by = ay0;
        if (ay1 < *by) *by = ay1;
        if (ay0 > *ty) *ty = ay0;
        if (ay1 > *ty) *ty = ay1;
      }
   if ((arrow & 0x2) != 0)
      { 
        ax0 = locx+arrowf3x;
        ax1 = locx+arrowf4x;
        if (ax0 < *lx) *lx = ax0;
        if (ax1 < *lx) *lx = ax1;
        if (ax0 > *rx) *rx = ax0;
        if (ax1 > *rx) *rx = ax1;
        ay0 = locy+arrowf3y;
        ay1 = locy+arrowf4y;
        if (ay0 < *by) *by = ay0;
        if (ay1 < *by) *by = ay1;
        if (ay0 > *ty) *ty = ay0;
        if (ay1 > *ty) *ty = ay1;
      }
}


void
PolylineImpl::transSpecial(char *atype, double dx, double dy)
{
   int i,v,recompute=0;
   double fx,fy,bx,by;

   if (streql(atype,"FILL"))
      { width +=  dx;
	if (width < 0.0)
	   width = 0.0;
	else if (width > 1.0)
	   width = 1.0;
        style +=  dy;
	if (style < 0.0)
	   style = 0.0;
	else if (style > 1.0)
	   style = 1.0;
        DamageIt();
      }
   else if (streql(atype,"COLOR")) {
      color = get_pathcolor(dx,dy);
      DamageIt();
      }
   else if (streqln(atype,"RESIZE",6)) {
      if (('1' <= *(atype+6)) && (*(atype+6) <= '7')) {
         DamageIt();
         recompute = 1;
         v = (int) (*(atype+6) - '0');
         for (i=v-1; i<vertices-1; i++) {
            vx[i] += dx;
            vy[i] += dy;
            }
         DamageIt();
         }
      }      
   else if (streqln(atype,"GRAB",4)) {
      if (('1' <= *(atype+4)) && (*(atype+4) <= '7')) {
         DamageIt();
         recompute = 1;
         v = (int) (*(atype+4) - '1');
         vx[v] += dx;
         vy[v] += dy;
         DamageIt();
         }
      }      
   if (recompute) {
      if (arrow != 0)
         arrow_poly_direction(vertices,vx,vy,&fx,&fy,&bx,&by);
      if ((arrow == 1) || (arrow == 3))
         compute_arrow_off(fx,fy,&arrowf1x,&arrowf1y,&arrowf2x,&arrowf2y);
      if ((arrow == 2) || (arrow == 3))
         compute_arrow_off(bx,by,&arrowf3x,&arrowf3y,&arrowf4x,&arrowf4y);
      }
}

   
void
PolylineImpl::Draw()
{
   drawer(color);
}


void
PolylineImpl::Erase()
{
   drawer(view->GetBgColor());
}


void
PolylineImpl::drawer(COLORINDEX col)
{
   int i,ax0,ay0,ax1,ay1;
   double tx,ty;
   LINE_STYLE lstyle,old;
   XPoint pts[10];

   if (!visibility)
      return;

   pts[0].x = view->TO_PIX_X(locx);
   pts[0].y = view->TO_PIX_Y(locy);
   for (i=1; i<vertices; i++) {
      pts[i].x = view->TO_PIX_X(locx + vx[i-1]);
      pts[i].y = view->TO_PIX_Y(locy + vy[i-1]);
      }
   set_color(col);
   lstyle = get_linestyle(width,style);
   if (lstyle != SOLID)
      old = line_style(lstyle);
   XDrawLines(view->DrawWindow(),inq_gc(),pts,vertices,CoordModeOrigin);

   if ((arrow & 0x1) != 0)
      { tx = locx + vx[vertices-2];
        ty = locy + vy[vertices-2];
        ax0 = view->TO_PIX_X(tx+arrowf1x);
        ay0 = view->TO_PIX_Y(ty+arrowf1y);
        ax1 = view->TO_PIX_X(tx+arrowf2x);
        ay1 = view->TO_PIX_Y(ty+arrowf2y);
        XDrawLine(view->DrawWindow(),inq_gc(),
                            pts[vertices-1].x,pts[vertices-1].y,ax0,ay0);
        XDrawLine(view->DrawWindow(),inq_gc(),
                            pts[vertices-1].x,pts[vertices-1].y,ax1,ay1);
      }
   if ((arrow & 0x2) != 0)
      { 
        ax0 = view->TO_PIX_X(locx+arrowf3x);
        ay0 = view->TO_PIX_Y(locy+arrowf3y);
        ax1 = view->TO_PIX_X(locx+arrowf4x);
        ay1 = view->TO_PIX_Y(locy+arrowf4y);
        XDrawLine(view->DrawWindow(),inq_gc(),pts[0].x,pts[0].y,ax0,ay0);
        XDrawLine(view->DrawWindow(),inq_gc(),pts[0].x,pts[0].y,ax1,ay1);
      }

   if (lstyle != SOLID)
      line_style(old);
}
