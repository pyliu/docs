/***************************************************************/
/*							                                   */
/*	       		ViewWindowProc.cpp			                   */
/*							                                   */
/***************************************************************/
/*       Copyright 1997 Georgia Institute of Technology 
                     -- Roman S. Khramets                      */

#include <windows.h>

#include "window_sizes.h"
#include "Init.h"
#include "View.h"
#include "Pixmap.h"
#include "ViewWindow.h"

#define DRAWING_AREA_BYSPACE      3
#define ARROW_BUTTON_WIDTH        4
#define NON_ARROW_BUTTON_WIDTH    8
#define BUTTON_SPACING            0.5

#define PANL_ID                   0
#define PANR_ID                   1
#define PAND_ID                   2
#define PANU_ID                   3
#define ZOOMIN_ID                 4
#define ZOOMOUT_ID                5
#define DEBUG_ID                  6
#define REFRESH_ID                7
#define CLOSEB_ID                 8

// x and y sizes of the
// system fixed font: the font that
// will be used for buttons and
// static text
extern int cxChar, cyChar;

extern void resizeEH( Widget w );
extern void panlCB( Widget w );
extern void panrCB( Widget w );
extern void pandCB( Widget w );
extern void panuCB( Widget w );
extern void zoominCB( Widget w );
extern void zoomoutCB( Widget w );
extern void debugCB( Widget w );
extern void refreshCB( Widget w );
extern APP_CALLBACK AppCloseCB;


LRESULT CALLBACK ViewWindowProc (HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam) {
     RECT  rcClient ;
	 static char *botleftrowcolTitles[] = { "L", "R", "D", "U", "In", "Out" };
	 static char *botrightrowcolTitles[] = { "Debug", "Refresh", "Close" };
	 int          i;
	 int          j;
	 HWND         hwndCtl;
     LONG         wNotifyCode;
     LONG         wID;
	 ViewWindow  *vw;
	 View        *view;
	 Pixmap       pixmap;
	 DrawingArea *da;
	 HWND         hDrawingArea;

     switch( iMsg ) {
          case WM_CREATE :
               GetClientRect (hwnd, &rcClient) ;
			   vw = (ViewWindow *)((LPCREATESTRUCT)lParam)->
				   lpCreateParams;

			   for( i = 0; i < 6; i++ ) {
				   vw->botleftrowcol[i] = CreateWindow ("button",
							botleftrowcolTitles[i],
							WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON | WS_EX_STATICEDGE,
							cxChar * (1 + (BUTTON_SPACING + ARROW_BUTTON_WIDTH)*i),
							rcClient.bottom - DRAWING_AREA_BYSPACE*cyChar + (2.5/4.0)*cyChar,
							cxChar * ARROW_BUTTON_WIDTH,
							(7.0/4.0)*cyChar,
							hwnd,
							(HMENU) i,
							((LPCREATESTRUCT)lParam)->hInstance,
							(LPVOID)NULL) ;
			   }

			   for( j = 0; j < 3; j++ ) {
				   vw->botrightrowcol[j] = CreateWindow ("button",
							botrightrowcolTitles[j],
							WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON | WS_EX_STATICEDGE,
							rcClient.right - cxChar*(1 + BUTTON_SPACING*(2 - j) + (NON_ARROW_BUTTON_WIDTH)*(3 - j)),
							rcClient.bottom - DRAWING_AREA_BYSPACE*cyChar + (2.5/4.0)*cyChar,
							cxChar * NON_ARROW_BUTTON_WIDTH,
							(7.0/4.0)*cyChar,
							hwnd,
							(HMENU) (j + i),
							((LPCREATESTRUCT)lParam)->hInstance,
							(LPVOID)NULL) ;
			   }
			   
               hDrawingArea = CreateWindow ("DrawingArea",
				        NULL,
                        WS_CHILD | WS_VISIBLE | WS_BORDER,
                        0,
						0,
                        rcClient.right,
						rcClient.bottom - DRAWING_AREA_BYSPACE*cyChar,
                        hwnd,
						(HMENU) (i + j),
                        ((LPCREATESTRUCT)lParam)->hInstance,
						(LPVOID)NULL) ;

			   da = vw->getDrawingArea();
			   da->setWnd( hDrawingArea );

			   SetWindowLong( hwnd, GWL_USERDATA, (LONG)vw );
               return 0 ;

          case WM_SIZE :
               rcClient.left   = 0 ;
               rcClient.top    = 0 ;
               rcClient.right  = LOWORD (lParam) ;
               rcClient.bottom = HIWORD (lParam) ;

			   vw = (ViewWindow *)GetWindowLong( hwnd, GWL_USERDATA );
			   da = vw->getDrawingArea();

			   for( i = 0; i < 6; i++ ) {
				   MoveWindow( vw->botleftrowcol[i], 
							   cxChar * (1 + (BUTTON_SPACING + ARROW_BUTTON_WIDTH)*i),
							   rcClient.bottom - DRAWING_AREA_BYSPACE*cyChar + (2.5/4.0)*cyChar,
							   cxChar * ARROW_BUTTON_WIDTH,
							   (7.0/4.0)*cyChar,
							   TRUE );
			   }

			   for( j = 0; j < 3; j++ ) {
				   MoveWindow( vw->botrightrowcol[j], 
							   rcClient.right - cxChar*(1 + BUTTON_SPACING*(2 - j) + (NON_ARROW_BUTTON_WIDTH)*(3 - j)),
							   rcClient.bottom - DRAWING_AREA_BYSPACE*cyChar + (2.5/4.0)*cyChar,
							   cxChar * NON_ARROW_BUTTON_WIDTH,
							   (7.0/4.0)*cyChar,
							   TRUE );
			   }

			   MoveWindow( da->getWnd(),
			               rcClient.left, 
			               rcClient.top, 
			               rcClient.right,
			               rcClient.bottom - DRAWING_AREA_BYSPACE*cyChar,
			               TRUE );

			   resizeEH( vw );
               return 0 ;

		  case WM_PAINT:
			   vw = (ViewWindow *)GetWindowLong( hwnd, GWL_USERDATA );
			   refreshCB( vw );
		  break;

		  case WM_CLOSE:
			   vw = (ViewWindow *)GetWindowLong( hwnd, GWL_USERDATA );
			   AppCloseCB( vw );
			   return 0;

          case WM_COMMAND :
               hwndCtl = (HWND) lParam;      // handle of control 

		       wNotifyCode = HIWORD(wParam); // notification code 
               wID = LOWORD(wParam);         // item, control, or accelerator identifier 

			   switch( wID ) {
				   case PANL_ID:
					   vw = (ViewWindow *)GetWindowLong( hwnd, GWL_USERDATA );
					   panlCB( vw );
				   break;

				   case PANR_ID:
					   vw = (ViewWindow *)GetWindowLong( hwnd, GWL_USERDATA );
					   panrCB( vw );
				   break;

				   case PAND_ID:
					   vw = (ViewWindow *)GetWindowLong( hwnd, GWL_USERDATA );
					   pandCB( vw );
				   break;

				   case PANU_ID:
					   vw = (ViewWindow *)GetWindowLong( hwnd, GWL_USERDATA );
					   panuCB( vw );
				   break;

				   case ZOOMIN_ID:
					   vw = (ViewWindow *)GetWindowLong( hwnd, GWL_USERDATA );
					   zoominCB( vw );
				   break;

				   case ZOOMOUT_ID:
					   vw = (ViewWindow *)GetWindowLong( hwnd, GWL_USERDATA );
					   zoomoutCB( vw );
				   break;
				   
				   case DEBUG_ID:
					   vw = (ViewWindow *)GetWindowLong( hwnd, GWL_USERDATA );
					   debugCB( vw );
				   break;

				   case REFRESH_ID:
					   vw = (ViewWindow *)GetWindowLong( hwnd, GWL_USERDATA );
					   refreshCB( vw );
				   break;

			       case CLOSEB_ID:
					   vw = (ViewWindow *)GetWindowLong( hwnd, GWL_USERDATA );
					   AppCloseCB( vw );
					   vw->destroyWindow();
				   break;
			   }
               return 0;
     }

     return DefWindowProc (hwnd, iMsg, wParam, lParam) ;
}
