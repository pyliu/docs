/***************************************************************/
/*							                                   */
/*	       		TextShape.cpp		                           */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#include "polka_staticwindow.H"
#include "StaticView.h"


TextShape::TextShape(int px, int py, const char *st, const char *fname, 
                        const char *col)
{
   x = px;
   y = py;
   strcpy(str, st);
   if (fname) 
      fontid = load_font(fname); 
   else 
      fontid = inq_font(); 
   text_info(fontid,str,&xext,&yext,&xoff,&yoff);
   color = load_color(col);
}


void
TextShape::draw(/*Window win, int winheight, StaticView *sv*/)
{
//   FILL_STYLE oldfill;
//   int oldfont; 
//
//   set_color(color);
//   oldfont = set_font(fontid);
//   oldfill = fill_style(POLKA_FILL_SOLID);
//   XDrawString(_display,win,inq_gc(),x,winheight-y,str,strlen(str));
//   sv->AccumClip(x-xoff,y-yoff,x+xext,y+yext);
//   fill_style(oldfill);
//   set_font(oldfont);   
}
