/***************************************************************/
/*							                                   */
/*	       		SplineImpl.cpp		                           */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#include "SplineImpl.h"
#include "View.h"


SplineImpl::SplineImpl(View *a, int v, double lx, double ly, int ve, 
              double vtx[], double vty[], COLOR c, double w, double s) 
               : AnimObjectImpl(a,v,lx,ly)
{
   int i;

   type = P_Spline;
   vertices = ve;
   for (i=0; i<vertices-1; i++) {
       vx[i] = vtx[i];
       vy[i] = vty[i];
     }
   strcpy(colorname,c);
   color = load_color(colorname);
   width = w;
   style = s;
}


SplineImpl::SplineImpl(const SplineImpl& s) : AnimObjectImpl( s )
{
   vertices = s.vertices;
   for (int i=0; i<vertices-1; i++) {
       vx[i] = s.vx[i];
       vy[i] = s.vy[i];
     }
   strcpy(colorname,s.colorname);
   color = s.color;
   width = s.width;
   style = s.style;
}


SplineImpl::~SplineImpl()
{
   Erase();
}


void 
SplineImpl::GetValues(View* *vi, int *v, double *lx, double *ly, int *ve, 
                double vtx[], double vty[], COLOR c, double *w, double *s)
{
   if (vi) *vi=view;
   if (v) *v=visibility;
   if (lx) *lx=locx;
   if (ly) *ly=locy;
   if (ve) *ve=vertices;
   for (int i=0; i<vertices; i++) {
       if (vtx) vtx[i] = vx[i];
       if (vty) vty[i] = vy[i];
   }
   if (c) strcpy(c,colorname);
   if (w) *w=width;
   if (s) *s=style;
}	


LocPtr
SplineImpl::Where(PART p)
{
   double	   xmin,ymin,xmax,ymax;

   BoundBox(&xmin,&ymin,&xmax,&ymax);

   switch (p)
   {
      case PART_C :
	 return( new Loc((xmin + xmax)/2.0,(ymin + ymax)/2.0) );
      case PART_NW :
	 return( new Loc(xmin,ymax) );
      case PART_N :
	 return( new Loc((xmin+ xmax)/2.0,ymax) );
      case PART_NE :
	 return( new Loc(xmax,ymax) );
      case PART_E :
	 return( new Loc(xmax,(ymin + ymax)/2.0) );
      case PART_SE :
	 return( new Loc(xmax,ymin) );
      case PART_S :
	 return( new Loc((xmin + xmax)/2.0,ymin) );
      case PART_SW :
	 return( new Loc(xmin,ymin) );
      case PART_W :
	 return( new Loc(xmin,(ymin + ymax)/2.0) );
   }
   return( new Loc(0.0,0.0) );
}


void
SplineImpl::BoundBox(double *lx, double *by, double *rx, double *ty)
{
   double x,y,xmin,xmax,ymin,ymax;
   int i;

   xmin = xmax = locx;
   ymin = ymax = locy;   /* Find the bounding box */
   for (i=0; i<(vertices - 1); ++i)
      { if ((x = (locx+vx[i])) > xmax) xmax = x;
	if ((x = (locx+vx[i])) < xmin) xmin = x;
	if ((y = (locy+vy[i])) > ymax) ymax = y;
	if ((y = (locy+vy[i])) < ymin) ymin = y;
      }
   *lx = xmin; *rx = xmax; *ty = ymax; *by = ymin;
}


void
SplineImpl::transSpecial(char *atype, double dx, double dy)
{
   int i,v;

   if (streql(atype,"FILL"))
      { width +=  dx;
	if (width < 0.0)
	   width = 0.0;
	else if (width > 1.0)
	   width = 1.0;
        style +=  dy;
	if (style < 0.0)
	   style = 0.0;
	else if (style > 1.0)
	   style = 1.0;
        DamageIt();
      }
   else if (streql(atype,"COLOR")) {
      color = get_pathcolor(dx,dy);
      DamageIt();
      }
   else if (streqln(atype,"RESIZE",6)) {
      if (('1' <= *(atype+6)) && (*(atype+6) <= '7')) {
         DamageIt();
         v = (int) (*(atype+6) - '0');
         for (i=v-1; i<vertices-1; i++) {
            vx[i] += dx;
            vy[i] += dy;
            }
         DamageIt();
         }
      }      
   else if (streqln(atype,"GRAB",4)) {
      if (('1' <= *(atype+4)) && (*(atype+4) <= '7')) {
         DamageIt();
         v = (int) (*(atype+4) - '1');
         vx[v] += dx;
         vy[v] += dy;
         DamageIt();
         }
      }      
}

   
void
SplineImpl::Draw()
{
   drawer(color);
}


void
SplineImpl::Erase()
{
   drawer(view->GetBgColor());
}


void
SplineImpl::drawer(COLORINDEX col)
{
   int i,x[32],y[32];
   LINE_STYLE lstyle,old;

   if (!visibility)
      return;

   x[0] = view->TO_PIX_X(locx);
   y[0] = view->TO_PIX_Y(locy);
   for (i=1; i<vertices; i++) {
      x[i] = view->TO_PIX_X(locx + vx[i-1]);
      y[i] = view->TO_PIX_Y(locy + vy[i-1]);
      }
   set_color(col);
   lstyle = get_linestyle(width,style);
   if (lstyle != SOLID)
      old = line_style(lstyle);
   make_a_spline(vertices,x,y,view);
   if (lstyle != SOLID)
      line_style(old);
}
