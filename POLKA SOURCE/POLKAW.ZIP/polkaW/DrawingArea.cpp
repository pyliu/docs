/***************************************************************/
/*							                                   */
/*	       		DrawingArea.cpp                                */
/*							                                   */
/***************************************************************/
/*       Copyright 1997 Georgia Institute of Technology 
                     -- Roman S. Khramets                      */

#include "DrawingArea.h"


DrawingArea::DrawingArea() {
}


DrawingArea::~DrawingArea() {
}
