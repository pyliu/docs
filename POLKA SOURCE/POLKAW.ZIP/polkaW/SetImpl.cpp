/***************************************************************/
/*							                                   */
/*	       		SetImpl.cpp			                           */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#include "SetImpl.h"
#include "View.h"


SetImpl::SetImpl(View *vi) : AnimObjectImpl(vi, 1, 0.0, 0.0)
{
   type = P_Set;
}


LocPtr
SetImpl::Where(PART p)
{
   double	   lx,by,rx,ty;

   BoundBox(&lx,&by,&rx,&ty);

   switch (p)
   {
      case PART_C :
	 return( new Loc((lx + rx)/2.0,(by + ty)/2.0) );
      case PART_NW :
	 return( new Loc(lx,ty) );
      case PART_N :
	 return( new Loc((lx+ rx)/2.0,ty) );
      case PART_NE :
	 return( new Loc(rx,ty) );
      case PART_E :
	 return( new Loc(rx,(ty + by)/2.0) );
      case PART_SE :
	 return( new Loc(rx,by) );
      case PART_S :
	 return( new Loc((lx + rx)/2.0,by) );
      case PART_SW :
	 return( new Loc(lx,by) );
      case PART_W :
	 return( new Loc(lx,(by + ty)/2.0) );
   }
   return( new Loc(0.0,0.0) );
}


void 
SetImpl::BoundBox(double *lx, double *by, double *rx, double *ty)
{
   double plx,pby,prx,pty;
   Set *s;
   AOPtr objs;
   
   s = (Set *)wrapper;
   objs = s->Objs();
   if (!objs)
     { *lx = *by = *rx = *ty = 0.0;
         return;
     }
   objs->object->BoundBox(lx,by,rx,ty);
   
   for (AOPtr a = objs->next; a; a=a->next)
       { a->object->BoundBox(&plx,&pby,&prx,&pty);
         if (plx < *lx) *lx = plx;
         if (prx > *rx) *rx = prx;
         if (pby < *by) *by = pby;
         if (pty > *ty) *ty = pty;
     }
}


void
SetImpl::Draw()
{
   Set *s = (Set *) wrapper;
   for (AOPtr a=s->Objs(); a; a=a->next)
      a->object->Draw();
}


void
SetImpl::Erase()
{
   Set *s = (Set *) wrapper;
   for (AOPtr a=s->Objs(); a; a=a->next)
      a->object->Erase();
}
