/***************************************************************/
/*							                                   */
/*	       		RectangleImpl.cpp			                   */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#include "RectangleImpl.h"
#include "View.h"
#include "Pixmap.h"


RectangleImpl::RectangleImpl(View *a, int v, double lx, double ly, 
              double sx, double sy, COLOR c, double f) 
              : AnimObjectImpl(a,v,lx,ly)
{
   type = P_Rectangle;
   sizex = sx;
   if (sx < 0.0) {
      cerr << "Warning:  Rectangle with x_size less than 0.0" << endl;
      sizex = 0.0;
      }
   sizey = sy;
   if (sy < 0.0) {
      cerr << "Warning:  Rectangle with y_size less than 0.0" << endl;
      sizey = 0.0;
      }
   strcpy(colorname,c);
   color = load_color(colorname);
   fill = f;
}


RectangleImpl::RectangleImpl(const RectangleImpl& r) : AnimObjectImpl( r )
{
   sizex = r.sizex;
   sizey = r.sizey;
   strcpy(colorname,r.colorname);
   color = r.color;
   fill = r.fill;
}
  

RectangleImpl::~RectangleImpl()
{
   Erase();
}


void 
RectangleImpl::GetValues(View* *vi, int *v, double *lx, double *ly, 
          double *sx, double *sy, COLOR c, double *f)
{
   if (vi) *vi=view;
   if (v) *v=visibility;
   if (lx) *lx=locx;
   if (ly) *ly=locy;
   if (sx) *sx=sizex;
   if (sy) *sy=sizey;
   if (c) strcpy(c,colorname);
   if (f) *f=fill;
}


LocPtr
RectangleImpl::Where(PART p)
{
   double	   x0,y0,x1,y1;

   BoundBox(&x0,&y1,&x1,&y0);

   switch (p)
   {
      case PART_C :
	 return( new Loc((x0 + x1)/2.0,(y0 + y1)/2.0) );
      case PART_NW :
	 return( new Loc(x0,y0) );
      case PART_N :
	 return( new Loc((x0+ x1)/2.0,y0) );
      case PART_NE :
	 return( new Loc(x1,y0) );
      case PART_E :
	 return( new Loc(x1,(y0 + y1)/2.0) );
      case PART_SE :
	 return( new Loc(x1,y1) );
      case PART_S :
	 return( new Loc((x0 + x1)/2.0,y1) );
      case PART_SW :
	 return( new Loc(x0,y1) );
      case PART_W :
	 return( new Loc(x0,(y0 + y1)/2.0) );
   }
   return( new Loc(0.0,0.0) );
}


void
RectangleImpl::BoundBox(double *lx, double *by, double *rx, double *ty)
{
   *lx= locx;
   *rx= *lx + sizex;
   *by= locy;
   *ty= *by + sizey;
}


void
RectangleImpl::transSpecial(char *atype, double dx, double dy)
{
   if (streql(atype,"FILL"))
      { fill +=  dx;
	if (fill < 0.0)
	   fill = 0.0;
	else if (fill > 1.0)
	   fill = 1.0;
        DamageIt();
      }
   else if (streql(atype,"RESIZE"))
      { DamageIt();
        sizex += dx;
	sizey += dy;
	if (sizex < ZERO)
	   sizex = ZERO;
	if (sizey < ZERO)
	   sizey = ZERO;
        DamageIt();
      }
   else if (streql(atype,"COLOR")) {
      color = get_pathcolor(dx,dy);
      DamageIt();
      }
}

   
void
RectangleImpl::Draw()
{
   FILL_STYLE curfill;

   curfill = get_fillstyle(fill);
   drawer(color,curfill);
}


void
RectangleImpl::Erase()
{
   FILL_STYLE curfill;

   curfill = get_fillstyle(fill);
   if (curfill == POLKA_FILL_OUTLINE)
      drawer(view->GetBgColor(),POLKA_FILL_OUTLINE);
   else
      drawer(view->GetBgColor(),POLKA_FILL_SOLID);
}


void
RectangleImpl::drawer(COLORINDEX col, FILL_STYLE curfill)
{
   int x0,y0,xs,ys;
   FILL_STYLE oldfill;

   if (!visibility)
      return;

   x0 = view->TO_PIX_X(locx);
   y0 = view->TO_PIX_Y(locy);
   xs = view->SIZE_PIX_X(sizex);
   ys = view->SIZE_PIX_Y(sizey);

   set_color(col);
   if (curfill == POLKA_FILL_OUTLINE)
      {
        XDrawRectangle(view->DrawWindow(),inq_gc(),x0,y0-ys,xs,ys);
      }
   else
      {
        oldfill = fill_style(curfill);
        XFillRectangle(view->DrawWindow(),inq_gc(),x0,y0-ys,xs,ys);
        fill_style(oldfill);
      }
}
