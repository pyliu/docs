/***************************************************************/
/*							                                   */
/*	       		Action.cpp			                           */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#include "Action.h"

COLOR_MAPPER *_color_list=NULL;
COLOR_MAPPER *_string_list=NULL;

/* ********************************************************************
Action::Action(const char *t, int num, double x[], double y[])

Creates a Action object with given offsets.
******************************************************************** */

Action::Action(const char *t, int num, double x[], double y[])
{
   OFFSET_PTR offset;

   head = tail = NULL;
   count = 0;
   strcpy(type,t);
   if (num == 0)
      cerr << "Warning: Allocating Action with no offsets==>Useless"
           << endl;
   for (int i=0; i<num; ++i)
      { offset = new OFFSET;
	offset->dx = x[i];
	offset->dy = y[i];
	offset->prevo = tail;
	offset->nexto = NULL;
	if (head)
	   tail->nexto = offset;
	else
	   head = offset;
	tail = offset;
        count++;
      }
}


/* ********************************************************************
Action::Actionconst (char *t, const  char *c)

Create a path which will change an object to a given color or will
modify a text string.
******************************************************************** */

Action::Action(const char *t, const char *c)
{
   COLOR_MAPPER *cl,*gcc;
   static double colcounter = 0.002; // .000 and .001 for black and white
   static double strcounter = 0.001;

   if (strcmp(t,"COLOR") == 0) { 
      strcpy(type,t);   

      head = tail = new OFFSET;
      head->prevo = head->nexto = NULL;
      count = 1;
   
      for (cl=_color_list; cl; cl=cl->next)
          if (!strcmp(c,cl->name)) break;
   
      if (cl) // found it already in list
         head->dx = cl->pathval;
      else // start a new one
         {
           gcc = new(COLOR_MAPPER);
           strcpy(gcc->name,c);
           head->dx = gcc->pathval = colcounter;
           colcounter += .001;
           gcc->colornum = load_color(c);
           gcc->next = _color_list;
           _color_list = gcc;
         }
   
      head->dy = 0.0;
      }
   else if (strcmp(t,"ALTER") == 0) { // modify a text string
      strcpy(type,t);   

      head = tail = new OFFSET;
      head->prevo = head->nexto = NULL;
      count = 1;
   
      for (cl=_string_list; cl; cl=cl->next)
          if (!strcmp(c,cl->name)) break;
   
      if (cl) // found it already in list
         head->dx = cl->pathval;
      else // start a new one
         {
           gcc = new(COLOR_MAPPER);
           strcpy(gcc->name,c);
           head->dx = gcc->pathval = strcounter;
           strcounter += .001;
           gcc->next = _string_list;
           _string_list = gcc;
         }
   
      head->dy = 0.0;
      }
   else {
      strcpy(type,t);   

      head = tail = new OFFSET;
      head->prevo = head->nexto = NULL;
      count = 1;
      head->dx = head->dy = 0.0;
      }
}


/* ********************************************************************
Action::Action(const char *t, MOTION motion)

Create a path which cooresponds to one of the basic path types.
******************************************************************** */

Action::Action(const char *t, MOTION motion)
{
   int i,val;
   OFFSET_PTR offset;

   strcpy(type,t);
   head = tail = NULL;

   count = POLKA_ACTION_POINTS;
   if (motion == STRAIGHT)
      val = 0;
   else if (motion == CLOCKWISE)
      val = 1;
   else
      val = 2;
   for (i=0; i<POLKA_ACTION_POINTS; ++i) {
        offset = new OFFSET;
        offset->dx = Motions[val][i][0];
        offset->dy = Motions[val][i][1];
        offset->prevo = tail;
	offset->nexto = NULL;
	if (head)
	   tail->nexto = offset;
	else
	   head = offset;
	tail = offset;
        }
}


/* ********************************************************************
Action::Action(const char *t, int val)

Create a path which cooresponds which has a given number of null offsets
******************************************************************** */

Action::Action(const char *t, int val)
{
   int i;
   OFFSET_PTR offset;

   strcpy(type,t);
   head = tail = NULL;
   count = 0;

   if (val == 0)
      cerr << "Warning: Allocating Action with no offsets==>Useless"
           << endl;

   for (i=1; i<=val; ++i) {
       offset = new OFFSET;
       offset->dx = offset->dy = ZERO;
       offset->prevo = tail;
       offset->nexto = NULL;
       if (head)
          tail->nexto = offset;
       else
          head = offset;
       tail = offset;
       }
   count = val;
}


/* ********************************************************************
Action::Action(const char *t, Loc fmloc, Loc toloc, MOTION m)

Create a path of the given type that moves between the two locations.
******************************************************************** */

Action::Action(const char *t, LocPtr fmloc, LocPtr toloc, MOTION m)
{
   ActionPtr retAction;

   Action path = Action(t,m);

   retAction = path.Example(fmloc,toloc);

   head = retAction->head;
   tail = retAction->tail;
   count = retAction->count;
   strcpy(type,t);
   retAction->head = NULL;
   retAction->tail = NULL;
   delete retAction;
}


/* ********************************************************************
Action::Action(const char *t, Loc fmloc, Loc toloc, double dist)

Create a path that moves from the fmloc to the toloc, and that has
an offset every time the given distance has been covered.
******************************************************************** */

Action::Action(const char *t, LocPtr fmloc, LocPtr toloc, double dist)
{
   int	       steps,i;
   double   fromx,fromy,tox,toy,
	       dx,dy,totdist,ratio,
	       xstep,ystep,runx,runy;
   OFFSET_PTR offset;

   tox=toloc->XCoord();
   toy=toloc->YCoord();
   fromx=fmloc->XCoord();
   fromy=fmloc->YCoord();

   dx = tox-fromx;
   dy = toy-fromy;

   totdist = sqrt( (dx*dx) + (dy*dy) );

   ratio = dist / totdist;

   steps = (int) (1.0 / ratio);

   xstep = dx * ratio;
   ystep = dy * ratio;
   runx = fromx;
   runy = fromy;

   head = tail = NULL;
   count = 0;

   for (i=1; i<=steps; ++i) {
        offset = new OFFSET;
	offset->dx = xstep;
	offset->dy = ystep;
	if (!head)
	   head = offset;
	else
	   tail->nexto = offset;
	offset->prevo = tail;
	offset->nexto = NULL;
	tail = offset;
	++count;

        runx += xstep;
        runy += ystep;
      }

   if (!_EQUAL(runx,dx) || !_EQUAL(runy,dy) || (steps == 0))
      { offset = new OFFSET;
	offset->dx = tox - runx;
	offset->dy = toy - runy;
	if (!head)
	   head = offset;
	else
	   tail->nexto = offset;
	offset->prevo = tail;
	offset->nexto = NULL;
	tail = offset;
	++count;
      }
   strcpy(type,t);
}


/* ********************************************************************
Action::Action(const char *t, Loc fmloc, Loc toloc, int steps)

Create a path that moves from the fmloc to the toloc in a straight 
line, and that has the given number of offsets
******************************************************************** */

Action::Action(const char *t, LocPtr fmloc, LocPtr toloc, int steps)
{
   int	    i;
   double   fromx,fromy,tox,toy,
            xstep,ystep;
   OFFSET_PTR offset;

   head = tail = NULL;
   count = 0;
   strcpy(type,t);

   if (steps == 0)
      cerr << "Warning: Allocating Action with no offsets==>Useless"
           << endl;

   if (steps > 0) {
      tox=toloc->XCoord();
      toy=toloc->YCoord();
      fromx=fmloc->XCoord();
      fromy=fmloc->YCoord();
   
      xstep = (tox-fromx)/double(steps);
      ystep = (toy-fromy)/double(steps);
   
      for (i=1; i<=steps; ++i) {
           offset = new OFFSET;
           offset->dx = xstep;
           offset->dy = ystep;
           if (!head)
              head = offset;
           else
              tail->nexto = offset;
           offset->prevo = tail;
           offset->nexto = NULL;
           tail = offset;
           ++count;
           }
       }
}


/* ********************************************************************
Action::~Action()

Destructor for Action.  It deallocates the memory used by the offset list.
******************************************************************** */

Action::~Action()
{
   OFFSET_PTR offset=head, prev;

   while (offset) {
      prev = offset;
      offset = offset->nexto;
      delete prev;
   }
}

/* ********************************************************************
Action::AddOffsetAtEnd(double x, double y)

Adds the offset (x,y) to the end of the path.
******************************************************************** */

void
Action::AddOffsetAtEnd(double x, double y)
{
   count++;
   OFFSET_PTR offset = new OFFSET;
   offset->dx = x;
   offset->dy = y;
   offset->nexto = NULL;
   offset->prevo = tail;
   if (head)
      tail->nexto = offset;
   else
      head = offset;
   tail = offset;
}

/* ********************************************************************
Action::DeleteOffsetFromFront()

Deletes an offset (x,y) from the front of the path.
******************************************************************** */

void
Action::DeleteOffsetFromFront()
{
   OFFSET_PTR offset = head;
   if (head) {
      count--;
      head = head->nexto;
      if (!head) 
         tail=NULL;
      else
         head->prevo = NULL;
      delete offset;
      }
}

/* ********************************************************************
Action::DeleteOffsetFromEnd()

Deletes one offset (x,y) from the end of the path.
******************************************************************** */

void
Action::DeleteOffsetFromEnd()
{
   OFFSET_PTR offset = tail;
   if (tail) {
      count--;
      tail = tail->prevo;
      if (!tail) 
         head=tail;
      else
         tail->nexto = NULL;
      delete offset;
      }
}


/* ********************************************************************
Action::Print()

Print the path to standard output.
******************************************************************** */

void
Action::Print()
{
  OFFSET_PTR off;

   cout << type << "\n";
   for (off=head;off;off=off->nexto)
      cout << off->dx << " " << off->dy << "\n";
   cout << flush;
}


/* ********************************************************************
Action::Deltax()

Returns the x distance the path covers.
******************************************************************** */

double
Action::Deltax()
{
   OFFSET_PTR offset;
   double dx = 0.0;

   for (offset=head; offset; offset=offset->nexto)
      dx += offset->dx;

   return( dx );
}


/* ********************************************************************
Action::Deltay()

Returns the y distance the path covers.
******************************************************************** */

double
Action::Deltay()
{
   OFFSET_PTR offset;
   double dy = 0.0;

   for (offset=head; offset; offset=offset->nexto)
      dy += offset->dy;

   return( dy );
}


/* ********************************************************************
Action::AddHead(int num)

Return a path which has the given number of null offsets added to the
head of the given path.
******************************************************************** */

ActionPtr
Action::AddHead(int num)
{
   OFFSET_PTR offset,h,t;
   ActionPtr ret = Copy();

   if (num <= 0) return( ret );
   h = t = NULL;
   for (int i=1; i<=num; ++i)
      { offset = new OFFSET;
	offset->dx = offset->dy = ZERO;
	offset->prevo = t;
	offset->nexto = NULL;
	if (h)
	   t->nexto = offset;
	else
	   h = offset;
	t = offset;
      }
   t->nexto = head;
   if (head)
      head->prevo = t;
   head = h;
   if (!tail)
      tail = t;
   count += num;

   return (ret);
}


/* ********************************************************************
Action::AddTail(int num)

Return a path which has the given number of null offsets added to the
tail of the given path.
******************************************************************** */

ActionPtr
Action::AddTail(int num)
{
   OFFSET_PTR offset,h,t;
   ActionPtr ret = Copy();

   if (num <= 0) return( ret );
   h = t = NULL;
   for (int i=1; i<=num; ++i)
      { offset = new OFFSET;
	offset->dx = offset->dy = ZERO;
	offset->prevo = t;
	offset->nexto = NULL;
	if (h)
	   t->nexto = offset;
	else
	   h = offset;
	t = offset;
      }
   h->prevo = tail;
   if (tail)
      tail->nexto = h;
   tail = t;
   if (!h)
      head = h;
   count += num;

   return (ret);
}


/* ********************************************************************
Action::DeleteHead(int num)

Return a path which corresponds to the path with the given number
of offsets removed from its head.
******************************************************************** */

ActionPtr
Action::DeleteHead(int num)
{
   int i;

   if (num < 0) num = 0;

   ActionPtr copy = Copy();
   for (i=1; i<num; ++i)
      copy->DeleteOffsetFromFront();

   return( copy );
}


/* ********************************************************************
Action::DeleteTail(int num)

Return a path which corresponds to the path with the given number
of offsets removed from its tail.
******************************************************************** */

ActionPtr
Action::DeleteTail(int num)
{
   int i;

   if (num < 0) num=0;

   ActionPtr copy = Copy();
   for (i=1; i<num; ++i)
      copy->DeleteOffsetFromEnd();

   return( copy );
}


/* ********************************************************************
Action::Copy()

Return a new path which is a duplicate of this path.
******************************************************************** */

ActionPtr
Action::Copy()
{
   OFFSET_PTR offset,ptr,h,t;
   ActionPtr copy = new Action(type);

   h = t = NULL;
   for (ptr=head; ptr; ptr=ptr->nexto)
      { offset = new OFFSET;
	offset->dx = ptr->dx;
	offset->dy = ptr->dy;
	offset->prevo = t;
	offset->nexto = NULL;
	if (h)
	   t->nexto = offset;
	else
	   h = offset;
	t = offset;
      }

   copy->count = count;
   copy->head = h;
   copy->tail = t;
   return( copy );
}



/* ********************************************************************
Action::ChangeType()

Return a new path which is a duplicate of this path except the type
is changed.
******************************************************************** */

ActionPtr
Action::ChangeType(const char *t)
{
   ActionPtr copy = Copy();
   strcpy(copy->type,t);
   return(copy);
}



/* ********************************************************************
Action::Reverse()

Return a new path which is a a reversal of the given path.  This 
entails reversing the order of the offsets and making each's direction
be opposite.
******************************************************************** */

ActionPtr
Action::Reverse()
{
   OFFSET_PTR offset,ptr,h,t;
   ActionPtr reverse = new Action(type);

   h = t = NULL;
   for (ptr=tail; ptr; ptr=ptr->prevo)
      { offset = new OFFSET;
	offset->dx = -(ptr->dx);
	offset->dy = -(ptr->dy);
	offset->prevo = t;
	offset->nexto = NULL;
	if (h)
	   t->nexto = offset;
	else
	   h = offset;
	t = offset;
      }

   reverse->count = count;
   reverse->head = h;
   reverse->tail = t;
   return( reverse );

}



/* ********************************************************************
Action::Smooth()

Return a path that is a "smoother" version of the given path (avg.
in nearby offsets).
******************************************************************** */

ActionPtr
Action::Smooth()
{
   OFFSET_PTR ptr,run;
   double  x,y,oldx,oldy,newx,newy,xshould,yshould;

   if (count <= 1) return( Copy() );

   ActionPtr copy = Copy();

   ptr = head;
   oldx = ptr->dx;
   oldy = ptr->dy;
   newx = (3.0 * ptr->dx + ptr->nexto->dx) / 4.0;
   newy = (3.0 * ptr->dy + ptr->nexto->dy) / 4.0;

   run = copy->head;
   run->dx = newx;
   run->dy = newy;

   for (ptr=ptr->nexto; ptr->nexto; ptr=ptr->nexto) {
      run = run->nexto;
      oldx += ptr->dx;
      oldy += ptr->dy;
      xshould = (4.0 * oldx - ptr->prevo->dx + ptr->nexto->dx) / 4.0;
      yshould = (4.0 * oldy - ptr->prevo->dy + ptr->nexto->dy) / 4.0;

      run->dx = ptr->dx + xshould - oldx;
      run->dy = ptr->dy + yshould - oldy;

      newx += run->dx;
      newy += run->dy;
      }
   x = Deltax() - newx;
   y = Deltay() - newy;

   run = run->nexto;
   run->dx = x;
   run->dy = y;
   
   return( copy );
}


/* ********************************************************************
Action::Rotate(int deg)

Create a path which is the rotation of the given path by the given
number of degrees.  (positive degrees only and counterclockwise
rotation)
******************************************************************** */

ActionPtr
Action::Rotate(int deg)
{
   double rads = 0.017453/* PI/180 */    *  deg;
   double cosine = cos(rads);
   double sine = sin(rads);
   OFFSET_PTR offset;

   ActionPtr rotpath = Copy();

   for (offset=rotpath->head; offset; offset=offset->nexto)
     { offset->dx = (offset->dx * cosine) - (offset->dy * sine);
       offset->dy = (offset->dx * sine) + (offset->dy * cosine);
     }
   return( rotpath );
}


/* ********************************************************************
Action::Scale(double xscale, double yscale)

Return a path scaled by the given factors in x and y.
******************************************************************** */

ActionPtr
Action::Scale(double xscale, double yscale)
{
   OFFSET_PTR offset;
   ActionPtr scalepath = Copy();

   for (offset=scalepath->head; offset; offset=offset->nexto)
     { offset->dx = offset->dx * xscale;
       offset->dy = offset->dy * yscale;
     }
   return( scalepath );
}


/* ********************************************************************
Action::Extend(double x, double y)

Return a path such that (x,y) has been added to each offset.
******************************************************************** */

ActionPtr
Action::Extend(double x, double y)
{
   OFFSET_PTR offset;
   ActionPtr extpath = Copy();

   for (offset=extpath->head; offset; offset=offset->nexto)
     { offset->dx = offset->dx + x;
       offset->dy = offset->dy + y;
     }
   return( extpath );
}


/* ********************************************************************
Action::Interpolate(double factor)

Create a path which contains an interpolated number of offsets from
the given path as indicated by the parameter factor.
******************************************************************** */

ActionPtr
Action::Interpolate(double factor)
{
   int found;
   double x,y,runx,runy,remainder,total,percent;
   OFFSET_PTR off,offset;
   ActionPtr newa = new Action(type);

   remainder = 0.0;
   runx = runy = 0.0;
   total = factor;
   found = 0;
   off = head;
   x = off->dx;
   y = off->dy;
   while (!found) {
      if ((remainder+factor) < 1.0) {
         runx += x;
         runy += y;
         off = off->nexto;
         if (off) {
            x = off->dx;
            y = off->dy;
            total += factor;
            remainder += factor;
            }
         else
            found = 1;
         }
      else {
         while (total >= 1.0) { 
            percent = (1.0 - remainder) / factor;

	    offset = new OFFSET;
	    newa->count++;
	    offset->dx = runx + (percent * x);
	    offset->dy = runy + (percent * y);
	    offset->prevo = newa->tail;
	    offset->nexto = NULL;
	    if (newa->head)
	       newa->tail->nexto = offset;
	    else
	       newa->head = offset;
	    newa->tail = offset;

            runx = runy = 0.0;
            remainder = 0.0;
            total -= 1.0;
            }
         remainder = total;
         runx = (remainder / factor) * x;
         runy = (remainder / factor) * y;
         off = off->nexto;
         if (off) {
            x = off->dx;
            y = off->dy;
            total += factor;
            }
         else
            found = 1;
         }
      }
   offset = new OFFSET;
   newa->count++;
   offset->dx = runx;
   offset->dy = runy;
   offset->prevo = newa->tail;
   offset->nexto = NULL;
   if (newa->head)
      newa->tail->nexto = offset;
   else
      newa->head = offset;
   newa->tail = offset;

   return( newa );
}


/* ********************************************************************
Action::Example(Loc fromloc, Loc toloc)

Create and return a path which looks like the given path, only it
begins at fromloc and runs to toloc.
******************************************************************** */

ActionPtr
Action::Example(LocPtr fromloc, LocPtr toloc)
{
   double	loc_dx,loc_dy;	    /* total x and y changes in given locs   */
   double	path_dx,path_dy;    /* total x and y changes in given path   */
   double	dx_ratio,dy_ratio;  /* loc--path differences over # points   */
   OFFSET_PTR   op;
   int xscale,yscale;

   if (!head) {
      Action temp = Action(type,STRAIGHT);
      return( temp.Example(fromloc,toloc) );
      }

   loc_dx = toloc->XCoord() - fromloc->XCoord();
   loc_dy = toloc->YCoord() - fromloc->YCoord();
   path_dx = Deltax();
   path_dy = Deltay();

   if ( _EQUAL(path_dx,0.0) ) {
      dx_ratio = loc_dx / (double)(Length());
      xscale = 0;
      }
   else { 
      dx_ratio = loc_dx / path_dx;
      xscale = 1;
      }

   if ( _EQUAL(path_dy,0.0) ) {
      dy_ratio = loc_dy / (double)(Length());
      yscale = 0;
      }
   else {
      dy_ratio = loc_dy / path_dy;
      yscale = 1;
      }

   ActionPtr copy = Copy();

   for (op=copy->head;op;op=op->nexto) {
      op->dx = ((xscale) ? op->dx * dx_ratio : op->dx + dx_ratio);
      op->dy = ((yscale) ? op->dy * dy_ratio : op->dy + dy_ratio);
      }

   return( copy );
}


/* ********************************************************************
Action::Iterate(int num)

Return a path which is "num" iterations of the given path concatenated
after each other.
******************************************************************** */

ActionPtr
Action::Iterate(int num)
{
   OFFSET_PTR offset,op;
   int whole,parts,i;
   double decimal;

   ActionPtr newa = new Action(type);

   whole = (int) num;

   newa->head = newa->tail = NULL;
   newa->count = 0;

   for (i=1; i<=whole; ++i)
      { for (op=head; op; op=op->nexto)
	   { offset = new OFFSET;
	     offset->dx = op->dx;
	     offset->dy = op->dy;
	     if (!newa->head)
		newa->head = offset;
	     else
		newa->tail->nexto = offset;
	     offset->prevo = newa->tail;
	     offset->nexto = NULL;
	     newa->tail = offset;
	   }
	newa->count += count;
      }

   decimal = num - (double) whole;
   parts = (int) (decimal * (double)(count));

   op = head;
   for (i=1; i<=parts; ++i)
      { offset = new OFFSET;
	offset->dx = op->dx;
	offset->dy = op->dy;
	if (!newa->head)
	   newa->head = offset;
	else
	   newa->tail->nexto = offset;
	offset->prevo = newa->tail;
	offset->nexto = NULL;
	newa->tail = offset;
	op = op->nexto;
      }
   newa->count += parts;
   return( newa );
}


/* ********************************************************************
Action::Concatenate(Action path)

Return a new path that is the concatenation of this with path.
******************************************************************** */

ActionPtr
Action::Concatenate(ActionPtr path)
{
   ActionPtr front = Copy();
   ActionPtr end = path->Copy();

   if (!front->head)
      { delete front;
        return( end );
    }
   else if (!end->head)
      { delete end;
        return( front );
    }
   else {
      front->tail->nexto = end->head;
      end->head->prevo = front->tail;
      front->tail = end->tail;
      end->head = end-> tail = NULL;
      front->count += end->count;
      delete end;
      return( front );
      }
}


/* ********************************************************************
Action::Compose(Action path)

Returns a new path that is the composition (sum of corresponding
offsets) of this with path.  If this and path do not have the same
number of offsets, returns NULL.
******************************************************************** */

ActionPtr
Action::Compose(ActionPtr path)
{
   if (count == path->Length()) {
      OFFSET_PTR op1,op2;
      ActionPtr compath = Copy();
      for (op1=compath->head,op2=path->head; op1;
                 op1=op1->nexto,op2=op2->nexto) {
         op1->dx += op2->dx;
         op1->dy += op2->dy;
         }
      return( compath );
      }
   else
      return( NULL );
}
