/***************************************************************/
/*							                                   */
/*	       		CircleImpl.cpp	                               */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#include "CircleImpl.h"
#include "View.h"
#include "Drawable.h"
#include "Pixmap.h"


CircleImpl::CircleImpl(View *a, int v, double lx, double ly, double r,
                  COLOR c, double f) 
          : AnimObjectImpl(a,v,lx,ly)
{
   type = P_Circle;
   radius = r;
   strcpy(colorname,c);
   color = load_color(colorname);
   fill = f;
}


CircleImpl::CircleImpl(const CircleImpl& c) : AnimObjectImpl( c )
{
   radius = c.radius;
   strcpy(colorname,c.colorname);
   color = c.color;
   fill = c.fill;
}
  

CircleImpl::~CircleImpl()
{
   Erase();
}


void 
CircleImpl::GetValues(View* *vi, int *v, double *lx, double *ly, double *r, 
              COLOR c, double *f)
{
   if (vi) *vi=view;
   if (v) *v=visibility;
   if (lx) *lx=locx;
   if (ly) *ly=locy;
   if (r) *r=radius;
   if (c) strcpy(c,colorname);
   if (f) *f=fill;
}   


LocPtr
CircleImpl::Where(PART p)
{
   double	   x0,y0,corner;

   x0 = locx;
   y0 = locy;
   corner = sqrt( (radius * radius) / 2.0 );
   switch (p)
   {
      case PART_C :
	 return( new Loc(x0,y0) );
      case PART_NW :
	 return( new Loc(x0-corner,y0+corner) );
      case PART_N :
	 return( new Loc(x0,y0+radius) );
      case PART_NE :
	 return( new Loc(x0+corner,y0+corner) );
      case PART_E :
	 return( new Loc(x0+radius,y0) );
      case PART_SE :
	 return( new Loc(x0+corner,y0-corner) );
      case PART_S :
	 return( new Loc(x0,y0-radius) );
      case PART_SW :
	 return( new Loc(x0-corner,y0-corner) );
      case PART_W :
	 return( new Loc(x0-radius,y0) );
   }
   return( new Loc(0.0,0.0) );
}


void
CircleImpl::BoundBox(double *lx, double *by, double *rx, double *ty)
{
   *lx = locx - radius;
   *rx = locx + radius;
   *ty = locy + radius;
   *by = locy - radius;
}


int
CircleImpl::IsPickIn(double xpt, double ypt)
{
   double dist,xd,yd;

   xd = locx-xpt;
   yd = locy-ypt;
   dist = sqrt( (xd*xd) + (yd*yd) );

   if (dist <= radius)
      return(1);
   else
      return(0);
}   


void
CircleImpl::transSpecial(char *atype, double dx, double dy)
{
   if (streql(atype,"FILL"))
      { fill +=  dx;
	if (fill < 0.0)
	   fill = 0.0;
	else if (fill > 1.0)
	   fill = 1.0;
        DamageIt();
      }
   else if (streql(atype,"RESIZE"))
      { DamageIt();
        radius += dx;
	if (radius < ZERO)
	   radius = ZERO;
        DamageIt();
      }
   else if (streql(atype,"COLOR")) {
      color = get_pathcolor(dx,dy);
      DamageIt();
      }
}

   
void
CircleImpl::Draw()
{
   FILL_STYLE curfill;

   curfill = get_fillstyle(fill);
   drawer(color,curfill);
}


void
CircleImpl::Erase()
{
   FILL_STYLE curfill;

   curfill = get_fillstyle(fill);
   if (curfill == POLKA_FILL_OUTLINE)
      drawer(view->GetBgColor(),POLKA_FILL_OUTLINE);
   else
      drawer(view->GetBgColor(),POLKA_FILL_SOLID);
}


void
CircleImpl::drawer(COLORINDEX col,FILL_STYLE curfill)
{
   int x0,y0,radx,rady;
   FILL_STYLE oldfill;

   if (!visibility)
      return;

   x0 = view->TO_PIX_X(locx);
   y0 = view->TO_PIX_Y(locy);
   radx = view->SIZE_PIX_X(radius);
   rady = view->SIZE_PIX_Y(radius);
   set_color(col);

   if (curfill == POLKA_FILL_OUTLINE)
      {
         XDrawEllipse(view->DrawWindow(),inq_gc(),
			 x0-radx,y0-rady,radx<<1,rady<<1);
      }                                /* multiply by 2 to get size */
   else 
      {
        oldfill = fill_style(curfill);
        XFillEllipse(view->DrawWindow(),inq_gc(),
			x0-radx,y0-rady,radx<<1,rady<<1);
        fill_style(oldfill);
      }
}
