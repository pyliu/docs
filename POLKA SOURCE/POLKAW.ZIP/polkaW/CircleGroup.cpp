/***************************************************************/
/*							                                   */
/*	       		CircleGroup.cpp			                       */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#include "CircleGroup.h"


CircleGroup::CircleGroup()
{
   fill = 0.0;
}


int
CircleGroup::Make(View *v, Circle *o[], int n, 
                   double lx, double by, double rx, double ty)
{
   double s,locx,locy,rad;
   int i;

   locx = lx;
   locy = by;
   for (i=0; i<n; i++) {
      if (horiz) {
         if (spacetype == SpacingNone) s = 0.0;
         else if (spacetype == SpacingSame) s = (rx-lx) / (2.0 * n - 1.0);
         else if (spacetype == SpacingAbsolute) s = spacing;

         if (useints)
            rad = (double)(intvals[i]-intmin) / 
                     (double)(intmax-intmin) * (ty-by) * 0.5;
         else if (usedoubles)
            rad = (doublevals[i]-doublemin) / 
                      (doublemax-doublemin) * (ty-by) * 0.5;
         else
            rad = ((rx-lx)-(s*(n-1))) / (2.0 * n);
   
         if (align == AlignBottom)
            o[i] = new Circle(v,vis,locx+rad,locy+rad,rad,color,fill);
         else if (align == AlignMiddle)
            o[i] = new Circle(v,vis,locx+rad,by+(ty-by)/2.0,rad,color,fill);
         else if (align == AlignTop)
            o[i] = new Circle(v,vis,locx+rad,ty-rad,rad,color,fill);
         else /* bad */
            o[i] = new Circle(v,vis,locx+rad,locy+rad,rad,color,fill);

         locx += 2.0 * rad + s;
      }
      else /* vertical */ {
         if (spacetype == SpacingNone) s = 0.0;
         else if (spacetype == SpacingSame) s = (ty-by) / (2.0 * n - 1.0);
         else if (spacetype == SpacingAbsolute) s = spacing;

         if (useints)
            rad = (double)(intvals[i]-intmin) / 
                        (double)(intmax-intmin) * (rx-lx);
         else if (usedoubles)
            rad = (doublevals[i]-doublemin) / 
                      (doublemax-doublemin) * (rx-lx);
         else
            rad = ((ty-by)-(s*(n-1))) / (2.0 * n);

         if (align == AlignLeft)
            o[i] = new Circle(v,vis,locx+rad,locy+rad,rad,color,fill);
         else if (align == AlignMiddle)
            o[i] = new Circle(v,vis,lx+(rx-lx)/2.0,locy+rad,rad,color,fill);
         else if (align == AlignRight)
            o[i] = new Circle(v,vis,rx-rad,locy+rad,rad,color,fill);
         else /* bad */
            o[i] = new Circle(v,vis,locx+rad,locy+rad,rad,color,fill);

         locy += 2.0 * rad + s;
      }
   }
   return (1);
}  



