#include <iostream.h>
#include <string.h>
//#include <stream.h>
//#include <strings.h>
#include "polka.H"
#include "spath.H"

const double   RADIUS =  0.02;

char * FRINGECOLOR =   "violet";
char * TREECOLOR =   "blue";
char * MINCOLOR =   "OrangeRed";
char * PATHCOLOR =   "LimeGreen";



/* create location and adj matrix associations */

void
SPath::Init()
{
   Create("Shortest Path Algorithm");

   Text *t = new Text(this, 1, 0.05, 0.975, "red", "variable", "STOP", 1);
   t->Originate(time);
   stop = new Rectangle(this, 1 ,0.0, 0.95, 0.1, 0.05, "red", 0.0);
   stop->Originate(time);
   time = Animate(time, 1);
}




/* get the locations of the vertices */

char *
SPath::Vertex(int index)
{
   char 	 str[3],*ret;
   double	 x,y;

   PickCoord(x,y);
   if ((0.0<=x) && (x<=0.1) && (0.95<=y) && (y<=1.0))  // chose to stop 
      return(NULL);
   pos[index] = new Loc(x,y);

   sprintf(str,"%d",index);
   label[index] = new Text(this, 1, x,y, "black", "variable", str, 1);
   label[index]->Originate(time);

   vertex[index] = new Circle(this, 1, x, y, RADIUS, "black", 0.0);
   vertex[index]->Originate(time);
   vertex[index]->StoreData((void*)index);

   ret = new char[64];
   sprintf(ret,"%lf %lf",x,y);
   time = Animate(time, 1);
   return(ret);
}



/* get the edges */

char *
SPath::Edge()
{
   AnimObject	 *node1,*node2;
   int		 index1,index2;
   double	 x1,y1,x2,y2;
   char 	 *ret;

   while (!PickAnimObject(node1)) continue;
   if (node1 == stop)
      { ret = new char[8];
        sprintf(ret,"-1 -1");
        return(ret);
      }

   while (!PickAnimObject(node2)) continue;
   if (node2 == stop)
      { ret = new char[8];
        sprintf(ret,"-1 -1");
        return(ret);
      }

   index1 = (int) node1->RetrieveData();
   index2 = (int) node2->RetrieveData();

   x1 = pos[index1]->XCoord();
   y1 = pos[index1]->YCoord();
   x2 = pos[index2]->XCoord();
   y2 = pos[index2]->YCoord();

   edge[index1][index2] = edge[index2][index1] = new Line(this, 1, x1, y1, 
                               x2-x1, y2-y1, "black", 0.5, 1.0, 0);
   edge[index1][index2]->Originate(time);

   Action a("LOWER",1);
   edge[index1][index2]->Program(time, &a);

   ret = new char[8];
   sprintf(ret,"%d %d",index1,index2);
   time = Animate(time, 1);
   return(ret);
}



char *
SPath::GetNode()
{
   AnimObject *obj;
   int index;
   char *ret;

   PickAnimObject(obj);
   index = (int) obj->RetrieveData();
   ret = new char[8];
   sprintf(ret,"%d",index);
   return(ret);
}



void
SPath::Examine(int from, int to)
{
   static double dashed_x[1] = { 0.0 };
   static double dashed_y[1] = { -0.5 };
   static double solid_x[1] = { 0.0 };
   static double solid_y[1] = { 0.5 };
   Action *concat,*over;
   int len;

   Action dashed("FILL", 1, dashed_x, dashed_y);
   Action solid("FILL", 1, solid_x, solid_y);
   concat = dashed.Concatenate(&solid);
   over = concat->Iterate(6);
   len = edge[from][to]->Program(time, over);
   message("Examining new edge");
   time = Animate(time, len);
   delete(concat);
   delete(over);
}



void
SPath::NewMin(int from, int to)
{
   int len;

   Action color1("COLOR", MINCOLOR);
   len = edge[from][to]->Program(time, &color1);

   if (oldedge)
      { Action color2("COLOR", FRINGECOLOR);
	len = oldedge->Program(time, &color2);
      }

   message("New minimum found");

   time = Animate(time, 10);  // want a little delay here
   oldedge = edge[from][to];
}



void
SPath::AddFringe(int from, int to)
{
   int len;
   static double fillpath_x[1] = { 1.0 };
   static double fillpath_y[1] = { 0.0 };

   if (edge[from][to])
      { Action color("COLOR", FRINGECOLOR);
	len = edge[from][to]->Program(time, &color);
        time = Animate(time, len);
      }

   Action filler("FILL", 1, fillpath_x, fillpath_y);
   len = vertex[to]->Program(time, &filler);

   Action col("COLOR", FRINGECOLOR);
   len = vertex[to]->Program(time, &col);

   Action raise("RAISE", 1);
   len = label[to]->Program(time, &raise);

   Action white("COLOR", "white");
   len = label[to]->Program(time, &white);

   time = Animate(time, len);
}



void
SPath::Shorter(int from, int to)
{
   int len;

   Action color("COLOR", FRINGECOLOR);
   len = edge[from][to]->Program(time, &color);
   time = Animate(time, len);
}



void
SPath::Add(int n)
{
   int len;
   static double px[1] = { 1.0 };
   static double py[1] = { 0.0 };

   Action color("COLOR", TREECOLOR);
   len = vertex[n]->Program(time, &color);

   if (oldedge)
      { oldedge->Program(time, &color);

	Action thick("FILL", 1, px, py);
	oldedge->Program(time, &thick);
      }

   message("Adding new vertex to tree");

   time = Animate(time, 10);  // want a little delay here
   oldedge = NULL;
}



void
SPath::AlongPath(int from, int to)
{
   int len;

   Action color("COLOR", PATHCOLOR);
   len = edge[from][to]->Program(time, &color);
   message("Designating Shortest Path");
   time = Animate(time, len);
}



void
SPath::DisplayLegend()
{
   Text *t;

   t = new Text(this, 1, 0.80, 0.96, TREECOLOR, "variable", 
                             "Spanning tree", 0);
   t->Originate(time);
   t = new Text(this, 1, 0.80, 0.92, FRINGECOLOR, "variable", 
                             "Tree fringe", 0);
   t->Originate(time);
   t = new Text(this, 1, 0.80, 0.88, MINCOLOR, "variable", 
                             "Next best", 0);
   t->Originate(time);
   t = new Text(this, 1, 0.80, 0.84, PATHCOLOR, "variable", 
                             "Shortest path", 0);
   t->Originate(time);
   time = Animate(time, 1);
}

   

void
SPath::message(char *str)
{
   static Text *msg = NULL;

   if (msg)
      msg->Delete(time);
   msg = new Text(this, 1, 0.5, 0.03, "black", "10x20",
            str, 1);
   msg->Originate(time);
}

