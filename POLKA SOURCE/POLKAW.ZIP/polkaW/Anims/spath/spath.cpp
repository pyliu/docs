#include <iostream.h>
#include <string.h>
//#include <stream.h>
//#include <strings.h>
#include <math.h>
#include "polka.H"
#include "spath.H"

SPath *s;

const double INFINITY = 1000.0;
const int UNSEEN =  0;
const int FRINGE =  1;
const int INTREE =  2;

const int TOPS = 25;

const double SQUARE(double A) { return(A*A); };


main(int argc, char *argv[])
{
   int i,j,n, status[TOPS], from[TOPS], parent[TOPS], numbeento, next, start,end;
   double loc[TOPS][2],dist[TOPS],edge[TOPS][TOPS],min;
   char *reply;

   s = new SPath;

   s->Init();


   cout << "SHORTEST PATH " << endl;
   cout << "Interactively draw the graph with the mouse." << endl;
   cout << "Click to select a vertex position (click in STOP to stop)" << endl;

   n=0;
   for (;;)
      { reply = s->Vertex(n);
	if (!reply || (*reply=='\0')) break;
	sscanf(reply,"%lf %lf",&(loc[n][0]),&(loc[n][1]));
	n++;
	delete [] reply;
      }

   for (i=0; i<n; ++i)
      for (j=0; j<n; ++j)
	 edge[i][j] = INFINITY;

   cout << "Select pairs of vertices for edges. (Click STOP to stop.)" << endl;
   for (;;)
      { reply = s->Edge();
	if (reply && *reply)
	   { sscanf(reply,"%d %d",&i,&j);
	     if (i == -1) break;
	     edge[i][j] = sqrt( SQUARE(loc[i][0]-loc[j][0]) + SQUARE(loc[i][1]-loc[j][1]) );
	     edge[j][i] = edge[i][j];	/* undirected for now */
             delete [] reply;
	   }
      }

   for (i=0; i<n; ++i)
      { status[i] = UNSEEN;
	dist[i] = INFINITY;
	from[i] = 0;
      }

   cout << "Select the start vertex" << endl;
   reply = s->GetNode();
   sscanf(reply,"%d",&start);
   delete [] reply;

   cout << "Select the end vertex" << endl;
   reply = s->GetNode();
   sscanf(reply,"%d",&end);
   delete [] reply;

   s->DisplayLegend();

   status[start] = INTREE;
   dist[start] = 0.0;
   from[start] = start;
   numbeento = 1;
   s->AddFringe(start,start);
   s->Add(start);

   for (i=0; i<n; ++i)
      if ((status[i] == UNSEEN) && (edge[start][i] != INFINITY))
	 { status[i] = FRINGE;
	   from[i] = start;
	   dist[i] = edge[start][i];
	   s->AddFringe(start,i);
	 }

   while (numbeento < n)
      { min = INFINITY;
	for (i=0; i<n; ++i)
	   if (status[i] == FRINGE)
	      { s->Examine(from[i],i);
		if (dist[i] < min)
		   { s->NewMin(from[i],i);
		     min  = dist[i];
		     next = i;
		   }
	      }
	s->Add(next);
        parent[next] = from[next];
	status[next] = INTREE;
	numbeento++;
	if (next == end)
	   break;

	for (i=0; i<n; ++i)
	   if ((status[i] == UNSEEN) && (edge[next][i] != INFINITY))
	      { s->AddFringe(next,i);
		status[i] = FRINGE;
		from[i] = next;
		dist[i] = dist[next] + edge[next][i];
	      }
	   else if (status[i] == FRINGE)
	      { if (dist[next]+edge[next][i] < dist[i])  /* better way of */
		   { dist[i] = dist[next]+edge[next][i];  /* getting there */
		     from[i] = next;
		     s->Shorter(next,i);
		   }
	      }
      }
   next = end;
   while (next != start) {
     s->AlongPath(next, parent[next]);
     next = parent[next];
     }
   while (1)
     s->CheckInput();
}
