#include <iostream.h>
#include <string.h>
#include <errno.h>
#include <polka.H>
#include "shellsort.H"

MyAnimator sh;



int
MyAnimator::Controller()
{
//   cout << "In controller aen=" << AlgoEvtName << "\n";

   if (!strcmp(AlgoEvtName,"Init")) {
      b.Init();
   }
   else if (!strcmp(AlgoEvtName,"Input")) {
      b.Input(AnimInts[0],AnimInts[1]);
   }
   else if (!strcmp(AlgoEvtName,"Allset")) {
      b.Ready(AnimInts[0]);
   }
   else if (!strcmp(AlgoEvtName,"Subarray")) 
      b.MoveIt(AnimInts[0],AnimInts[1],AnimInts[2],AnimInts[3]);
   else if (!strcmp(AlgoEvtName,"Exchange")) { 
      b.Exchange(AnimInts[0],AnimInts[1]);
   }
   else if (!strcmp(AlgoEvtName,"Done"))  {
      b.InPlace(AnimInts[0]);
   }
   else 
      b.CheckInput();
   return(1);
}


int
Blocks::Init()
{
   Create("Sorting");
   SetBgColor("black");
   return(0);
}



/* save the values in the array */

int
Blocks::Input(int index, int val)
{
   values[index] = val;
   if (val > max) max=val;
   if (val < min) min=val;
   return(1);
}




/* draw the array as a row of rectangles with the heights corresponding */
/* to the value of each array element.					*/

int
Blocks::Ready(int n)
{
   int len,i;
   RectangleGroup objs;

   strcpy(objs.color,"green");
   objs.spacetype = SpacingSame;
   objs.horiz = 1;
   objs.align = AlignBottom;
   objs.fill = 1.0;
   objs.useints = 1;
   objs.intvals = values;
   objs.intmin = min;
   objs.intmax = max;
   objs.Make(this,blocks,n,0.1,0.5,0.9,0.9);

   for (i=0; i<n; ++i)
      blocks[i]->Originate(0);

   Action a("DELAY",10);
   len = blocks[0]->Program(time,&a);
   time = Animate(time, len);
   return(len);
}




int
Blocks::MoveIt(int start, int jump, int type, int total)
{
   Loc back(0.1, 0.5);
   Loc down(0.1, 0.1);
   Action *a;
   int len,i;

   if (type == 0)
      a = new Action("MOVE", &back, &down, 0.02);
   else
      a = new Action("MOVE", &down, &back, 0.02);

   for (i=start; i<total; i+=jump) 
     len = blocks[i]->Program(time, a);
    
   time = Animate(time, len);
   delete(a);
   return(len);
}




/* make the two rectangles exchange positions on the screen in one */
/* simultaneous movement					   */

int
Blocks::Exchange(int i, int j)
{
   Rectangle *tempr;
   LocPtr loc1,loc2;
   int len;

   loc1 = blocks[i]->Where(PART_SW);
   loc2 = blocks[j]->Where(PART_SW);
   Action a("MOVE",loc1,loc2,0.02);
   Action *b = a.Rotate(180);
   len = blocks[i]->Program(time,&a);
   blocks[j]->Program(time,b);
   time = Animate(time, len);

   tempr = blocks[i];
   blocks[i] = blocks[j];
   blocks[j] = tempr;

   delete b;
   return(len);
}





/* alter the fill style of the rectangle to show it is "in-place" */

int
Blocks::InPlace(int i)
{
   int len=0;
   double f = 1.0;

//   Action a("FILL",1,&f,&f);
//   Action b("COLOR","white");
//   blocks[i]->Program(time,&a);
//   len = labels[i]->Program(time,&b);
//   time += len;
   return(len);
}


