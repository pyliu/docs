#include <iostream.h>
#include <string.h>
#include <errno.h>
#include <polka.H>
#include "shellsort.H"

extern MyAnimator sh;

main(int, char **)
{
   int n,i,j,k,shell,val;
   int a[100];
   int count;
   
   sh.RegisterAlgoEvt("Init",NULL);
   sh.RegisterAlgoEvt("Input","dd");
   sh.RegisterAlgoEvt("Allset","d");
   sh.RegisterAlgoEvt("Subarray","dddd");
   sh.RegisterAlgoEvt("Exchange","dd");
   sh.RegisterAlgoEvt("Done","d");
   sh.RegisterAlgoEvt("Wait",NULL);

   cout << "Shellsort" << endl;
   cout << "  Input number of elements in array" << endl;
   cin >> n;
   sh.SendAlgoEvt("Init",NULL);

   cout << "Enter the elements" << endl;
   for (count=0; count<n; ++count) {
      cin >> a[count];
      sh.SendAlgoEvt("Input",count,a[count]);
      }

   sh.SendAlgoEvt("Allset", n);
   shell = 1;
   do {shell = shell*3 + 1;} while (shell <= n);
   while (shell) {
        shell /= 3;
	for (i=0; i<shell; ++i) {
	   j = i + shell;
           sh.SendAlgoEvt("Subarray", i, shell, 0, n); 
           while (j < n) {
              k = j;
              val = a[k];
              while (a[k-shell] > val) {
                 sh.SendAlgoEvt("Exchange", k-shell, k);
                 a[k] = a[k-shell];
                 k -= shell;
                 if (k < shell) break;
                 }
	      a[k] = val;
              j += shell;
              }
           sh.SendAlgoEvt("Subarray", i%shell, shell, 1, n); 
	   }
        sh.SendAlgoEvt("Done", n);
      }
   for (i=0; i<n; ++i)
	   cout << a[i] << " ";
   cout << endl;

   while (1)
      sh.SendAlgoEvt("Wait");

}



