#include <iostream.h>
#include <string.h>
#include "polka.H"
#include "tutorial.H"

extern MyAnimator anim;

void main(int argc, char *argv[])
{
   anim.RegisterAlgoEvt("op1",NULL);
   anim.RegisterAlgoEvt("op2",NULL);
   anim.RegisterAlgoEvt("op3",NULL);
   anim.RegisterAlgoEvt("op4",NULL);
   anim.RegisterAlgoEvt("op5",NULL);
   anim.RegisterAlgoEvt("op6",NULL);
   anim.RegisterAlgoEvt("op7",NULL);
   anim.RegisterAlgoEvt("op8",NULL);
   anim.RegisterAlgoEvt("op9",NULL);
   anim.RegisterAlgoEvt("op10",NULL);
   anim.RegisterAlgoEvt("op11",NULL);
   anim.RegisterAlgoEvt("WAIT",NULL);


   anim.SendAlgoEvt("op1");
   anim.SendAlgoEvt("op2");
   anim.SendAlgoEvt("op3");
   anim.SendAlgoEvt("op4");
   anim.SendAlgoEvt("op5");
   anim.SendAlgoEvt("op6");
   anim.SendAlgoEvt("op7");
   anim.SendAlgoEvt("op8");
   anim.SendAlgoEvt("op9");
   anim.SendAlgoEvt("op10");
   anim.SendAlgoEvt("op11");
   while (1)
     anim.SendAlgoEvt("WAIT");
}
