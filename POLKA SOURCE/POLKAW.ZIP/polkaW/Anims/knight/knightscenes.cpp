
/*************   Knight's Tour   by Kalyan Perumalla ****************/

#include <iostream.h>
#include <string.h>
//#include <stream.h>
//#include <strings.h>
#include <errno.h>
//#include <osfcn.h>

#include "polka.H"
//#include "polka.H"
#include "knight.H"

// added
#define TRUE  1
#define FALSE 0
// end added

MyAnimator ktour;

char knight_bits[] = {
   0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01, 0x00,
   0x00, 0x80, 0x02, 0x00, 0x00, 0x80, 0x07, 0x00, 0x00, 0xc0, 0x0f, 0x00,
   0x00, 0xf8, 0x1f, 0x00, 0x00, 0xf8, 0x1f, 0x00, 0x00, 0xdc, 0x3f, 0x00,
   0x00, 0xfe, 0x7f, 0x00, 0x00, 0xff, 0xff, 0x00, 0x80, 0xff, 0xff, 0x01,
   0xc0, 0xff, 0xff, 0x03, 0x40, 0xff, 0xff, 0x03, 0xc0, 0xff, 0xff, 0x07,
   0x00, 0xc3, 0xff, 0x0f, 0x00, 0xc0, 0xff, 0x0f, 0x00, 0x80, 0xff, 0x1f,
   0x00, 0x80, 0xff, 0x3f, 0x00, 0x80, 0xff, 0x7f, 0x00, 0x80, 0xff, 0xff,
   0x00, 0x80, 0xff, 0xff, 0x00, 0x80, 0xff, 0xff, 0x00, 0x80, 0xff, 0xff,
   0x00, 0x80, 0xff, 0xff, 0x00, 0xc0, 0xff, 0xff, 0x00, 0xe0, 0xff, 0xff,
   0x00, 0xf0, 0xff, 0xff, 0x00, 0xf8, 0xff, 0xff, 0x00, 0xf8, 0xff, 0xff,
   0x00, 0xf8, 0xff, 0xff, 0x00, 0xf0, 0xff, 0xff};

char ghost_bits[] = {
   0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xfe, 0xff, 0xff, 0xff, 0xfe, 0xff,
   0xff, 0x7f, 0xfd, 0xff, 0xff, 0x7f, 0xf8, 0xff, 0xff, 0x3f, 0xf0, 0xff,
   0xff, 0x07, 0xe0, 0xff, 0xff, 0x07, 0xe0, 0xff, 0xff, 0x23, 0xc0, 0xff,
   0xff, 0x01, 0x80, 0xff, 0xff, 0x00, 0x00, 0xff, 0x7f, 0x00, 0x00, 0xfe,
   0x3f, 0x00, 0x00, 0xfc, 0xbf, 0x00, 0x00, 0xfc, 0x3f, 0x00, 0x00, 0xf8,
   0xff, 0x3c, 0x00, 0xf0, 0xff, 0x3f, 0x00, 0xf0, 0xff, 0x7f, 0x00, 0xe0,
   0xff, 0x7f, 0x00, 0xc0, 0xff, 0x7f, 0x00, 0x80, 0xff, 0x7f, 0x00, 0x00,
   0xff, 0x7f, 0x00, 0x00, 0xff, 0x7f, 0x00, 0x00, 0xff, 0x7f, 0x00, 0x00,
   0xff, 0x7f, 0x00, 0x00, 0xff, 0x3f, 0x00, 0x00, 0xff, 0x1f, 0x00, 0x00,
   0xff, 0x0f, 0x00, 0x00, 0xff, 0x07, 0x00, 0x00, 0xff, 0x07, 0x00, 0x00,
   0xff, 0x07, 0x00, 0x00, 0xff, 0x0f, 0x00, 0x00};

int MyAnimator::Controller()
{
    static int time = 0;
    int len;

    if( !strcmp( AlgoEvtName, "Init" ) )
    {
	algo.Init( AnimInts[0], AnimInts[1] );
	path.Init( AnimInts[0], AnimInts[1] );
    }
    else if( !strcmp( AlgoEvtName, "Ready" ) )
    {
	path.Ready();
	len = algo.Ready();
	time = Animate( time, len );
    }
    else if( !strcmp( AlgoEvtName, "Visit" ) )
    {
	path.Visit( AnimInts[0], AnimInts[1], AnimInts[2], AnimInts[3] );
	len = algo.Visit( AnimInts[0], AnimInts[1], AnimInts[2], AnimInts[3] );
	time = Animate( time, len );
    }
    else if( !strcmp( AlgoEvtName, "Consider" ) )
    {
	len = algo.Consider( AnimInts[0], AnimInts[1],
			     AnimInts[2], AnimInts[3] );
	time = Animate( time, len );
    }
    else if( !strcmp( AlgoEvtName, "Reach" ) )
    {
	len = algo.Reach( AnimInts[0], AnimInts[1], AnimInts[2], AnimInts[3] );
	time = Animate( time, len );
    }
    else if( !strcmp( AlgoEvtName, "DoneConsider" ) )
    {
	len = algo.DoneConsider( AnimInts[0], AnimInts[1],
				 AnimInts[2], AnimInts[3],
				 AnimInts[4] );
	time = Animate( time, len );
    }
    else if( !strcmp( AlgoEvtName, "DoneReach" ) )
    {
	len = algo.DoneReach( AnimInts[0], AnimInts[1],
			      AnimInts[2], AnimInts[3] );
	time = Animate( time, len );
    }
    else if( !strcmp( AlgoEvtName, "DoneAllConsider" ) )
    {
	len = algo.DoneAllConsider( AnimInts[0], AnimInts[1] );
	time = Animate( time, len );
    }
    else if( !strcmp( AlgoEvtName, "NextMove" ) )
    {
	path.NextMove( AnimInts[0], AnimInts[1] );
	len = algo.NextMove( AnimInts[0], AnimInts[1] );
	time = Animate( time, len );
    }
    else
    {
	algo.CheckInput();
	path.CheckInput();
    }

    return 1;
}

/* Changes the color of given square */
int ChangeSquareColor( Rectangle *r, char *color, int time )
{
    int len = 0;

    Action a( "COLOR", color );
    len = r->Program( time, &a );

    return len;
}

/* Animates moving knight */
int MoveKnight( Bitmap *knight, Loc *locs[8][8], int time,
		int f_r, int f_c, int t_r, int t_c )
{
    int len = 0;
    Action a( "MOVE", locs[f_r][f_c], locs[t_r][f_c], STRAIGHT );
    Action b( "MOVE", locs[t_r][f_c], locs[t_r][t_c], STRAIGHT );
    Action *c = a.Concatenate( &b );

    len = knight->Program( time, c );

    delete c;
    return len;
}

int FlashSquare( Rectangle *r, char *init_color, char *flash_color,  int time )
{
    int len = 0;

    Action a( "COLOR", flash_color );
    Action b( "COLOR", init_color );
    ActionPtr c = a.Concatenate( &b );
    ActionPtr d = c->Iterate( 6 ); delete c;

    len = r->Program( time, d );
    delete d;

    return len;
}

/* Intializes the Algo view */
int Algo::Init( int row, int col )
{
    k_pos.row = row;
    k_pos.col = col;

    Create("KnightTour (Algo view)");
    return (0);
}

int Algo::Ready( void )
{
    for( int i = 0; i < 8; i++ )
    {
	for( int j = 0; j < 8; j++ )
	{
	    double lx, ly, sx, sy;

            sx = sy = 0.095;
	    lx = 0.1 + j * 0.1;
	    ly = 0.1 + i * 0.1;
	    Rectangle *square = new Rectangle( this, TRUE, lx, ly,
					       sx, sy, INITIAL_COLOR, 1.0 );
	    square->Originate(0);
	    squares[i][j] = square;
	    locs[i][j] = new Loc( lx+0.018, ly+0.018 );
	    strs[i][j] = new Text( this, FALSE,
				   lx+0.05-0.018, ly+0.05-0.018,
				   "black", NULL, "#", TRUE );
	    strs[i][j]->Originate(0);
	}
    }

    Loc k_loc( locs[k_pos.row][k_pos.col]->XCoord(),
               locs[k_pos.row][k_pos.col]->YCoord() );

    knight = new Bitmap( this, TRUE, k_loc.XCoord(), k_loc.YCoord(),
			 KNIGHT_WIDTH, KNIGHT_HEIGHT,
			 knight_bits, KNIGHT_COLOR, INITIAL_COLOR );
    kghost = new Bitmap( this, TRUE, k_loc.XCoord(), k_loc.YCoord(),
			 KGHOST_WIDTH, KGHOST_HEIGHT,
			 ghost_bits, KGHOST_COLOR, INITIAL_COLOR );
    knight->Originate(0);
    kghost->Originate(0);

    Action a( "DELAY", 20 );
    int len = squares[0][0]->Program( time, &a );
    time += len;

    return len;
}

/* Changes (to_r,to_c) to VISITED_COLOR, and 'moves' the knight */
/* from (from_r, from_c) to (to_r, to_c).  Updates knight's curr pos */
int Algo::Visit( int from_r, int from_c, int to_r, int to_c )
{
    int len, old_time = time;

    /* Move both knight and its ghost at the same time */
    len = MoveKnight( knight, locs, time, from_r, from_c, to_r, to_c );
    len = MoveKnight( kghost, locs, time, from_r, from_c, to_r, to_c );
    time += len;

    Action a( "DELAY", 25 );
    len = kghost->Program( time, &a );
    time += len;
    len = ChangeSquareColor( squares[to_r][to_c], VISITED_COLOR, time );
    time += len;
    Action b( "DELAY", 20 );
    len = kghost->Program( time, &b );
    time += len;

    k_pos.row = to_r; k_pos.col = to_c;

    return time - old_time;
}

/* 'Consider's moving the knight from 'from' to 'to'.  Moves the ghost */
/* knight from 'from' to 'to', and changes the 'to's color to CONSIDER_COLOR */
int Algo::Consider( int from_r, int from_c, int to_r, int to_c )
{
    int len, old_time = time;

    len = MoveKnight( kghost, locs, time, from_r, from_c, to_r, to_c );
    time += len;
    len = ChangeSquareColor( squares[to_r][to_c], CONSIDER_COLOR, time );
    time += len;

    return time - old_time;
}

/* Changes 'to's color to REACH_COLOR to show that it is reachable from */
/* 'from'. */
int Algo::Reach( int from_r, int from_c, int to_r, int to_c )
{
    int len, old_time = time;

    len = ChangeSquareColor( squares[to_r][to_c], REACH_COLOR, time );
    time += len;

    return time - old_time;
}

/* Changes to's color to INITIAL_COLOR, moves knight ghost from 'to' to */
/* 'from', and displays the threat number of 'to' in its square */
int Algo::DoneConsider( int from_r, int from_c,
			int to_r, int to_c,
			int nthreats )
{
    int len, old_time = time;
    static char s[100];

    Action a( "MOVE", locs[to_r][to_c], locs[from_r][from_c], 1 );
    len = kghost->Program( time, &a );

    sprintf( s, "%d", nthreats );
    Text *new_t = new Text( this, FALSE,
			    locs[to_r][to_c]->XCoord()+0.05-0.018,
			    locs[to_r][to_c]->YCoord()+0.05-0.018,
		            "black", NULL, s, FALSE );
    strs[to_r][to_c]->Change( time, new_t, TRUE );
    time += len;
    Action c( "VIS", 1 );
    len = strs[to_r][to_c]->Program( time, &c );
    time += len;

    len = ChangeSquareColor( squares[to_r][to_c], INITIAL_COLOR, time );
    time += len;

    return time - old_time;
}

/* Changes 'to's color to INITIAL_COLOR */
int Algo::DoneReach( int from_r, int from_c, int to_r, int to_c )
{
    int len, old_time = time;

    len = ChangeSquareColor( squares[to_r][to_c], INITIAL_COLOR, time );
    time += len;

    return time - old_time;
}

/* Erases the nthreats number in (r,c) */
int Algo::DoneAllConsider( int r, int c )
{
    int len, old_time = time;

    Action a( "VIS", 1 );
    len = strs[r][c]->Program( time, &a );
    time += len;

    return time - old_time;
}

/* Flashes (r,c) */
int Algo::NextMove( int r, int c )
{
    int len, old_time = time;

    len = FlashSquare( squares[r][c], INITIAL_COLOR, FLASH_COLOR, time );
    time += len;

    return time - old_time;
}

/*** End of file ***/

