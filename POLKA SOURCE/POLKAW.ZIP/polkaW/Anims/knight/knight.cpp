
/*************   Knight's Tour   by Kalyan Perumalla ****************/

#include <iostream.h>
#include <string.h>
//#include <stream.h>
//#include <strings.h>
#include <assert.h>
//#include <unistd.h>

#include "polka.H"
#include "knight.H"

#define INVALID 9

// added
#define TRUE  1
#define FALSE 0
// end added

extern MyAnimator ktour;

int KnightTour::NextMoves( ChessPos curr, ChessPos next[8] )
{
    int n = 0;
    int row = curr.row, col = curr.col;

#define NEXT( cond, nr, nc ) \
	if( (cond) && !visited[nr][nc] ) {\
	    next[n].row = nr;\
	    next[n].col = nc;\
	    n++;\
	}

    if( row < 6 ) {
	NEXT( col > 0, row+2, col-1 );
	NEXT( col < 7, row+2, col+1 );
    }

    if( row < 7 ) {
	NEXT( col > 1, row+1, col-2 );
	NEXT( col < 6, row+1, col+2 );
    }

    if( row > 1 ) {
	NEXT( col > 0, row-2, col-1 );
	NEXT( col < 7, row-2, col+1 );
    }

    if( row > 0 ) {
	NEXT( col > 1, row-1, col-2 );
	NEXT( col < 6, row-1, col+2 );
    }

    return n;
}

int KnightTour::FindNThreats( ChessPos pos )
{
    int n_next, i;
    ChessPos all_next[8];

    n_next = NextMoves( pos, all_next );

    //VIEWB
    for( i = 0; i < n_next; i++ )
    {
	ktour.SendAlgoEvt( "Reach", pos.row, pos.col,
			   all_next[i].row, all_next[i].col );
    }

    for( i = 0; i < n_next; i++ )
    {
	ktour.SendAlgoEvt( "DoneReach", pos.row, pos.col,
			   all_next[i].row, all_next[i].col );
    }
    //VIEWE

    return n_next;
}

ChessPos KnightTour::GetNextMove( ChessPos curr )
{
    ChessPos all_next[8];
    int min, min_index, i, n_next, nthreats;

    n_next = NextMoves( curr, all_next );

    for( i = 0, min = INVALID; i < n_next; i++ )
    {
	//VIEWB
	ktour.SendAlgoEvt( "Consider", curr.row, curr.col,
	                   all_next[i].row, all_next[i].col );
	//VIEWE

	nthreats = FindNThreats( all_next[i] );

	//VIEWB
	ktour.SendAlgoEvt( "DoneConsider", curr.row, curr.col,
	                   all_next[i].row, all_next[i].col, nthreats );
	//VIEWE

	if( min == INVALID || min > nthreats ) {
	    min_index = i;
	    min = nthreats;
	}

    }

    assert( min != INVALID );

    //VIEWB
    for( i = 0; i < n_next; i++ )
        ktour.SendAlgoEvt( "DoneAllConsider",
			   all_next[i].row, all_next[i].col );
    //VIEWE

    return all_next[min_index];
}

void KnightTour::InitTour( ChessPos start )
{
    int i, j;

    for( i = 0; i < 8; i++ )
	for( j = 0; j < 8; j++ )
	    visited[i][j] = FALSE;

    nvisited = 1;
    curr_pos = start;
    order[start.row][start.col] = 1;
    visited[start.row][start.col] = TRUE;

    //VIEWB
    ktour.SendAlgoEvt( "Init", start.row, start.col );
    ktour.SendAlgoEvt( "Ready", NULL );
    ktour.SendAlgoEvt( "Visit", start.row, start.col,
		       start.row, start.col );
    //VIEWE
}

/* Returns 0 if all visited, 1 if moved, -1 on error */
int KnightTour::MakeNextMove( void )
{
    if( nvisited == 64 ) return 0;

    ChessPos next = GetNextMove( curr_pos );
    nvisited++;
    order[next.row][next.col] = nvisited;
    visited[next.row][next.col] = TRUE;

    //VIEWB
    ktour.SendAlgoEvt( "NextMove", next.row, next.col );
    ktour.SendAlgoEvt( "Visit", curr_pos.row, curr_pos.col,
		       next.row, next.col );
    //VIEWE

    curr_pos = next;

    return 1;
}

void PrintUsage( char *prog )
{
    cout << "Usage: " << prog << " <RC>" << endl;
    cout <<  "where <RC> is starting row and col digits of the knight." << endl;
    cout << "Example: " << prog << " 36" << endl;
    cout << "Rows and cols of board start with 0." << endl;
    cout << "Animates Knight Tour based on following greedy algorithm:" << endl;
    cout << "      Visit the unvisited square that threatens the least" << endl;
    cout << "      number of unvisited squares." << endl;

// added
	char ch;
	scanf("%c", &ch);
// end added

    exit(1);
}

void main( int ac, char *av[] )
{
    ChessPos start;
    if( ac != 2 ) PrintUsage( av[0] );
    start.row = av[1][0] - '0'; start.col = av[1][1] - '0';
    if( start.row < 0 || start.row > 7 ) PrintUsage( av[0] );
    if( start.col < 0 || start.col > 7 ) PrintUsage( av[0] );

    KnightTour k;

    ktour.RegisterAlgoEvt( "Init", "dd" );
    ktour.RegisterAlgoEvt( "Ready", NULL );
    ktour.RegisterAlgoEvt( "Visit", "dddd" );
    ktour.RegisterAlgoEvt( "Consider", "dddd" );
    ktour.RegisterAlgoEvt( "Reach", "dddd" );
    ktour.RegisterAlgoEvt( "DoneConsider", "ddddd" );
    ktour.RegisterAlgoEvt( "DoneReach", "dddd" );
    ktour.RegisterAlgoEvt( "DoneAllConsider", "dd" );
    ktour.RegisterAlgoEvt( "NextMove", "dd" );
    ktour.RegisterAlgoEvt( "Wait", NULL );

    k.InitTour( start );
    do
    {
	ChessPos pos = k.GetCurrPos();
	//cout << "(" << pos.row << "," << pos.col << ")   " << flush;
    } while( k.MakeNextMove() > 0 );
    //cout << endl;

    while( 1 )
        ktour.SendAlgoEvt( "Wait", NULL );
}

/*** End of file ***/

