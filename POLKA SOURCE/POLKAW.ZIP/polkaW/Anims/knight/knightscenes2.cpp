
/*************   Knight's Tour   by Kalyan Perumalla ****************/

#include <iostream.h>
#include <string.h>
//#include <stream.h>
//#include <strings.h>
#include <errno.h>
//#include <osfcn.h>

#include "polka.H"
//#include "polka.H"
#include "knight.H"

// added
#define TRUE  1
#define FALSE 0
// end added

extern char knight_bits[];

int FlashSquare( Rectangle *, char *, char *, int );
int MoveKnight( Bitmap *, Loc *[8][8], int, int, int, int, int );

/* Intializes the Path view */
int Path::Init( int row, int col )
{
    k_pos.row = row;
    k_pos.col = col;
    Create("KnightTour (Path view)");
    return (0);
}

int Path::Ready( void )
{
    SetBgColor( "limegreen" );

    for( int i = 0; i < 8; i++ )
    {
	for( int j = 0; j < 8; j++ )
	{
	    double lx, ly, sx, sy;

            sx = sy = 0.1;
	    lx = 0.1 + j * 0.1;
	    ly = 0.1 + i * 0.1;
	    Rectangle *square = new Rectangle( this, TRUE, lx, ly,
					       sx, sy,
					       (i+j)%2 ? "black" : "white",
					       1.0 );
	    square->Originate(0);
	    squares[i][j] = square;
	    locs[i][j] = new Loc( lx+0.018, ly+0.018 );
	}
    }

    Loc k_loc( locs[k_pos.row][k_pos.col]->XCoord(),
               locs[k_pos.row][k_pos.col]->YCoord() );

    knight = new Bitmap( this, TRUE, k_loc.XCoord(), k_loc.YCoord(),
			 KNIGHT_WIDTH, KNIGHT_HEIGHT,
			 knight_bits, "pink", "black" );
    knight->Originate(0);

    Action a( "DELAY", 10 );
    int len = squares[0][0]->Program( time, &a );
    time += len;

    return len;
}

/* Flashes (r,c) */
int Path::NextMove( int r, int c )
{
    int len, old_time = time;

    len = FlashSquare( squares[r][c],
		       (r+c) % 2 ? "black" : "white",
		       FLASH_COLOR, time );
    time += len;

    return time - old_time;
}

int Path::Visit( int from_r, int from_c, int to_r, int to_c )
{
    int len, old_time = time;
    double lx, ly, sx, sy, wid;

    len = MoveKnight( knight, locs, time, from_r, from_c, to_r, to_c );
    time += len;

    lx = locs[from_r][from_c]->XCoord(); ly = locs[from_r][from_c]->YCoord();
    sx = locs[to_r][to_c]->XCoord()- lx; sy = locs[to_r][to_c]->YCoord()- ly;
    wid = 0.6;
    Line *ln = new Line( this, TRUE, lx+0.032, ly+0.032, sx, sy,
			 LINE_COLOR, wid, 1.0, 1 );
    ln->Originate(time);

    k_pos.row = to_r; k_pos.col = to_c;

    return time - old_time;
}

/*** End of file ***/

