#include <iostream.h>
//#include <stream.h>
#include <math.h>
#include "polka.H"
#include "heapsort.H"


#define MAX(A,B)  (A > B ? A : B)


MyAnimator  heapsort;



int
MyAnimator::Controller()
{
   int dur,dur1,dur2,i;
//   cout << "In controller aen=" << AlgoEvtName << "\n";

   if (!strcmp(AlgoEvtName,"Init"))  {
      dur1 = sv.Init(AnimInts[0]);
      dur2 = nv.Init(AnimInts[0]);
      dur = MAX(dur1,dur2);
      }
   else if (!strcmp(AlgoEvtName,"AddNode")) {
      dur = nv.Input(AnimInts[0],AnimInts[1]);
      }
   else if (!strcmp(AlgoEvtName,"SetupTree")) {
      dur1 = sv.AddNode(AnimInts[0],AnimInts[1]);
      dur2 = nv.Highlight(AnimInts[0]);
      dur = MAX(dur1, dur2);
      }
   else if (!strcmp(AlgoEvtName,"Elevate")) 
      dur = sv.Elevate(AnimInts[0]);
   else if (!strcmp(AlgoEvtName,"Heapify")) 
      dur = sv.HeapPtr(AnimInts[0]);
   else if (!strcmp(AlgoEvtName,"HeapifyDone")) 
      dur = sv.HeapifyDone();
   else if (!strcmp(AlgoEvtName,"BuildHeap")) 
      dur = sv.BuildPtr(AnimInts[0]);
   else if (!strcmp(AlgoEvtName,"BHStart")) 
      dur = sv.BHToggle();
   else if (!strcmp(AlgoEvtName,"BHFinish")) 
      dur = sv.BHToggle();
   else if (!strcmp(AlgoEvtName,"CompareLeft")) 
      dur = sv.CompareLeft(AnimInts[0]);
   else if (!strcmp(AlgoEvtName,"CompareBoth")) 
      dur = sv.CompareBoth(AnimInts[0]);
   else if (!strcmp(AlgoEvtName,"Exchange"))   {
      dur1 = sv.Exchange(AnimInts[0],AnimInts[1]);
      dur2 = nv.Exchange(dur1,AnimInts[0],AnimInts[1]);
      dur = dur1 + dur2;
      }
   else if (!strcmp(AlgoEvtName,"Sift")) {   
      dur1 = sv.Sift(AnimInts[0],AnimInts[1]);
      dur2 = nv.Exchange(dur1,AnimInts[0],AnimInts[1]);
      dur = dur1 + dur2;
      }
   else if (!strcmp(AlgoEvtName,"Finished"))  {
      dur1 = sv.Done(AnimInts[0]);
      dur2 = nv.Done(AnimInts[0]);
      dur = MAX(dur1, dur2);
      }
   else if (!strcmp(AlgoEvtName,"ArrayMessage"))  
      dur = nv.Message(AnimStrings[0]);
   else if (!strcmp(AlgoEvtName,"TreeMessage"))  
      dur = sv.Message(AnimStrings[0]);
   else if (!strcmp(AlgoEvtName,"Code"))  
      dur = sv.Code(AnimInts[0]);
   else
      dur = sv.CheckInput();

   for (i=1; i<=dur; i++) {
      nv.AnimateAFrame();
      sv.AnimateAFrame();
      }

   return(1);
}






int
SortView::Init(int n)
{
   int edges,count,i,j;
   double x,y,dx,dy;
   Line *left,*right;
   Circle *builder;
   Text *code1,*code2,*code3,*code4,*code5;
   AnimObject *objs[3];

//cout << "***Init " << n << endl;;
   Create("Heap Sort (Tree view)",ConstantAspect,650,500);
   SetCoord(0.0,0.0,1.3,1.0);
   SetBgColor("black");
   edges = (int) (log( (double)n )/log(2.0));

   count = 0;
   dy = 0.6 / double(edges);
   y = 0.9;
   for (i=0; i<=edges; i++) {
       x = dx = 1.0 / double(two_to_the(i) + 1);
       for (j=1; j<=two_to_the(i); j++) {
          tree[count++] = new Loc(x,y);
          x += dx;
       }
       if (count >= n) break;
       y -= dy;
   }

   x = 0.1;
   for (i=0; i< n; i++) {
       spots[i] = new Loc(x, 0.1);
       x += 0.8/double(n-1);
   }


   highlight = new Rectangle(this, 1, 0.78,0.955, 0.48,0.04, "SlateGray",1.0);
   highlight->Originate(time);

   code1 = new Text(this, 1, 0.80, 0.96, "white", "10x20",
                      "Read in data", 0);
   code1->Originate(time);
   code2 = new Text(this, 1, 0.80, 0.92, "white", "10x20",
                      "Build Heap", 0);
   code2->Originate(time);
   code3 = new Text(this, 1, 0.80, 0.88, "white", "10x20",
                      "While (not sorted) do", 0);
   code3->Originate(time);
   code4 = new Text(this, 1, 0.87, 0.84, "white", "10x20",
                      "Swap root and last", 0);
   code4->Originate(time);
   code5 = new Text(this, 1, 0.87, 0.80, "white", "10x20",
                      "Heapify root", 0);
   code5->Originate(time);

   builder = new Circle(this, 0, -0.9,0.95, radius+0.02, "white", 0.0);
   builder->Originate(time);
   left = new Line(this, 0, -0.9-radius-0.02,0.95, -radius,-radius,
                      "white", 0.0, 1.0);
   left->Originate(time);
   right = new Line(this, 0, -0.9+radius+0.02,0.95, radius,-radius,
                      "white", 0.0, 1.0);
   right->Originate(time);
   objs[0] = builder;
   objs[1] = left;
   objs[2] = right;
   heaproot = new Set(this, 3, objs);

   return(5);
}


int
SortView::AddNode(int num, int val)
{
   char 	  str[10];
   double	  x,y,sx,sy,nx,ny;
   Loc           *north,*south;

//cout << "***AddNode " << num << " " << val << endl;
   sprintf(str,"%d",val);
   x = tree[num]->XCoord();
   y = tree[num]->YCoord();
   node[num] = new Circle(this, 1,x,y, radius, "DeepSkyBlue", 1.0);
   node[num]->Originate(time);
   label[num] = new Text(this, 1,x,y, "black", 
                           "lucidasanstypewriter-bold-18", str, 1);
   label[num]->Originate(time);

   if (num != 0) {   // not the root
      north = node[num]->Where(PART_N);
      nx = north->XCoord();
      ny = north->YCoord();
      south = node[(num-1)/2]->Where(PART_S);  // from parent node
      sx = south->XCoord();
      sy = south->YCoord();
      edge[num] = new Line(this, 1,nx,ny, sx-nx,sy-ny, "white",0.5,1.0,0);
      edge[num]->Originate(time);
      }
   return(5);
}


int
SortView::Elevate(int num)
{
   int len;

//cout << "***Elevate " << num << endl;
   Action a1("MOVE", tree[0], spots[num], SPEED);
   len = node[0]->Program(time, &a1);
   len = label[0]->Program(time, &a1);
   if (num != 0)
      { Action a2("MOVE", tree[num], tree[0], SPEED);
        edge[num]->Delete(time+len);
        label[num]->Program(time+len, &a2);
        len += node[num]->Program(time+len, &a2);
      }
   node[0] = node[num];
   label[0] = label[num];
   return(len);
}


int
SortView::HeapPtr(int num)
{
   int len;

//cout << "***HeapPtr " << num << endl;
   Action a1("COLOR", "yellow");
   len = node[num]->Program(time, &a1);

   heapifier = node[num];

   return(len);
}


int
SortView::HeapifyDone()
{
   int len;

//cout << "***HeapifyDone " << endl;
   Action a1("COLOR", "green");
   len = heapifier->Program(time, &a1);
   return(len+5);
}


int
SortView::BHToggle()
{
   int len;

//cout << "***BHStart " << endl;

   Action a1("VIS", 1);
   len = heaproot->Program(time, &a1);
   return(len);
}


int
SortView::BuildPtr(int num)
{
   int len;
   Loc *nw,*now;
   double nx,ny;

//cout << "***BuildPtr " << num << endl;
   now = heaproot->Where(PART_C);
   nw = node[num]->Where(PART_C);
//   nx = nw->XCoord();
//   ny = nw->YCoord();

   Action a1("MOVE", now, nw, 1.0);
   len = heaproot->Program(time, &a1);

   delete(nw);
   delete(now);

   return(len);
}


int
SortView::Done(int num)
{
   int len;

   if (num != 0)   // don't want to do for root
      edge[num]->Delete(time);
   Action a1("COLOR", "gray");
   len = node[num]->Program(time, &a1);

   // delete(edge[num]);
   return(1);
}


int
SortView::CompareLeft(int num)
{
   int len;

//cout << "***CompareLeft " << num << endl;
   Action red("COLOR", "red");
   Action green("COLOR", "green");
   Action yellow("COLOR", "yellow");
   Action *a3 = red.Iterate(3);
   Action *b3 = green.Iterate(3);
   Action *c3 = yellow.Iterate(3);
   Action *con1 = a3->Concatenate(b3);
   Action *flash1 = con1->Iterate(4);
   Action *con2 = a3->Concatenate(c3);
   Action *flash2 = con2->Iterate(4);

   len = node[num]->Program(time, flash2);
   len = node[num*2+1]->Program(time, flash1);   // left child
   delete(a3);
   delete(b3);
   delete(c3);
   delete(con1);
   delete(con2);
   delete(flash1);
   delete(flash2);
   return(len);
}




int
SortView::CompareBoth(int num)
{
   int len;

//cout << "***CompareBoth " << num << endl;
   Action red("COLOR", "red");
   Action yellow("COLOR", "yellow");
   Action green("COLOR", "green");
   Action *a3 = red.Iterate(3);
   Action *b3 = green.Iterate(3);
   Action *c3 = yellow.Iterate(3);
   Action *con1 = a3->Concatenate(b3);
   Action *flash1 = con1->Iterate(4);
   Action *con2 = a3->Concatenate(c3);
   Action *flash2 = con2->Iterate(4);

   len = node[num]->Program(time, flash2);
   len = node[num*2+1]->Program(time, flash1);   // left child
   len = node[num*2+2]->Program(time, flash1);   // right child
   delete(a3);
   delete(b3);
   delete(c3);
   delete(con1);
   delete(flash1);
   delete(con2);
   delete(flash2);
   return(len);
}


int
SortView::Sift(int i, int j)
{
   int len1, len2;
   Circle *tempc;
   Text *tempt;
   Loc *now, *nw;

//cout << "***Sift " << i << " " << j << endl;
   Action a1("MOVE", tree[i], tree[j], SPEED);
   Action a2("MOVE", tree[j], tree[i], SPEED);
   len1 = node[i]->Program(time, &a1);
   len1 = label[i]->Program(time, &a1);
   len1 = node[j]->Program(time, &a2);
   len1 = label[j]->Program(time, &a2);
//   now = heapifier->Where(PART_E);
//   nw = node[j]->Where(PART_W);

//   Action a3("MOVE", now, nw, SPEED);
//   len2 = heapifier->Program(time, &a3);
len2 = 0;

   tempc = node[i];
   node[i] = node[j];
   node[j] = tempc;
   tempt = label[i];
   label[i] = label[j];
   label[j] = tempt;

//   delete(nw);
//   delete(now);

   return((len1>len2) ? len1 : len2);
}




int
SortView::Exchange(int i, int j)
{
   int len1,len2;
   Circle *tempc;
   Text *tempt;
   Loc spot(1.1,0.5);

//cout << "***Exchange " << i << " " << j << endl;
   Action a1("MOVE", tree[i], &spot, SPEED);
   Action a2("MOVE", &spot, tree[j], SPEED);
   Action a3("MOVE", tree[j], &spot, SPEED);
   Action a4("MOVE", &spot, tree[i], SPEED);
   len1 = node[i]->Program(time, &a1);
   len1 = label[i]->Program(time, &a1);
   len2 = node[i]->Program(time+len1, &a2);
   len2 = label[i]->Program(time+len1, &a2);
   len1 = node[j]->Program(time, &a3);
   len1 = label[j]->Program(time, &a3);
   len2 = node[j]->Program(time+len1, &a4);
   len2 = label[j]->Program(time+len1, &a4);
   tempc = node[i];
   node[i] = node[j];
   node[j] = tempc;
   tempt = label[i];
   label[i] = label[j];
   label[j] = tempt;
   return(len1+len2);
}




int
SortView::Code(int line)
{
   int len;
   Loc *loc1, *loc2;   

   loc1 = highlight->Where(PART_SW);
   if (line == 1)
      loc2 = new Loc(0.78, 0.955);
   else if (line == 2)
      loc2 = new Loc(0.78, 0.915);
   else if (line == 3)
      loc2 = new Loc(0.78, 0.875);
   else if (line == 4)
      loc2 = new Loc(0.78, 0.835);
   else if (line == 5)
      loc2 = new Loc(0.78, 0.795);

   Action a("MOVE",loc1,loc2,8);
   len = highlight->Program(time, &a);
   delete(loc1);
   delete(loc2);
   return(len);
}   



int
SortView::Message(char *str)
{
   static Text *msg = NULL;

   if (msg)
      msg->Delete(time);
   msg = new Text(this, 1, 0.5, 0.2, "white", "12x24",
            str, 1);
   msg->Originate(time);
   return(1);
}



void
SortView::AnimateAFrame()
{
   time = Animate(time, 1);
}









int
Names::Init(int n)
{
   Create("Heapsort (Array View)", CoordStretch, 700, 120);
   SetBgColor("black");
   numvals = n;
   barrier = new Rectangle(this, 1, 0.98,0.1, 0.01,0.8, "magenta", 1.0);
   barrier->Originate(time);
   Text *sorted = new Text(this, 1, 2.0, 2.0, "magenta", "10x20",
            "Sorted ->", 1);
   sorted->Originate(time);
   Text *unsorted = new Text(this, 1, 2.0, 2.0, "magenta", "10x20",
            "<- Unsorted", 1);
   unsorted->Originate(time);
   sorted->AttachTo(barrier, PART_W, PART_S, 0.02, 0.0);
   unsorted->AttachTo(barrier, PART_E, PART_S, -0.02, 0.0);
   return(1);
}



/* save the values in the array */

int
Names::Input(int index,int val)
{
   int len;
   static double x = 0.05;
   double spacing;
   char str[5];

   spacing = 0.9 / (double) (numvals-1);

   values[index] = val;
   sprintf(str,"%d",values[index]);
   labels[index] = new Text(this,1, x,0.5,"white","10x20",str,1);
   labels[index]->Originate(0);
   x += spacing;

   Action a("DELAY",1);
   len = labels[index]->Program(time,&a);
   return(len);
}




int
Names::Highlight(int index)
{
   int len;
   Loc *loc;
   double x,y;
   Polygon *pointer;
   double vx[2],vy[2];

   loc = labels[index]->Where(PART_S);
   x = loc->XCoord();
   y = loc->YCoord();
   vx[0] = -0.04;  vx[1] = 0.04;
   vy[0] = -0.2;  vy[1] = -0.2;

   pointer = new Polygon(this,1, x,y, 3, vx,vy, "cyan", 1.0);
   pointer->Originate(time);

   Action a("DELAY",5);
   len = pointer->Program(time,&a);
   pointer->Delete(time+5);
   return(len + 1);
}




/* make the two rectangles exchange positions on the screen in one */
/* simultaneous movement                                           */

int
Names::Exchange(int delay, int i, int j)
{
   Text *tempt;
   LocPtr loc1,loc2;
   int len;

   loc1 = labels[i]->Where(PART_C);
   loc2 = labels[j]->Where(PART_C);
   Action a("MOVE",loc1,loc2,CLOCKWISE);
   Action *b = a.Rotate(180);
   len = labels[i]->Program(time+delay,&a);
   labels[j]->Program(time+delay,b);

   tempt = labels[i];
   labels[i] = labels[j];
   labels[j] = tempt;

   delete b;
   return(len);
}


int
Names::Done(int pos)
{
   int len;
   Loc *loc1, *loc2;   

   loc1 = barrier->Where(PART_E);
   loc2 = labels[pos]->Where(PART_W);
   Action a("MOVE",loc1,loc2,4);
   len = barrier->Program(time, &a);
   delete(loc1);
   delete(loc2);

   return(len);
}



int
Names::Message(char *str)
{
   static Text *msg = NULL;

   if (msg)
      msg->Delete(time);
   msg = new Text(this, 1, 0.5, 0.97, "white", "10x20", str, 1);
   msg->Originate(time);
   return(1);
}



void
Names::AnimateAFrame()
{
   time = Animate(time, 1);
}


