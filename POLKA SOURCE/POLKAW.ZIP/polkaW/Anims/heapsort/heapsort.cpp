#include <iostream.h>
#include <string.h>
#include "polka.H"
#include "heapsort.H"

extern MyAnimator heapsort;

void BuildHeap();
void Heapify(int);

int Heap[129];
int heapsize;

main(int argc, char *argv[])
{
   int i, temp, length;
   char label[50];



   heapsort.RegisterAlgoEvt("Init","d");
   heapsort.RegisterAlgoEvt("AddNode","dd");
   heapsort.RegisterAlgoEvt("SetupTree","dd");
   heapsort.RegisterAlgoEvt("Elevate","d");
   heapsort.RegisterAlgoEvt("Heapify","d");
   heapsort.RegisterAlgoEvt("HeapifyDone",NULL);
   heapsort.RegisterAlgoEvt("BuildHeap","d");
   heapsort.RegisterAlgoEvt("BHStart",NULL);
   heapsort.RegisterAlgoEvt("BHFinish",NULL);
   heapsort.RegisterAlgoEvt("CompareLeft","d");
   heapsort.RegisterAlgoEvt("CompareBoth","d");
   heapsort.RegisterAlgoEvt("Exchange","dd");
   heapsort.RegisterAlgoEvt("Sift","dd");
   heapsort.RegisterAlgoEvt("Finished","d");
   heapsort.RegisterAlgoEvt("Code","d");
   heapsort.RegisterAlgoEvt("ArrayMessage","s");
   heapsort.RegisterAlgoEvt("TreeMessage","s");
   heapsort.RegisterAlgoEvt("WAIT",NULL);

   cout << "Input number of elts to be heap-sorted" << endl;
   cin >> heapsize;

   length = heapsize;
   heapsort.SendAlgoEvt("Init",heapsize);

   heapsort.SendAlgoEvt("ArrayMessage","Reading in Array");

   cout << "Enter the elements" << endl;
   for (i=0; i<heapsize; ++i)
      { cin >> Heap[i];
        heapsort.SendAlgoEvt("AddNode",i,Heap[i]);
      }
   heapsort.SendAlgoEvt("ArrayMessage"," ");

   for (i=0; i<heapsize; ++i) {
      heapsort.SendAlgoEvt("SetupTree",i,Heap[i]);
      }

   heapsort.SendAlgoEvt("Code",2);
   BuildHeap();
   heapsort.SendAlgoEvt("Code",3);
   for (i=heapsize-1; i>0; i--) {
      temp = Heap[i];
      Heap[i] = Heap[0];
      Heap[0] = temp;
      heapsort.SendAlgoEvt("TreeMessage", "Heap has been built");
      heapsort.SendAlgoEvt("Code",4);
      heapsort.SendAlgoEvt("TreeMessage", "Swap root and last leaf");
      heapsort.SendAlgoEvt("Exchange",0,i);
      heapsort.SendAlgoEvt("Finished",i);
      heapsort.SendAlgoEvt("TreeMessage", " ");
      heapsize--;
      heapsort.SendAlgoEvt("Code",5);
      heapsort.SendAlgoEvt("Heapify", 0);
      Heapify(0);
      heapsort.SendAlgoEvt("HeapifyDone");
      }
   heapsort.SendAlgoEvt("Finished",0);

   cout << "Sorted array is " << endl;
   for (i=0; i<length; ++i)
      cout << Heap[i] << " ";
   cout << endl;

   while (1)
      heapsort.SendAlgoEvt("WAIT");
}



void
BuildHeap()
{
   int i;

   heapsort.SendAlgoEvt("BHStart");
   for (i=heapsize-1; i>=0; i--) {
      heapsort.SendAlgoEvt("BuildHeap",i);
      heapsort.SendAlgoEvt("Heapify", i);
      Heapify(i);
      heapsort.SendAlgoEvt("HeapifyDone");
      }
   heapsort.SendAlgoEvt("BHFinish");
}




void
Heapify(int pos)
{
   int largest, left, right, i, temp;

   left = 2*pos + 1;
   right = 2*pos + 2;

   heapsort.SendAlgoEvt("TreeMessage", "Compare node values");
   if (right < heapsize)
      heapsort.SendAlgoEvt("CompareBoth",pos);
   else if (left < heapsize)
      heapsort.SendAlgoEvt("CompareLeft",pos);
   heapsort.SendAlgoEvt("TreeMessage", " ");
  
   if ((left<heapsize) && (Heap[left] > Heap[pos]))
         largest = left;
      else
         largest = pos;

   if ((right<heapsize) && (Heap[right] > Heap[largest]))
         largest = right;

   if (largest != pos) {
      temp = Heap[pos];
      Heap[pos] = Heap[largest];
      Heap[largest] = temp;
      heapsort.SendAlgoEvt("TreeMessage", "Swap with largest value");
      heapsort.SendAlgoEvt("Sift",pos,largest);
      heapsort.SendAlgoEvt("TreeMessage", " ");
      Heapify(largest);
      }
   else 
      heapsort.SendAlgoEvt("TreeMessage", "No swap");
}





