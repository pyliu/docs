#include <iostream.h>
#include <string.h>
#include "polka.H"
#include "quick.H"


void qquicksort(int,int);


extern MyAnimator qs_anim;
int a[200],n;

main(int argc, char *argv[])
{
   int count;

   cout << "Quicksort" << endl;

   qs_anim.RegisterAlgoEvt("Init","d");
   qs_anim.RegisterAlgoEvt("Input","dd");
   qs_anim.RegisterAlgoEvt("Display","d");
   qs_anim.RegisterAlgoEvt("Compare","dd");
   qs_anim.RegisterAlgoEvt("Exchange","dd");
   qs_anim.RegisterAlgoEvt("ExchangePartition","dd");
   qs_anim.RegisterAlgoEvt("PartitionVal","dd");
   qs_anim.RegisterAlgoEvt("PartitionDone","d");
   qs_anim.RegisterAlgoEvt("Range","dd");
   qs_anim.RegisterAlgoEvt("LoPtr","d");
   qs_anim.RegisterAlgoEvt("LoPtrDone","d");
   qs_anim.RegisterAlgoEvt("HiPtr","d");
   qs_anim.RegisterAlgoEvt("HiPtrDone","d");
   qs_anim.RegisterAlgoEvt("InPlace","d");
   qs_anim.RegisterAlgoEvt("Comment","s");
   qs_anim.RegisterAlgoEvt("Wait",NULL);



   cout << "Input number of elts in array (max of 200)" << endl;
   cin >> n;

   qs_anim.SendAlgoEvt("Init",n);

   cout << "Enter the elements (must be ints from 1 -> " << n << endl;
   for (count=0; count<n; ++count)
      { cin >> a[count];
	    qs_anim.SendAlgoEvt("Input",count,a[count]);
      }

   qs_anim.SendAlgoEvt("Display",n);
   qquicksort(0,n-1);

   for (count=0; count<n; ++count)
       cout << a[count] << " " ;
	   cout << endl;

   while (1)
      qs_anim.SendAlgoEvt("Wait");
}


void
qquicksort(int lo, int hi)
{
   int i,j,part,temp;
   char msg[100];

   sprintf(msg,"Quicksort (%d -> %d)",lo,hi);
   qs_anim.SendAlgoEvt("Comment",msg);

   if (hi > lo) {
      qs_anim.SendAlgoEvt("Range",lo,hi);
      if (lo == hi-1) {
	 if (a[lo] > a[hi]) {
            temp = a[lo];
            a[lo] = a[hi];
            a[hi] = temp;
            qs_anim.SendAlgoEvt("Exchange",lo,hi);
            }
         qs_anim.SendAlgoEvt("PartitionDone",lo);
         return;
         }

      qs_anim.SendAlgoEvt("PartitionVal",hi,a[hi]);
      part = a[hi];
      i = lo-1;
      j = hi;

      do { 
         do {
           i++;
           qs_anim.SendAlgoEvt("LoPtr", i);
           }
         while (a[i] < part);
         qs_anim.SendAlgoEvt("LoPtrDone", i);
         do {
           j--;
           qs_anim.SendAlgoEvt("HiPtr", j);
           }
         while ((j>i) && (a[j] > part));
         qs_anim.SendAlgoEvt("HiPtrDone", j);
         if (j <= i) break;
         qs_anim.SendAlgoEvt("Exchange",i,j);
         temp = a[i];
         a[i] = a[j];
         a[j] = temp;
         }
      while (j>i);

      qs_anim.SendAlgoEvt("ExchangePartition",i,hi);
      temp = a[i];
      a[i] = a[hi];
      a[hi] = temp;

      qs_anim.SendAlgoEvt("PartitionDone",i);

      qquicksort(lo, i-1);
      qquicksort(i+1, hi);
      }
   else if (hi == lo)  {
      qs_anim.SendAlgoEvt("Range",lo,hi);
      qs_anim.SendAlgoEvt("PartitionDone",lo);
      }
}
