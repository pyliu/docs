#include <iostream.h>
#include <string.h>
#include "polka.H"
#include "quick.H"

#define MAX(A,B)  ((A)>(B) ? (A) : (B))



MyAnimator qs_anim;


const double DISTANCE = 0.005;

int
MyAnimator::Controller()
{
   int len1, len2, len3, i;
//   cout << "          In controller aen=" << AlgoEvtName << "\n";

   len1 = len2 = len3 = 0;
   if (!strcmp(AlgoEvtName,"Init")) {
      len1 = arrayview.Init();
      len2 = dotsview.Init();
      len3 = valueview.Init(AnimInts[0]);
   }
   else if (!strcmp(AlgoEvtName,"Input")) {
      len1 = arrayview.Input(AnimInts[0],AnimInts[1]);
      len2 = dotsview.Input(AnimInts[0],AnimInts[1]);
      len3 = valueview.Input(AnimInts[0],AnimInts[1]);
   }
   else if (!strcmp(AlgoEvtName,"Display")) {
      len1 = arrayview.Ready(AnimInts[0]);
      len2 = dotsview.Draw(AnimInts[0]);
   }
   else if (!strcmp(AlgoEvtName,"Exchange")) { 
      len1 = arrayview.Exchange(AnimInts[0],AnimInts[1]);
      len2 = dotsview.Exchange(AnimInts[0],AnimInts[1]);
      len3 = valueview.Exchange(AnimInts[0],AnimInts[1]);
   }
   else if (!strcmp(AlgoEvtName,"ExchangePartition")) { 
      len1 = arrayview.ExchangePartition(AnimInts[0],AnimInts[1]);
      len2 = dotsview.Exchange(AnimInts[0],AnimInts[1]);
      len3 = valueview.Exchange(AnimInts[0],AnimInts[1]);
   }
   else if (!strcmp(AlgoEvtName,"PartitionVal")) { 
      len1 = arrayview.ShowPartition(AnimInts[0],AnimInts[1]);
      len2 = dotsview.Partition(AnimInts[0],AnimInts[1]);
   }
   else if (!strcmp(AlgoEvtName,"PartitionDone")) { 
      len1 = arrayview.PartitionDone(AnimInts[0]);
      len2 = dotsview.PartitionDone(AnimInts[0]);
   }
   else if (!strcmp(AlgoEvtName,"Range")) { 
      len1 = arrayview.Range(AnimInts[0],AnimInts[1]);
      len2 = dotsview.Range(AnimInts[0],AnimInts[1]);
   }
   else if (!strcmp(AlgoEvtName,"LoPtr")) { 
      len1 = arrayview.LoPtrChange(AnimInts[0]);
   }
   else if (!strcmp(AlgoEvtName,"LoPtrDone")) { 
      len1 = arrayview.LoPtrDone(AnimInts[0]);
   }
   else if (!strcmp(AlgoEvtName,"HiPtr")) { 
      len1 = arrayview.HiPtrChange(AnimInts[0]);
   }
   else if (!strcmp(AlgoEvtName,"HiPtrDone")) { 
      len1 = arrayview.HiPtrDone(AnimInts[0]);
   }
   else if (!strcmp(AlgoEvtName,"Comment")) { 
      len1 = arrayview.Comment(AnimStrings[0]);
   }
   else 
      arrayview.CheckInput();

   for (i=0; i<MAX( MAX(len1,len2), len3); i++) {
      arrayview.DoAnimationFrame();
      dotsview.DoAnimationFrame();
      valueview.AnimateAFrame();
   }

   return(1);
}




/******************************************/
/*                                        */
/*        Array view                      */
/*                                        */
/******************************************/


int
ArrayView::Init()
{
   Create("Quicksort --  Array View",CoordStretch,600,600);
   return (1);
}



/* save the values in the array */

int
ArrayView::Input(int index,int val)
{
   values[index] = val;
   if (val > max) max=val;
   if (val < min) min=val;
   return(1);
}




/* Draw the array as a row of rectangles with the heights corresponding */
/* to the value of each array element.					*/

int
ArrayView::Ready(int n)
{
   int i;
   RectangleGroup objs;

   strcpy(objs.color,"black");
   objs.spacetype = SpacingSame;
   objs.horiz = 1;
   objs.align = AlignBottom;
   objs.fill = 1.0;
   objs.useints = 1;
   objs.intvals = values;
   objs.intmin = min;
   objs.intmax = max;
   objs.Make(this,blocks,n,0.05,0.5,0.95,0.95);

   for (i=0; i<n; ++i)
      blocks[i]->Originate(time);

   loBack = new Rectangle(this,1,0.0,0.0,0.07,0.03,"white",1.0);
   loBack->Originate(time);
   hiBack = new Rectangle(this,1,0.0,0.0,0.07,0.03,"white",1.0);
   hiBack->Originate(time);

   loArrow = new Line(this,1,0.05,0.05,0.0,-0.08,"red",0.5,1.0,2);
   loArrow->Originate(time);
   hiArrow = new Line(this,1,0.95,0.1,0.0,-0.05,"red",0.5,1.0,2);
   hiArrow->Originate(time);

   loPtr = new Text(this,1,0.02,0.03,"black",
                      "lucidasanstypewriter-bold-18","Lo",0);
   loPtr->Originate(time);
   hiPtr = new Text(this,1,0.9,0.03,"black",
                      "lucidasanstypewriter-bold-18","Hi",0);
   hiPtr->Originate(time);

   loPtr->AttachTo(loArrow, PART_N, PART_S, 0.0, 0.01);
   hiPtr->AttachTo(hiArrow, PART_N, PART_S, 0.0, 0.01);
   loBack->AttachTo(loPtr, PART_C, PART_C, 0.0, 0.0);
   hiBack->AttachTo(hiPtr, PART_C, PART_C, 0.0, 0.0);

   boundary = NULL;

   return(10);
}



int
ArrayView::ShowPartition(int pos, int)
{
   int len;
   Action colorremove("COLOR","black");
   Action col("COLOR","purple");
   static Rectangle *part_rect = NULL;

//   blocks[pos]->GetValues(NULL,NULL,NULL,NULL,&width,&height,NULL,NULL);
//   lopart = new Rectangle(this,1,-1.0,-1.0,width,height,"violet",0.0);
//   hipart = new Rectangle(this,1,-1.0,-1.0,width,height,"violet",0.0);
//   lopart->Originate(time);
//   hipart->Originate(time);
//   lopart->AttachTo(loArrow,PART_S,PART_N);
//   hipart->AttachTo(hiArrow,PART_S,PART_N);

   if (part_rect) 
      part_rect->Program(time,&colorremove);
      
   len = blocks[pos]->Program(time,&col);
   part_rect = blocks[pos];
   return(len);
}



int
ArrayView::PartitionDone(int pos)
{
   int len;

//   Action col("COLOR","black");
//   len = blocks[pos]->Program(time,&col);

   if (boundary) {
      boundary->Delete(time);
      boundary = NULL;
      }
   len = 1;
   Message("  ");
   return(len);
}



int
ArrayView::Range(int lo, int hi)
{
   int initlen,len;
   double lowx,highx,lowy;
   LocPtr loc1,loc2,loc3,loc4;
   Action a("LOWER",1),*slider;
   Action *move;
   Line *rangeline;
   double rangeline_y_start = 0.5;
   static double rangeline_y = 0.37;

   loc1 = blocks[lo]->Where(PART_SW);
   loc2 = blocks[hi]->Where(PART_SE);

   lowx = loc1->XCoord();
   highx = loc2->XCoord();
   lowy = loc1->YCoord();
   delete(loc1);
   delete(loc2);

   rangeline = new Line(this,1,lowx,rangeline_y_start,highx-lowx,0.0,
                             "black",0.5,1.0);
   loc3 = new Loc(0.0,rangeline_y_start);
   loc4 = new Loc(0.0,rangeline_y);
   slider = new Action("MOVE",loc3,loc4,0.01);
   rangeline->Originate(time);
   initlen = rangeline->Program(time+1,slider);
//   rangeline_y -= 0.005;
   rangeline_y -= 0.01;

   delete(loc3);
   delete(loc4);

   len = 0;
   if (lo < hi) {
      loc1 = loArrow->Where(PART_N);
      loc2 = blocks[lo]->Where(PART_S);
      move = new Action("MOVE",loc1,loc2,1);
      loArrow->Program(time+initlen,move);
      delete(move);
      delete(loc1);
      delete(loc2);
      loc1 = hiArrow->Where(PART_N);
      loc2 = blocks[hi-1]->Where(PART_S);
      move = new Action("MOVE",loc1,loc2,1);
      len = hiArrow->Program(time+initlen,move);
      delete(move);
      delete(loc1);
      delete(loc2);

      boundary = new Rectangle(this,1,lowx,lowy,highx-lowx,0.95-lowy,
                              "gray",0.5);

      boundary->Originate(time+1);
      boundary->Program(time+1,&a);
      }

   return(initlen+len);
}



int
ArrayView::LoPtrChange(int pos)
{
   int len;
   Action *move;
   Action color("COLOR","LightPink");
   LocPtr loc1,loc2;

   loc1 = loArrow->Where(PART_N);
   loc2 = blocks[pos]->Where(PART_S);
   move = new Action("MOVE",loc1,loc2,DISTANCE/2.0);
   len = loArrow->Program(time,move);
   loBack->Program(time,&color);

   delete move;
   delete loc1;
   delete loc2;

   return(len);
}



int
ArrayView::LoPtrDone(int pos)
{
   int len;
   Action color("COLOR","green");
   Action remove("COLOR","white");

   len = blocks[pos]->Program(time,&color);
   loBack->Program(time,&remove);

   return(len);
}



int
ArrayView::HiPtrChange(int pos)
{
   int len;
   Action *move;
   Action color("COLOR","LightPink");
   LocPtr loc1,loc2;

   loc1 = hiArrow->Where(PART_N);
   loc2 = blocks[pos]->Where(PART_S);
   move = new Action("MOVE",loc1,loc2,DISTANCE/2.0);
   len = hiArrow->Program(time,move);
   hiBack->Program(time,&color);

   delete move;
   delete loc1;
   delete loc2;

   return(len);
}



int
ArrayView::HiPtrDone(int pos)
{
   int len;
   Action remove("COLOR","white");

   len = hiBack->Program(time,&remove);

   return(len);
}



/* Make the two rectangles exchange positions on the screen in one */
/* simultaneous movement					   */

int
ArrayView::Exchange(int i, int j)
{
   Rectangle *tempr;
   LocPtr loc1,loc2;
   Action col1("COLOR","green");
   Action col2("COLOR","black");
   Action raise("RAISE",1);
   int len;

   loc1 = blocks[i]->Where(PART_SW);
   loc2 = blocks[j]->Where(PART_SW);
   Action a("MOVE",loc1,loc2,2.0*DISTANCE);
   Action *b = a.Reverse();
   len = blocks[i]->Program(time,&a);
   blocks[j]->Program(time,b);
   blocks[i]->Program(time,&col1);
   blocks[j]->Program(time,&col1);
   blocks[i]->Program(time,&raise);
   blocks[j]->Program(time,&raise);
   len += blocks[i]->Program(time+len,&col2);
   blocks[j]->Program(time+len,&col2);

   tempr = blocks[i];
   blocks[i] = blocks[j];
   blocks[j] = tempr;

   delete b;
   return(len);
}



/* Assumes the partition is in the j spot                          */
/*                      					   */

int
ArrayView::ExchangePartition(int i, int j)
{
   Rectangle *tempr;
   LocPtr loc1,loc2;
   Action col1("COLOR","green");
   Action col2("COLOR","black");
   Action raise("RAISE",1);
   int len;

   loc1 = blocks[i]->Where(PART_SW);
   loc2 = blocks[j]->Where(PART_SW);
   Action a("MOVE",loc1,loc2,DISTANCE);
   Action *b = a.Reverse();
   len = blocks[i]->Program(time,&a);
   blocks[j]->Program(time,b);
   blocks[i]->Program(time,&col1);
   blocks[i]->Program(time,&raise);
   blocks[j]->Program(time,&raise);
   len += blocks[i]->Program(time+len,&col2);
//   blocks[j]->Program(time+len,&col2);

   tempr = blocks[i];
   blocks[i] = blocks[j];
   blocks[j] = tempr;

   delete b;
   return(len);
}



int
ArrayView::Message(char *str)
{
   static Text *msg = NULL;

   if (msg)
      msg->Delete(time);
   msg = new Text(this, 1, 0.65, 0.04, "black", "12x24",
            str, 0);
   msg->Originate(time);
   return(1);
}


int
ArrayView::Comment(char *str)
{
   static Text *msg = NULL;

   if (msg)
      msg->Delete(time);
   msg = new Text(this, 1, 0.1, 0.04, "black", "12x24",
            str, 0);
   msg->Originate(time);
   return(1);
}






void
ArrayView::DoAnimationFrame()
{
   time = Animate(time, 1);
}




/******************************************/
/*                                        */
/*             Dots view                  */
/*                                        */
/******************************************/


int
DotsView::Init()
{
   Create("Quicksort -- Dots view",CoordStretch,300,300);
   return(1);
}



/* save the values in the array */

int
DotsView::Input(int index, int val)
{
   values[index] = val;
   return(1);
}





int
DotsView::Draw(int n)
{
   double lx;
   int i,len;

   spacing = 1.0 / (double) n;
   lx = 0.0;

   for (i=0; i<n; ++i)
      { elts[i] = new Rectangle(this,1,
                                lx,(double)(values[i])*spacing - spacing,
                                spacing,spacing,"black",1.0);
        lx += spacing;
        elts[i]->Originate(0);
      }

   Action a("DELAY", 10);
   len = elts[0]->Program(time,&a);
   return(10);
}



int
DotsView::Partition(int pos, int val)
{
   partition = new Line(this,1,
                        0.0,double(spacing*val) - (spacing/2.0),1.0,0.0,
                        "violet",0.5,1.0);
   partition->Originate(time);
   return(1);
}


int
DotsView::PartitionDone(int)
{
   if (partition)
      partition->Delete(time);
   partition = NULL;
   return(1);
}



int
DotsView::Range(int lo, int hi)
{
   int len;
   double lowx,highx,lowy,highy;
   LocPtr loc1,loc2;
   Action a("LOWER",1);
   static Rectangle *boundary = NULL;

   if (boundary)
      boundary->Delete(time);

//   loc1 = elts[lo]->Where(PART_SW);
//   loc2 = elts[hi]->Where(PART_NE);

//   lowx = loc1->XCoord();
//   highx = loc2->XCoord();
//   lowy = loc1->YCoord();
//   highy = loc2->YCoord();

   boundary = new Rectangle(this,1,lo*spacing,lo*spacing,
                  ((hi+1)*spacing)-(lo*spacing),((hi+1)*spacing)-(lo*spacing),
                  "gray",0.5);

   boundary->Originate(time+1);
   boundary->Program(time+1,&a);

//   delete loc1;
//   delete loc2;

   return(2);
}





int
DotsView::Exchange(int p1, int p2)
{
   int len;
   double x1,y1,x2,y2;
   Loc *loc1f,*loc2f;
   Rectangle *temp;

   loc1f = elts[p1]->Where(PART_C);
   x1 = loc1f->XCoord();
   y1 = loc1f->YCoord();
   loc2f = elts[p2]->Where(PART_C);
   x2 = loc2f->XCoord();
   y2 = loc2f->YCoord();
   Loc loc1t(x2, y1);
   Loc loc2t(x1, y2);

   Action a1("MOVE", loc1f, &loc1t, 2.0*DISTANCE);
   Action a2("MOVE", loc2f, &loc2t, 2.0*DISTANCE);
   
   Action red("COLOR", "red");
   Action black("COLOR", "black");

   elts[p1]->Program(time,&red);
   elts[p2]->Program(time,&red);
   len = elts[p1]->Program(time,&a1);
   len = elts[p2]->Program(time,&a2);

   elts[p1]->Program(time,&black);
   elts[p2]->Program(time,&black);


   temp = elts[p1];
   elts[p1] = elts[p2];
   elts[p2] = temp;
   delete(loc1f);
   delete(loc2f);

   return(len);
}




void
DotsView::DoAnimationFrame()
{
   time = Animate(time, 1);
}







/***********************************************************/





int
ValueView::Init(int n)
{
   Create("Quicksort (Array View)", CoordStretch, 900, 130);
   SetBgColor("white");
   numvals = n;
   return(1);
}



/* save the values in the array */

int
ValueView::Input(int index,int val)
{
   int len;
   static double x = 0.05;
   double spacing;
   char str[5];

   spacing = 0.9 / (double) (numvals-1);

   values[index] = val;
   sprintf(str,"%d",values[index]);
   labels[index] = new Text(this,1, x,0.5,"black","10x20",str,1);
   labels[index]->Originate(0);
   x += spacing;

   Action a("DELAY",1);
   len = labels[index]->Program(time,&a);
   return(len);
}



/* make the two rectangles exchange positions on the screen in one */
/* simultaneous movement                                           */

int
ValueView::Exchange(int i, int j)
{
   Text *tempt;
   LocPtr loc1,loc2;
   int len;

   loc1 = labels[i]->Where(PART_C);
   loc2 = labels[j]->Where(PART_C);
   Action a("MOVE",loc1,loc2,2.0*DISTANCE);
   Action *b = a.Rotate(180);
   len = labels[i]->Program(time,&a);
   labels[j]->Program(time,b);

   tempt = labels[i];
   labels[i] = labels[j];
   labels[j] = tempt;

   delete b;
   return(len);
}




int
ValueView::Message(char *str)
{
   static Text *msg = NULL;

   if (msg)
      msg->Delete(time);
   msg = new Text(this, 1, 0.5, 0.97, "black", "10x20", str, 1);
   msg->Originate(time);
   return(1);
}



void
ValueView::AnimateAFrame()
{
   time = Animate(time, 1);
}


