#include <iostream.h>
// added
#include <time.h>
#include <stdio.h>
//
//#include <stream.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <assert.h>
#include <math.h>
#include "polka.H"
//#include <polka.H>
#include "prim.H"


/**********************************************************************/

extern MinHeap m;

/**********************************************************************/

static char *color_names[] =
{
  "black",
  "yellow",
  "red",
  "green",
};

/**********************************************************************/

int MyAnimator::Controller() 
{
  //cout << "In controller aen=" << AlgoEvtName << endl;
  
  if (!strcmp(AlgoEvtName,"Init")) 
    {
      v.init();
      h.init();
    }
  else if (!strcmp(AlgoEvtName,"AddGraphNode"))
    v.addGraphNode(AnimInts[0],AnimDoubles[0],
		   AnimDoubles[1],AnimStrings[0]);
  else if (!strcmp(AlgoEvtName,"AddGraphEdge"))
    v.addGraphEdge(AnimInts[0],AnimInts[1],AnimInts[2]);
  else if (!strcmp(AlgoEvtName,"Migrate"))
    v.migrate(AnimInts[0],AnimInts[1]);
  else if (!strcmp(AlgoEvtName,"ChangeWeight"))
    v.changeWeight(AnimInts[0],AnimInts[1]);
  else if (!strcmp(AlgoEvtName,"SwapNodes"))
    v.swapNodes(AnimInts[0],AnimInts[1]);
  else if (!strcmp(AlgoEvtName,"Connect"))
    v.connect(AnimInts[0],AnimInts[1]);
  else if (!strcmp(AlgoEvtName,"Disconnect"))
    v.disconnect(AnimInts[0],AnimInts[1]);
  else if (!strcmp(AlgoEvtName,"ShowComparison"))
    v.showComparison(AnimInts[0],AnimInts[1]);
  else if (!strcmp(AlgoEvtName,"Highlight"))
    return v.highlight(AnimInts[0],AnimInts[1],AnimInts[2]);
  else if (!strcmp(AlgoEvtName,"ShowGhosts"))
    v.showGhosts(AnimInts[0]);
  else if (!strcmp(AlgoEvtName,"HideGhosts"))
    v.hideGhosts(AnimInts[0]);
  else if (!strcmp(AlgoEvtName,"ShowInstruction"))
    v.showInstruction(AnimStrings[0]);
  else if (!strcmp(AlgoEvtName,"GoBack"))
    v.goBack(AnimInts[0]);
  else if (!strcmp(AlgoEvtName,"MoveToTop"))
    v.moveToTop(AnimInts[0]);
  else if (!strcmp(AlgoEvtName,"RemoveInstruction"))
    v.removeInstruction();
  else if (!strcmp(AlgoEvtName,"AddToMST"))
    v.addToMST(AnimInts[0],AnimInts[1]);
  else if (!strcmp(AlgoEvtName,"AddHeapNode"))
    h.addHeapNode(AnimInts[0],AnimStrings[0],AnimInts[1]);
  else if (!strcmp(AlgoEvtName,"AddHeap"))
    h.addHeap();
  else if (!strcmp(AlgoEvtName,"GhostifyEdges"))
    v.ghostifyEdges();
  else if (!strcmp(AlgoEvtName,"Animate"))
    {
      h.animate();
      v.animate();
    }
  else
    v.CheckInput();
  return(1);
}

/**********************************************************************/

int MyAnimator::pickStartNode()
{
  return v.pickStartNode();
}

/**********************************************************************/

int myView::init()
{
  Create("Prims Minimum Spanning Tree Algorithm",CoordStretch,600,600);
  SetBgColor("ivory2");
  
  // create all locs for heap
  double x = 0.5;
  double y = 0.5; 
  int index = 0;
  heapLocations[index] = new Loc(x,y);
  index++;
  for (int j=1; j<5; j++)
    {
      int nAcross = (int) pow(2.0,j);
      double perNode =  0.8 / (double)nAcross;
      x = 0.5 - (nAcross/2)*perNode + perNode*0.5;
      y -= (vertical_spacing + (double)2.0*radius);
      for (int k=0; k<nAcross; k++)
	{
	  heapLocations[index] = new Loc(x,y);
	  x += perNode;
	  index++;
	}
    }
  
  for (int i=0; i<MAX; i++)
    for (j=0; j<MAX; j++)
      graphEdges[i][j] = NULL;

  ng = 0;
  return(1);
}

/**********************************************************************/

void myView::addGraphNode(int i, double x, double y, char* label)
{
  assert (i < MAX);
  ng++;
  
  // create the permanent location
  graphLocations[i] = new Loc(x,y);

  // create the circle
  graphCircles[i] = new Circle(this,1,x,y,radius,"black",0.0);
  graphCircles[i]->StoreData((void*)i);
  graphCircles[i]->Originate(time);
  ghostGraphCircles[i] = new Circle(this,0,x,y,radius,"gray",0.0);
  ghostGraphCircles[i]->StoreData((void*)i);
  ghostGraphCircles[i]->Originate(time);
  // create the label
  graphLabels[i] = new Text(this,1,x,y,"black",
			    "Times New Roman|12"/*"-*-new century schoolbook-bold-r-*-*-14-*-*-*-*-*-*-*"*/,label,1);
  graphLabels[i]->StoreData((void*)i);


  graphLabels[i]->Originate(time);
  ghostGraphLabels[i] = new Text(this,0,x,y,"gray80",
			    "Times New Roman|12"/*"-*-new century schoolbook-bold-r-*-*-14-*-*-*-*-*-*-*"*/,label,1);
  ghostGraphLabels[i]->StoreData((void*)i);
    
  ghostGraphLabels[i]->Originate(time);
  double weightX, weightY;
  char weightLabel[1]; weightLabel[0] = '\0';
  weightX = (graphCircles[i]->Where(PART_E))->XCoord() + .005;
  weightY = (graphCircles[i]->Where(PART_E))->YCoord() + .015;
  graphWeights[i] = new Text(this,1,weightX,weightY,"red",
			     "Times New Roman|12"/*"-*-new century schoolbook-medium-r-*-*-10-*-*-*-*-*-*-*"*/,weightLabel,0);
  graphWeights[i]->Originate(time);

  // now create a set object and add the circle and label to it
  AnimObject* objs[3];
  objs[0] = graphCircles[i];
  objs[1] = graphLabels[i];
  objs[2] = graphWeights[i];
  graphNodes[i] = new Set(this,3,objs);
  graphNodes[i]->Originate(time);
  
  // now make it show up..
  time = Animate(time,1);
}

/**********************************************************************/

void myView::addGraphEdge(int i, int j, int weight)
{
  double xi, yi;
  Loc* iLoc = graphCircles[i]->Where(PART_C);
  xi = iLoc->XCoord();
  yi = iLoc->YCoord();
  double xj, yj;
  Loc* jLoc = graphCircles[j]->Where(PART_C);
  xj = jLoc->XCoord();
  yj = jLoc->YCoord();
  
  double dx = xj-xi;
  double dy = yj-yi;
  double length = sqrt(dx*dx + dy*dy);
  double t = radius/length;

  // calculate where the line should actually be drawn
  double x0 = xi + t*dx;
  double y0 = yi + t*dy;
  double x1 = xi + (1.0-t)*dx;
  double y1 = yi + (1.0-t)*dy;

  // create the line
  Line* tmpLine = new Line(this,1,x0,y0,(x1-x0),(y1-y0),
				    "black",0.4,1.0,0);
  tmpLine->StoreData((void*)weight);
  tmpLine->Originate(time);
  graphEdges[i][j] = tmpLine;
  graphEdges[j][i] = tmpLine;

  // now, figure out where to put the label
  // get a random variable between 0.2 and 0.8
/*
  struct timeval nowTime;
  struct timezone tz;
  gettimeofday(&nowTime,&tz);
  floatRV r(nowTime.tv_usec);
  float newT = r.Rand(0.2,0.8);
*/
  srand( (unsigned)(::time(NULL)) );
  float newT = 0.2 + (((float)rand())/((float)RAND_MAX))*(0.8 - 0.2);
//
  double lx = x0 + newT*(x1-x0);
  double ly = y0 + newT*(y1-y0);

  char labelString[10];
  sprintf(labelString,"%d",weight);
  double ndx = -dy;
  double ndy = dx;
  lx = lx + .07*ndx;
  ly = ly + .07*ndy;

  Text* tmpText = new Text(this,1,lx,ly,"red",
			    "Times New Roman|12"/*"lucidasanstypewriter-bold-8"*/,labelString,1);
  tmpText->Originate(time);
  graphEdgeLabels[i][j] = tmpText;
  graphEdgeLabels[j][i] = tmpText;

  time = Animate(time,1);
}

/**********************************************************************/

// move a node from the graph location i to heap location j

void myView::migrate(int i, int j)
{
  int len;
  Loc* l0 = graphLocations[i];
  Loc* l1 = heapLocations[j];
  Action a("MOVE",l0,l1,3*speed);
  len = graphNodes[i]->Program(time,&a);
  time = Animate(time,len);
}

/**********************************************************************/

// assumes that j is above i (parent)

void myView::connect(int i, int j)
{
  int iGraphIndex = m.getGraphIndex(i);
  int jGraphIndex = m.getGraphIndex(j);
  if ((iGraphIndex == -1) || (jGraphIndex == -1))
    return;
  Loc* iLoc = graphCircles[iGraphIndex]->Where(PART_N);
  Loc* jLoc = graphCircles[jGraphIndex]->Where(PART_S);
    
  double x0 = iLoc->XCoord(); double y0 = iLoc->YCoord();
  double x1 = jLoc->XCoord(); double y1 = jLoc->YCoord();

  heapEdges[i] = new Line(this,1,x0,y0,(x1-x0),
			   (y1-y0),"black",0.0,1.0,0);
  heapEdges[i]->Originate(time);
  time = Animate(time,1);

}

/**********************************************************************/

// assumes that j is above i (parent)

void myView::disconnect(int i, int j)
{
  if (j < 0)
    return;
  
  if (heapEdges[i] != NULL)
    {
      heapEdges[i]->Delete(time);
      time = Animate(time,1);
      delete heapEdges[i];
    }
}

/**********************************************************************/

void myView::showComparison(int f, int t)
{
  int len = 0;

  Loc l1(0.0,0.0);
  Loc l2(1.0,0.0);

  Action a3("FILL",&l1,&l2,1);
  Action a4("FILL",&l2,&l1,1);

  Action b("COLOR","white");
  Action a("COLOR","blue");
  ActionPtr c = a.Concatenate(&b);
  ActionPtr d = c->Iterate(6); 
  delete c;
   
  len = graphCircles[t]->Program(time,&a3);
  len = graphCircles[t]->Program(time,&a);
  time = Animate(time,len);
  len = graphEdges[f][t]->Program(time,d);
  len = graphCircles[t]->Program(time,d);
  time = Animate(time,len);
  delete d;
  Action Back0("COLOR","black");
  Action Back1("COLOR","gray80");
  len = graphEdges[f][t]->Program(time,&Back1);
  len = graphCircles[t]->Program(time,&Back0);
  time = Animate(time,len);
  len = graphCircles[t]->Program(time,&a4);
  time = Animate(time,len);


}

/**********************************************************************/

void myView::addToMST(int f, int t)
{
  double xi, yi;
  Loc* iLoc = graphCircles[f]->Where(PART_C);
  xi = iLoc->XCoord();
  yi = iLoc->YCoord();
  double xj, yj;
  Loc* jLoc = graphCircles[t]->Where(PART_C);
  xj = jLoc->XCoord();
  yj = jLoc->YCoord();
  
  double dx = xj-xi;
  double dy = yj-yi;
  double length = sqrt(dx*dx + dy*dy);
  double t0 = radius/length;
  double x0 = xi + t0*dx;
  double y0 = yi + t0*dy;
  double x1 = xi + (1.0-t0)*dx;
  double y1 = yi + (1.0-t0)*dy;
  Line* tmpLine = new Line(this,1,x0,y0,(x1-x0),(y1-y0),
				    "blue",1.0,1.0,2);
  graphEdges[f][t]->Change(time,tmpLine,0);
  time = Animate(time,0);
}

/**********************************************************************/

int myView::highlight(int i, int j, int okay)
{
  Loc l1(0.0,0.0);
  Loc l2(1.0,0.0);

  Action a3("FILL",&l1,&l2,1);
  Action a4("FILL",&l2,&l1,1);

  int iGraphIndex = m.getGraphIndex(i);
  int jGraphIndex = m.getGraphIndex(j);

  if ((iGraphIndex == -1) || (jGraphIndex == -1))
    return 0;

  Circle* iCircle = graphCircles[iGraphIndex];
  Circle* jCircle = graphCircles[jGraphIndex];

  int iColor = color[iGraphIndex];
  int jColor = color[jGraphIndex];

  int flashColor;
  if (okay)
    flashColor = RIGHT_COLOR;
  else
    flashColor = WRONG_COLOR;

  Action bi("COLOR",color_names[flashColor]);
  Action bj("COLOR",color_names[flashColor]);
  Action ai("COLOR","white");
  Action aj("COLOR","white");

  int len;
  len = iCircle->Program(time,&bi);
  jCircle->Program(time,&bj);
  len = iCircle->Program(time,&a3);
  jCircle->Program(time,&a3);
  time = Animate(time,len);

  ActionPtr ci = ai.Concatenate(&bi);
  ActionPtr cj = aj.Concatenate(&bj);
  ActionPtr di = ci->Iterate(4); 
  ActionPtr dj = cj->Iterate(4); 
  delete ci;
  delete cj;
  
  len = iCircle->Program(time,di);
  jCircle->Program(time,dj);
  time = Animate(time,len);

  delete di;
  delete dj;
  Action iBack("COLOR",color_names[iColor]);
  Action jBack("COLOR",color_names[jColor]);
  len = iCircle->Program(time,&iBack);
  jCircle->Program(time,&jBack);
  len = iCircle->Program(time,&a4);
  jCircle->Program(time,&a4);
  time = Animate(time,len);
  
  if (iGraphIndex == start)
    {
      len = iCircle->Program(time,&a3);
      time = Animate(time,len);
    }
  if (jGraphIndex == start)
    {
      len = jCircle->Program(time,&a3);
      time = Animate(time,len);
    }
  return len;
}

/**********************************************************************/

void myView::changeWeight(int i, int w)
{ 
  int iGraphIndex = m.getGraphIndex(i);
  if (iGraphIndex == -1) 
    return;

  char weightLabel[10];
  
  if (w != INFINITY)
    sprintf(weightLabel,"%d",w);
  else
    sprintf(weightLabel,"-");
  
  
  Action a2("ALTER",weightLabel);
  graphWeights[iGraphIndex]->Program(time,&a2);
  time = Animate(time,1);

  // now make it flash to grab attention
  int len = 0;
  Action b("COLOR","black");
  Action a("COLOR","red");
  ActionPtr c = a.Concatenate(&b);
  ActionPtr d = c->Iterate(2); 
  delete c;
  
  len = graphWeights[iGraphIndex]->Program(time,d);
  time = Animate(time,len);
  delete d;
  Action Back("COLOR","black");
  len = graphWeights[iGraphIndex]->Program(time,&Back);
  time = Animate(time,len);
}

/**********************************************************************/

void myView::moveToTop(int i)
{  
  int iGraphIndex = m.getGraphIndex(i);
  if (iGraphIndex == -1)
    return;
  Loc* l0 = heapLocations[i];
  Loc* l1 = heapLocations[0];
  Action a("MOVE",l0,l1,speed);
  int len = graphNodes[iGraphIndex]->Program(time,&a);
  if (i != 0)
    heapEdges[i]->Delete(time+(int)(len/3.0));
  time = Animate(time,len);
  if (i != 0)
    delete heapEdges[i];
}

/**********************************************************************/

void myView::goBack(int i)
{
  int len;
  int iGraphIndex = m.getGraphIndex(i);
  if (iGraphIndex == -1) 
    return;
  Loc* l0 = heapLocations[i];
  Loc* l1 = graphLocations[iGraphIndex];
  Action a("MOVE",l0,l1,speed);
  len = graphNodes[iGraphIndex]->Program(time,&a);
  time = Animate(time,len);
  Action b("ALTER","\0");
  len = graphWeights[iGraphIndex]->Program(time,&b);
  time = Animate(time,len);

  if (iGraphIndex == start)
    return;

  Loc l3(0.0,0.0);
  Loc l4(1.0,0.0);

  Action a2("COLOR","blue");
  Action a3("FILL",&l3,&l4,1);
  Action a4("COLOR","white");

  len = graphCircles[iGraphIndex]->Program(time,&a2);
  len = graphCircles[iGraphIndex]->Program(time,&a3);
  len = graphLabels[iGraphIndex]->Program(time,&a4);

  time = Animate(time,len);



}

/**********************************************************************/

void myView::swapNodes(int i, int j)
{
  Loc* iLoc = heapLocations[i];
  Loc* jLoc = heapLocations[j];
  Loc tempLoc(jLoc->XCoord(),iLoc->YCoord());

  int iGraphIndex = m.getGraphIndex(i);
  int jGraphIndex = m.getGraphIndex(j);

  if ((iGraphIndex == -1) || (jGraphIndex == -1))
    return;
  Set* nodeI = graphNodes[iGraphIndex];
  Set* nodeJ = graphNodes[jGraphIndex];

  Action a1("MOVE",iLoc,jLoc,speed*0.5);
  Action a2("MOVE",jLoc,&tempLoc,speed);
  Action a3("MOVE",&tempLoc,iLoc,speed);
  int len1 = nodeI->Program(time,&a1);
  int len2 = nodeJ->Program(time,&a2);
  int len3 = nodeJ->Program(time+len2,&a3);
  time = Animate(time,len1);
}

/**********************************************************************/

void myView::showGhosts(int i)
{
  int len;
  Action a2("VIS",1);
  len = ghostGraphCircles[i]->Program(time,&a2);
  len = ghostGraphLabels[i]->Program(time,&a2);
  time = Animate(time,len);
}

/**********************************************************************/

void myView::ghostifyEdges()
{
  Action a("COLOR","gray80");
  int len;
  
  for (int i=0; i<MAX; i++)
    for (int j=i+1; j<MAX; j++)
      if (graphEdges[i][j] != NULL)
	len = graphEdges[i][j]->Program(time,&a);
  time = Animate(time,len);
}

/**********************************************************************/

void myView::hideGhosts(int i)
{
  int iGraphIndex = m.getGraphIndex(i);
  if (iGraphIndex == -1)
    return;
  int len;
  Action a2("VIS",1);
  len = ghostGraphCircles[iGraphIndex]->Program(time,&a2);
  len = ghostGraphLabels[iGraphIndex]->Program(time,&a2);
  time = Animate(time,len);
}

/**********************************************************************/

void myView::showInstruction(char* i)
{
  char font[40];
  sprintf(font,"Times New Roman|25"/*"-*-haeberli-*-*-*-*-24-*-*-*-*-*-*-*"*/);
  instruction = new Text(this,1,0.1,0.1,"red",font,i,0);
  instruction->Originate(time);
  time = Animate(time,1);  
}

/**********************************************************************/

void myView::removeInstruction()
{
  if (instruction != NULL)
    {
      instruction->Delete(time);
      time = Animate(time,1);  
      delete instruction;
    }
}

/**********************************************************************/



int myView::pickStartNode()
{  
  AnimObject* node;
  int index;

  while(!PickAnimObject(node)) continue;

  index = (int) node->RetrieveData();
  
  int len;
  Loc l1(0.0,0.0);
  Loc l2(1.0,0.0);

  color[index] = START_NODE_COLOR;
  Action a2("COLOR",color_names[START_NODE_COLOR]);
  Action a3("FILL",&l1,&l2,1);
  
  len = graphCircles[index]->Program(time,&a2);
  len = graphCircles[index]->Program(time,&a3);
  time = Animate(time,len);

  start = index;
  return index;
}

/**********************************************************************/

int historyView::init()
{
  cout << "historyView::init()" << endl;
  xVal = -1;
  yVal = 0;
  nHeaps = -1;

  Create("Heap History",CoordStretch,600,600);
  SetBgColor("black");
  
  // create all locs for heap
  double x = 0.125;   
  double y = 0.21;
  int index = 0;
  heapLocations[index] = new Loc(x,y);
  index++;
  for (int j=1; j<5; j++)
    {
      int nAcross = (int) pow(2.0,j);
      double perNode =  0.25 / (double)nAcross;
      x = 0.125 - (nAcross/2)*perNode + perNode*0.5;
      y -= (vertical_spacing + 0.01);
      for (int k=0; k<nAcross; k++)
	{
	  heapLocations[index] = new Loc(x,y);
	  x += perNode;
	  index++;
	}
    }

  return(1);
}

/**********************************************************************/

void historyView::addHeap()
{
  cout << endl;
  xVal++;
  if (xVal == 4)
    {
      xVal = 0;
      yVal++;
    }
  nHeaps++;
}

/**********************************************************************/

void historyView::addHeapNode(int n, char* label, int weight)
{
  double x = heapLocations[n]->XCoord() + (xVal * 0.25);
  double y = heapLocations[n]->YCoord() + (yVal * 0.25);
  heapCircles[nHeaps][n] = new Circle(this,1,x,y,0.012,"gray80",1.0);
  heapCircles[nHeaps][n]->Originate(time);
    
  // add labels
  Text* t = new Text(this,1,x,y,"gray20",
		     "Times New Roman|10"/*"-adobe-helvetica-medium-r-normal-*-8-*-100-100-p-*-iso8859-1"*/,
		     label,1);
  t->Originate(time);

  char weightString[10]; 
  if (weight == INFINITY)
    sprintf(weightString,"-");
  else
    sprintf(weightString,"%d",weight);
  x = heapCircles[nHeaps][n]->Where(PART_E)->XCoord() + 0.005;
  y = heapCircles[nHeaps][n]->Where(PART_E)->YCoord() + 0.006;

  t = new Text(this,1,x,y,"red",
		     "Times New Roman|10"/*"-adobe-helvetica-medium-r-normal-*-9-*-100-100-p-*-iso8859-1"*/,
		     weightString,1);
  t->Originate(time);

  if (n == 0)
    return;

  // add a connecting line
  int p = (int) floor((float)(n-1)/2.0);
  x = heapCircles[nHeaps][n]->Where(PART_N)->XCoord();
  y = heapCircles[nHeaps][n]->Where(PART_N)->YCoord();
  double parentX = heapCircles[nHeaps][p]->Where(PART_S)->XCoord();
  double parentY = heapCircles[nHeaps][p]->Where(PART_S)->YCoord();
  double dx = parentX - x;
  double dy = parentY - y;
  Line* l = new Line(this,1,x,y,dx,dy,"white",0.0,1.0,0);
  l->Originate(time);
  Animate(time,1);


}

/**********************************************************************/

void historyView::animate()
{
  time = Animate(time,1);
}

/**********************************************************************/

void myView::animate()
{
  time = Animate(time,1);
}

/**********************************************************************/
