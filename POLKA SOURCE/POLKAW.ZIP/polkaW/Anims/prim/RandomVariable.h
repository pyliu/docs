#ifndef RandomVariable_h
#define RandomVariable_h

#include <limits.h>

// See Numerical Recipes in C pg 280

// Define a floating point random variable (floatRV) from 0 to 1
// and an unsigned long random variable (intRV) from 0 to 2^32-1

// Note that these are pretty quick and dirty; no attempt is made to increase
// periodicity.

const unsigned long rvA = 1664525L;
const unsigned long rvC = 1013904223L;

// The behavior of this one doesn't seem to be that good.  Use the other
// (R4400s are better at floating point anyway!).
class ulRV
{
private:
  unsigned long idum;

  ulRV(const ulRV&);
  const ulRV& operator=(const ulRV&);

  // Move to next number in sequence
  void Update(void){ idum = rvA*idum + rvC; }
public:
  ulRV(unsigned long s=0) : idum(s) {}
  
  // Member functions
  void Seed(unsigned long s=0){ idum = s; }
  unsigned long Rand(void){
    Update();
    return idum;
  }
  // Return a value within [x0,x1]
  unsigned long Rand(unsigned long x0, unsigned long x1){
    Update();
    return x0 + 
      (unsigned long)((((float)(x1-x0) + 1.0)*idum)/(ULONG_MAX+1.0));
  }
};

// Odd constants for masking
const unsigned long jflone = 0x3f800000;
const unsigned long jflmsk = 0x007fffff;

class floatRV
{
private:
  unsigned long idum;

  floatRV(const floatRV&);
  const floatRV& operator=(const floatRV&);

  // Move to next number in sequence
  void Update(void){ idum = rvA*idum + rvC; }
public:
  floatRV(unsigned long s=0) : idum(s) {}

  // Member functions
  void Seed(unsigned long s=0){ idum = s; }
  float Rand(void){
    unsigned long itemp;
    Update();
    itemp = jflone | (jflmsk & idum);
    return (*(float *)&itemp) - 1.0;
  }
  float Rand(float x0, float x1){ // Return a value within [x0,x1)
    return (x0 + Rand()*(x1-x0));
  }
};

#endif
