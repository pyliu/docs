/**********************************************************************

Greg Newton
CS 7390
February 10, 1996

Prim's Minimum Spanning Tree Algorithm

gregn@cc.gatech.edu

**********************************************************************/


#include <iostream.h>
//#include <stream.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <assert.h>
#include <math.h>
#include <polka.H>
#include "prim.H"

/**********************************************************************/

MyAnimator prims;
Graph* g;
MinHeap m;
HeapNode** h;



/**********************************************************************/

void initialize()
{
  // register the algorithm animation events with Polka
  prims.RegisterAlgoEvt("Init",NULL);
  prims.RegisterAlgoEvt("AddGraphNode","dffs");
  prims.RegisterAlgoEvt("AddGraphEdge","ddd");
  prims.RegisterAlgoEvt("Migrate","dd");
  prims.RegisterAlgoEvt("SwapNodes","dd");
  prims.RegisterAlgoEvt("ShowGhosts","d");
  prims.RegisterAlgoEvt("GhostifyEdges",NULL);
  prims.RegisterAlgoEvt("ShowComparison","dd");
  prims.RegisterAlgoEvt("HideGhosts","d");
  prims.RegisterAlgoEvt("ShowInstruction","s");
  prims.RegisterAlgoEvt("RemoveInstruction",NULL);
  prims.RegisterAlgoEvt("Connect","dd");
  prims.RegisterAlgoEvt("Disconnect","dd");
  prims.RegisterAlgoEvt("Highlight","ddd");
  prims.RegisterAlgoEvt("ChangeWeight","dd");
  prims.RegisterAlgoEvt("AddToMST","dd");
  prims.RegisterAlgoEvt("GoBack","d");
  prims.RegisterAlgoEvt("MoveToTop","d");
  prims.RegisterAlgoEvt("AddHeapNode","dsd");
  prims.RegisterAlgoEvt("AddHeap",NULL);
  prims.RegisterAlgoEvt("Animate",NULL);
  prims.RegisterAlgoEvt("WAIT",NULL);
  
  prims.SendAlgoEvt("Init");
}

/**********************************************************************/

void buildGraph(char* graphFile)
{
  cout << "opening \"" << graphFile << "\"" << endl << endl;
  
  // open the input file 
  FILE* inFile = fopen(graphFile,"r");
  if (inFile == NULL)
    {
      cerr << "Could not open \"" << graphFile 
	   << "\" for reading.  Exiting\n" << endl;
      exit(1);
    }

  char label = 'a';
  // get the number of nodes
  int nNodes;
  fscanf(inFile,"%d",&nNodes);
  // get the number of edges
  int nEdges;
  fscanf(inFile,"%d",&nEdges);
  g = new Graph(nNodes);

  // read in the node information
  for (int i=0; i<nNodes; i++)
    {
      double x, y;
      fscanf(inFile,"%lf %lf",&x,&y);
      g->setNode(i,label,x,y);
      label++;
    }

  // read in the edge information
  for (int j=0; j<nEdges; j++)
    {
      int f, t, w;
      fscanf(inFile,"%d %d %d",&f,&t,&w);
      g->addEdge(f,t,w);
    }

  // draw the graph nodes
  for (i=0; i<nNodes; i++)
    {
      char labelString[10];
      sprintf(labelString,"%c",g->getLabel(i));
      prims.SendAlgoEvt("AddGraphNode",i,g->getX(i),
			g->getY(i),labelString);
    }
  
  // draw the edges
  for (i=0; i<nNodes; i++)
    for (j=i+1; j<nNodes; j++)
      {
	int w = g->getWeight(i,j);
	if (w >= 0)
	  prims.SendAlgoEvt("AddGraphEdge",i,j,w);
      }
}

/**********************************************************************/

void buildHeap(int start)
{
  int n = g->getNNodes();
  h = new HeapNode*[n];
  
  for (int i=0; i<n; i++)
    {
      if (i == start)
	h[i] = new HeapNode(i,0);
      else
	h[i] = new HeapNode(i,INFINITY);
      h[i]->setParent(-1);
    }
  m.buildHeap(n,h);
}

/**********************************************************************/

int getStartNode()
{
  prims.SendAlgoEvt("ShowInstruction","Pick a start node.");
  int start = prims.pickStartNode();
  prims.SendAlgoEvt("RemoveInstruction");
  return start;
}

/**********************************************************************/

int main(int argc, char** argv)
{
  if (argc != 2)
    {
      cerr << "usage : prim graphFile" << endl;
      cerr << "(Try primIn1, primIn2, or primIn3)" << endl;
      exit(1);
    }
  
  // copy graphfile name
  char* graphFile = strdup(argv[1]);

  // call initialization function, will register the Polka events
  initialize();

  // read and build the graph
  buildGraph(graphFile);

  // have the user pick a starting node
  int start = getStartNode();
  
  // build the heap
  buildHeap(start);
  

  // now, do the algorithm
  while (!m.empty())
    {
      m.drawMiniature();
      HeapNode* extracted = m.extractMin();
      if (extracted->getParent() != -1)
	{
	  g->removeEdge(extracted->getGraphIndex(),
			extracted->getParent());
	}
      else 
	cout << endl;
      m.updateKeys(extracted->getGraphIndex(),g);
    }
  
  prims.SendAlgoEvt("ShowInstruction","Done!!");
  prims.SendAlgoEvt("Animate");
  while(1)
    prims.SendAlgoEvt("WAIT");
}

/**********************************************************************/



/**********************************************************************/

Graph::Graph(int nodes)
{
  nNodes = nodes; 

  x = new double[nNodes];
  y = new double[nNodes];
  labels = new char[nNodes];
  for (int i=0; i<nNodes; i++)
    for (int j=0; j<nNodes; j++)
      weights[i][j] = -1;
}

/**********************************************************************/

Graph::Graph(Graph& g)
{
  nNodes = g.nNodes;

  x = new double[nNodes];
  y = new double[nNodes];
  labels = new char[nNodes];

  for (int i=0; i<nNodes; i++)
    {
      x[i] = g.x[i];
      y[i] = g.y[i];
    }
  for (i=0; i<nNodes; i++)
    for (int j=0; j<nNodes; j++)
      weights[i][j] = g.weights[i][j];
}

/**********************************************************************/

void Graph::setNode(int i, char l, float xVal, float yVal)
{
  assert(i < nNodes);

  labels[i] = l;
  x[i] = xVal;
  y[i] = yVal;
}

/**********************************************************************/

void Graph::addEdge(int f, int t, int w)
{
  assert(f < nNodes);
  assert(t < nNodes);
  assert(w >= 0);
  weights[f][t] = w;
  weights[t][f] = w;
}

/**********************************************************************/

void Graph::removeEdge(int f, int t)
{
  assert(f < nNodes);  
  assert(t < nNodes);

  weights[f][t] = -1;
  weights[t][f] = -1;
}

/**********************************************************************/

int Graph::getNNodes()
{
  return nNodes;
}

/**********************************************************************/

char Graph::getLabel(int i)
{
  assert(i < nNodes);
  return labels[i];
}

/**********************************************************************/

int Graph::edgeExists(int f, int t)
{
  assert(f < nNodes);
  assert(t < nNodes);
  if (weights[f][t] >= 0)
    return 1;
  else
    return 0;
}

/**********************************************************************/

int Graph::getWeight(int f, int t)
{  
  assert(f < nNodes);
  assert(t < nNodes);
  return weights[f][t];
}

/**********************************************************************/

int Graph::getEdges(int f, int* t, int* w)
{
  assert(f < nNodes);
  int result = 0;
  for (int i=0; i<nNodes; i++)
    if (weights[f][i] >= 0)
      {
	t[result] = i;
	w[result] = weights[f][i];
	result++;
      }
  return result;
}

/**********************************************************************/

double Graph::getX(int i)
{
  assert(i < nNodes);

  return x[i];
}

/**********************************************************************/

double Graph::getY(int i)
{
  assert(i < nNodes);

  return y[i];
}

/**********************************************************************/

void Graph::print()
{
  cout << "There are " << nNodes << " nodes" << endl;
  for (int i=0; i<nNodes; i++)
    printf("\t%d -> %c\n",i,labels[i]);
  cout << endl;

  for (i=0; i<nNodes; i++)
    for (int j=0; j<nNodes; j++)
      if (weights[i][j] >= 0)
	printf("\tan edge from %d to %d, weight = %d\n",i,
	       j,weights[i][j]);
  cout << endl;
}

/**********************************************************************/

HeapNode::HeapNode()
{
  nodeKey = INFINITY; // is this a good default??
  nodeParent = -1;
  graphIndex = -1;
}

/**********************************************************************/

HeapNode::HeapNode(int i, int k)
{
  graphIndex = i;
  nodeKey = k;
  nodeParent = -1;
}

/**********************************************************************/

void HeapNode::setKey(int k)
{
  nodeKey = k;
}

/**********************************************************************/

void HeapNode::setGraphIndex(int i)
{
  graphIndex = i;
}


/**********************************************************************/

void HeapNode::setParent(int p)
{
  nodeParent = p;
}


/**********************************************************************/

int HeapNode::getKey()
{
  return nodeKey;
}

/**********************************************************************/

int HeapNode::getGraphIndex()
{
  return graphIndex;
}

/**********************************************************************/

int HeapNode::getParent()
{
  return nodeParent;
}

/**********************************************************************/
/**********************************************************************/

MinHeap::MinHeap()
{
  nNodes = 0;
  for (int i=0; i<MAX_NODES; i++)
    nodes[i] = NULL;
}

/**********************************************************************/

// WARNING!!  This call will destroy the heap if one already exists!

void MinHeap::buildHeap(int n, HeapNode** h)
{

  assert (n <= MAX_NODES);
  clearHeap();

  // copy the head node pointers
  for (int i=0; i<n; i++)
    nodes[i] = h[i];
  nNodes = n;

  // move the graph nodes
  for (i=0; i<nNodes; i++)
    {
      prims.SendAlgoEvt("ShowGhosts",i);
      prims.SendAlgoEvt("ChangeWeight",i,h[i]->getKey());

      prims.SendAlgoEvt("Migrate",i,i);
      if (i != 0)
	prims.SendAlgoEvt("Connect",i,parent(i));
    } 

  prims.SendAlgoEvt("GhostifyEdges");
  int start = ((int) floor((float)nNodes/2.0) - 1);

  for (int j=start; j>=0; j--)
    heapify(j);

}



/**********************************************************************/

void MinHeap::insert(HeapNode* h)
{
  int newNNodes = nNodes + 1;
  assert (newNNodes < MAX_NODES);

  // insert it at the bottom rightmost position
  
  int i = nNodes;
  nodes[i] = h;
  nNodes++;
  int key = h->getKey();
  int p = parent(i);

  // now do the manipulations to ensure the heap property
  while ((i > 0) && (nodes[p]->getKey() > key))
    {
      exchange(i,p);
      i = p;
      p = parent(i);
    }
}

/**********************************************************************/

void MinHeap::print()
{
  cout << "Heap" << endl;
  cout << "----" << endl;

  for (int i=0; i<nNodes; i++)
    {
      cout << nodes[i]->getGraphIndex() << "\t";
      if (nodes[i]->getKey() == INFINITY)
	cout << "INFINITY" << endl;
      else
	cout << nodes[i]->getKey() << endl;
    }
  cout << endl;
}

/**********************************************************************/

HeapNode* MinHeap::extractMin()
{
  assert(nNodes > 0);

  HeapNode* h = nodes[0];
  prims.SendAlgoEvt("GoBack",0);
  prims.SendAlgoEvt("HideGhosts",0);
  prims.SendAlgoEvt("MoveToTop",nNodes-1);
  if (h->getParent() != -1)
    prims.SendAlgoEvt("AddToMST",h->getGraphIndex(),
		      h->getParent());

  nodes[0] = nodes[nNodes-1];
  nodes[nNodes-1] = NULL;
  nNodes--;
  heapify(0);

  return h;
}

/**********************************************************************/

HeapNode* MinHeap::min()
{
  return nodes[0];
}

/**********************************************************************/

void MinHeap::decreaseKey(HeapNode* h, int newKey)
{
  h->setKey(newKey);
  int i = findIndex(h);
  int p = parent(i);
  prims.SendAlgoEvt("ChangeWeight",i,newKey);
  while (i > 0)
    {
      if (nodes[p]->getKey() > newKey)
        {
          prims.SendAlgoEvt("Highlight",i,p,0);
          exchange(i,p);
          i = p;
          p = parent(i);
        }
      else
        {
          prims.SendAlgoEvt("Highlight",i,p,1);
          break;
        }
    }
}

/**********************************************************************/

int MinHeap::empty()
{
  if (nNodes > 0)
    return 0;
  else 
    return 1;
}

/**********************************************************************/

int MinHeap::index(HeapNode* h)
{
  int i = findIndex(h);
  return i;
}

/**********************************************************************/

int MinHeap::getParent(int i)
{
  return parent(i);
}

/**********************************************************************/

int MinHeap::getGraphIndex(int i)
{
  if (i < nNodes)
    return nodes[i]->getGraphIndex();
  else
    return -1;
}

/**********************************************************************/

// look for node with index = i

int MinHeap::getHeapIndex(int i)
{
  // check each node until you find one that has graphIndex == i
  for (int j=0; j<nNodes; j++)
    {
      int graphIndex = nodes[j]->getGraphIndex();
      if (graphIndex == i)
	return j;
    }
    
  return -1;
}

/**********************************************************************/

int MinHeap::findIndex(HeapNode* h)
{
  for (int i=0; i<nNodes; i++)
    if (nodes[i] == h)
      return i;
  return -1;
}

/**********************************************************************/

int MinHeap::left(int i)
{
  return (2*i) + 1;
}

/**********************************************************************/

int MinHeap::right(int i)
{
  return (2*i) + 2;
}

/**********************************************************************/

int MinHeap::parent(int i)
{
  return (int) floor((float)(i-1)/2.0);
}

/**********************************************************************/

void MinHeap::exchange(int i, int j)
{
  assert (i < MAX_NODES);
  assert (j < MAX_NODES);
  prims.SendAlgoEvt("SwapNodes",i,j);

  HeapNode* tmp = nodes[i];
  nodes[i] = nodes[j];
  nodes[j] = tmp;
}

/**********************************************************************/

void MinHeap::heapify(int i)
{
  int l = left(i);
  int r = right(i);
  int smallest = i;
  int len;

  // check the left child's key value
  if (l < nNodes)
    if (nodes[l]->getKey() < nodes[i]->getKey())
      smallest = l;
    else
      {
	smallest = i;
	len = prims.SendAlgoEvt("Highlight",i,l,1);
      }
  
  // check the right child's key value
  if (r < nNodes)
    if (nodes[r]->getKey() < nodes[smallest]->getKey())
      smallest = r;
    else
      len = prims.SendAlgoEvt("Highlight",i,r,1);

  prims.SendAlgoEvt("Animate",len);
  if (smallest != i)
    {
      len = prims.SendAlgoEvt("Highlight",i,smallest,0);
      prims.SendAlgoEvt("Animate",len);
      exchange(i,smallest);
      heapify(smallest);
    }
}

/**********************************************************************/

// deletes ALL the nodes in the heap..

void MinHeap::clearHeap()
{
  for (int i=0; i<nNodes; i++)
    {
      delete nodes[i];
      nodes[i] = NULL;
    }
  nNodes = 0;
}

/**********************************************************************/

void MinHeap::updateKeys(int graphIndex, Graph* g)
{
  int to[31];
  int weights[31];

  // get all the edges that are connected to this node (graphIndex)
  int n =  g->getEdges(graphIndex,to,weights);

  // for each edge, see if the ending vertex needs it's heap key updated
  for (int i=0; i<n; i++)
    {
      int heapIndex = getHeapIndex(to[i]);
      if (heapIndex == -1)
	continue;
      int key = nodes[heapIndex]->getKey();
      int weight = weights[i];
      if (weight < key)
	{
	  prims.SendAlgoEvt("ShowComparison",graphIndex,to[i]);
	  nodes[heapIndex]->setParent(graphIndex);
	  decreaseKey(nodes[heapIndex],weight);
	}
    }
}

/**********************************************************************/

void MinHeap::drawMiniature()
{
  prims.SendAlgoEvt("AddHeap");
  for (int i=0; i<nNodes; i++)
    {
      int index = nodes[i]->getGraphIndex();
      char label[10]; 
      sprintf(label,"%c",g->getLabel(index));
      int weight = nodes[i]->getKey();
      prims.SendAlgoEvt("AddHeapNode",i,label,weight);
    }
}

