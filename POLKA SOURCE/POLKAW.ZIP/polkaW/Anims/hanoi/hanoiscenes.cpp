/* ---------------------------- Hanoi ------------------------------- */

#include	"hanoi.H"

/* ---------------------------- Hanoi ------------------------------- */

//extern "C" usleep(unsigned int);
extern "C" double fabs(double);
extern "C" void exit(int);

const   double  DHEIGHT = 0.09;
const   double  DWIDTH  = 0.3;
const   double  DIST    = 0.125; //0.14;
const   double  PFACTOR = 200.0;

MyAnimator      hanoi;

/* ---------------------------- Hanoi ------------------------------- */

int
MyAnimator::Controller()
{
    int             retval = 0;

    if (!strcmp(AlgoEvtName, "Move")) {
	retval = state.Move(AnimInts[0], AnimInts[1]);
    } else if (!strcmp(AlgoEvtName, "Init")) {
	retval = state.Init(AnimInts[0]);
    } else if (!strcmp(AlgoEvtName, "Done")) {
	state.Done();
    }
    return (retval);
}

/* ---------------------------- Hanoi ------------------------------- */

int
HanoiState::Init(int n)
{
    if ((n < 1) || (n * DHEIGHT > 0.8)) {
	cerr << "Invalid number of disks!\n";
	exit(1);
    }

    SetDebug(0);
    Create("Hanoi");

    N = n;
    moves = 0;
    pegs[0] = n;
    pegs[1] = pegs[2] = 0;

    int i;
    Line *l;

    VTOP = (n + 1) * DHEIGHT + 0.05;
    for (i = 0; i < 3; i++) {
	pegx[i] = i / 3.0 + 1.0 / 6;
	l = new Line(this, 1, pegx[i], 0.09, 0.0, VTOP - DHEIGHT - 0.003);
	l->Originate(time);
    }

    Rectangle *base = new Rectangle(this, 1, 0.0, 0.05, 1.0,
	DHEIGHT - 0.05, "black", 0.1);
    base->Originate(time);

    for (i = 0; i < 3; i++)
	peg[i] = new Set*[N];

    double x, y = DHEIGHT, w;

    // constructing the disks
    for (i = 0; i < n; i++) {
	char str[4];
	sprintf(str, "%d", n - i);
	AnimObject *a[3];

	w = DWIDTH - i * DIST / (n - 1);
	x = pegx[0] - w / 2;

	a[0] = new Rectangle(this, 1, x, y, w, DHEIGHT, "yellow", 1.0);
	a[1] = new Rectangle(this, 1, x, y, w, DHEIGHT, "black", 0.0);
	a[2] = new Text(this, 1, pegx[0], y + DHEIGHT / 2,
		"black", NULL, str, 1);
        a[0]->Originate(time);
        a[1]->Originate(time);
        a[2]->Originate(time);
	peg[0][i] = new Set(this, 3, a);
	peg[0][i]->StoreData(a[0]);
	peg[0][i]->Originate(time);
	y += DHEIGHT;
    }

    //Refresh();
    return 0;
}

/* ---------------------------- Hanoi ------------------------------- */

int
HanoiState::Move(int from, int to)
{
    moves ++;

    Action *act, *iact1, *iact2, *iact3, *fact, *nact;
    int len;

    // Get the object
    Set * obj = peg[from][pegs[from] - 1];
    Rectangle *r = (Rectangle *) obj->RetrieveData();

    // Change color
    act = new Action("COLOR", "orange");
    len = r->Program(time, act);
    time = Animate(time, len+20);
    delete (act);

    // "Real" delay
    //Refresh();

    double	x, y;
    double	fromX = pegx[from], fromY = DHEIGHT * pegs[from],
		toX = pegx[to], toY = DHEIGHT * (pegs[to] + 1);

    // Move up
    x = 0.0;			y = VTOP - fromY;
    act = new Action("MOVE", 1, &x, &y);
    iact1 = act->Interpolate((fabs(x) + fabs(y)) * PFACTOR);
    delete(act);

    // Move left or right
    x = toX - fromX;		y = 0.0;
    act = new Action("MOVE", 1, &x, &y);
    iact2 = act->Interpolate((fabs(x) + fabs(y)) * PFACTOR);
    nact = iact1->Concatenate(iact2);
    delete iact1;
    delete iact2;
    delete act;

    // Move down
    x = 0.0;			y = toY - VTOP;
    act = new Action("MOVE", 1, &x, &y);
    iact3 = act->Interpolate((fabs(x) + fabs(y)) * PFACTOR);
    fact = nact->Concatenate(iact3);
    delete act;
    delete iact3;
    delete nact;

    // "Program" the movement
    len += obj->Program(time + len, fact);
    delete fact;

    // Change color back
    act = new Action("COLOR", "yellow");
    len += r->Program(time + len, act);
    delete act;

    // Record the changes
    pegs[from] --;
    pegs[to] ++;
    peg[to][pegs[to] - 1] = obj;

    // Go!
    time = Animate(time, len);
    return len;
}

/* ---------------------------- Hanoi ------------------------------- */

void
HanoiState::Done()
{
//    cout << "Total moves = " << moves << "\n" << flush;
	printf( "Total moves = %d\n", moves );

    //Refresh();
    while (True) {
	CheckInput();
//	usleep(300000);
    }
}

/* ---------------------------- Hanoi ------------------------------- */

