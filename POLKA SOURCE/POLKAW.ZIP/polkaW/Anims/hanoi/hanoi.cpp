/* ---------------------------- Hanoi ------------------------------- */

#include "hanoi.H"

/* ---------------------------- Hanoi ------------------------------- */

extern MyAnimator hanoi;

/* ---------------------------- Hanoi ------------------------------- */

void
rec(int n, int from, int to)
{
    int             spare;

    if (n <= 1)
	hanoi.SendAlgoEvt("Move", from, to);
    else {
	spare = 3 - from - to;
	rec(n - 1, from, spare);
	hanoi.SendAlgoEvt("Move", from, to);
	rec(n - 1, spare, to);
    }
}

/* ---------------------------- Hanoi ------------------------------- */

main()
{
    hanoi.RegisterAlgoEvt("Init", "d");
    hanoi.RegisterAlgoEvt("Move", "dd");
    hanoi.RegisterAlgoEvt("Done", NULL);

    cout << "How many disks?\n";
    int n;
    cin >> n;
    hanoi.SendAlgoEvt("Init", n);
    rec(n, 0, 2);
    hanoi.SendAlgoEvt("Done");
}

/* ---------------------------- Hanoi ------------------------------- */

