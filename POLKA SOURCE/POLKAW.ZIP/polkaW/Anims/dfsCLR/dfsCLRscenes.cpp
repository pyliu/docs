#include <iostream.h>
#include <fstream.h>
#include <string.h>
#include "polka.H"
#include "dfsCLR.H"

#define MAX(A,B)   ((A) > (B) ? (A) : (B))

const double SIZE = 0.015;
double fillval = 1.0;
double unfillval = -1.0;


MyAnimator dfs;

int
MyAnimator::Controller()
{
   int len;

// printf("                                                --%s\n",AlgoEvtName);

   if (!strcmp(AlgoEvtName,"INIT")) {
      len = gv.Init(AnimStrings[0]);
      gv.DoAnimate(len);
   }
   else if (!strcmp(AlgoEvtName,"VERTEX")) {
      len = gv.Vertex(AnimInts[0],AnimDoubles[0],AnimDoubles[1]);
      gv.DoAnimate(len);
   }
   else if (!strcmp(AlgoEvtName,"EDGE")) {
      len = gv.Edge(AnimInts[0],AnimInts[1],AnimInts[2]);
      gv.DoAnimate(len);
   }
   else if (!strcmp(AlgoEvtName,"NEW_COMP")) {
      len = gv.NewComp(AnimInts[0],AnimInts[1]);
      gv.DoAnimate(len);
   }
   else if (!strcmp(AlgoEvtName,"END_COMP")) {
      len = gv.EndComp();
      gv.DoAnimate(len);
   }
   else if (!strcmp(AlgoEvtName,"VISIT")) {
      len = gv.Visit(AnimInts[0],AnimInts[1]);
      gv.DoAnimate(len);
   }
   else if (!strcmp(AlgoEvtName,"BACKTRACK")) {
      len = gv.Backtrack(AnimInts[0]);
      gv.DoAnimate(len);
   }
   else if (!strcmp(AlgoEvtName,"DONE")) {
      len = gv.Done(AnimInts[0]);
      gv.DoAnimate(len);
   }
   else {
      gv.CheckInput();
   }

   return(1);
}


int
GraphView::Init(char *title)
{
   char t[100];
   sprintf(t, "GraphView: %s",title);
   Create(t);
   SetBgColor("white");

   lozenge = new Circle(this, 0, 0.1, 0.1, SIZE, "green", 1.0);
   lozenge->Originate(time);

   return (1);
}


int
GraphView::Vertex(int vnum, double x, double y)
{
   vertex[vnum] = new Circle(this, 1, x, y, SIZE, "black", 0.0);
   vertex[vnum]->Originate(time);

   return(1);
}


int
GraphView::Edge(int count, int from, int to)
{
   int len;

   if (to <= from)   // only put the edges in once (handles both)
      return(0);

   Loc *frompt = vertex[from]->Where(PART_C);
   Loc *topt   = vertex[to]->Where(PART_C);
   edgenum[count] = edge[from][to] = edge[to][from] = new Line(this, 1, 
          frompt->XCoord(), frompt->YCoord(), 
          topt->XCoord()-frompt->XCoord(), topt->YCoord()-frompt->YCoord(),
          "black", 0.0, 1.0, 0);
   edge[from][to]->Originate(time);

   Action a("RAISE", 1);
   len = vertex[from]->Program(time, &a);
   len = vertex[to]->Program(time, &a);
  
   delete(frompt);
   delete(topt);
   return(len);
}





/* beginning of a new component, make the lozenge visible, and change the */
/* vertex to indicate it's been visited                                   */

int
GraphView::NewComp(int vnum, int val)
{
   char   str[5];
   int    len;
   Text  *pos;
   Loc   *atpt,*topt;

   atpt = lozenge->Where(PART_C);
   topt = vertex[vnum]->Where(PART_C);
   Action move("MOVE",atpt,topt,1);
   len = lozenge->Program(time, &move);

   //Action fill("FILL", 1, &fillval, &fillval);
   // lozenge->Program(time, &fill);

   Action vis("VIS", 1);
   len = lozenge->Program(time, &vis);

   delete(atpt);
   delete(topt);

   return(len+1);
}




/* move the lozenge to the given vertex and change the vertex's type */

int
GraphView::Visit(int vnum, int order)
{
   char   str[5];
   int    len;
   Text  *pos;
   Loc   *atpt,*topt;

   atpt = lozenge->Where(PART_C);
   topt = vertex[vnum]->Where(PART_C);
   Action move("MOVE",atpt,topt,0.01);
   len = lozenge->Program(time, &move);

   Action color1("COLOR", "gray");
   Action fill("FILL", 1, &fillval, &fillval);
   vertex[vnum]->Program(time+len, &color1);
   vertex[vnum]->Program(time+len, &fill);

   delete(atpt);
   delete(topt);

   return(len+3);
}





/* make the lozenge proceed back to the given vertex */

int
GraphView::Backtrack(int vnum)
{
   int   len;
   Loc  *atpt,*topt;

   atpt = lozenge->Where(PART_C);
   topt = vertex[vnum]->Where(PART_C);
   Action move("MOVE",atpt,topt,0.01);
   len = lozenge->Program(time, &move);

   delete(atpt);
   delete(topt);

   return(len+1);
}





/* all the descendants of this vertex have been visited */
/* so change its color to indicate so			*/

int
GraphView::Done(int vnum)
{
   int len;

   Action color("COLOR", "black");
   len = vertex[vnum]->Program(time, &color);

   return(len);
}





/* the current connected component is ending, so make the */
/* lozenge invisible					  */

int
GraphView::EndComp()
{
   int len;

   Action vis("VIS", 1);
   len = lozenge->Program(time, &vis);
   return(len);
}



int
GraphView::DoAnimate(int frames)
{
   time = Animate(time, frames);
   return(1);
}



void
GraphView::message(int ti, char *str)
{
   static Text *msg = NULL;

   if (msg)
      msg->Delete(ti);
   msg = new Text(this, 1, 0.5, 0.03, "yellow", "10x20",
            str, 1);
   msg->Originate(ti);
}











