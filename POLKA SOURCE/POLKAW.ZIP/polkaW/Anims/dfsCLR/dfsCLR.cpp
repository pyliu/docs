#include <iostream.h>
#include <fstream.h>
#include <math.h>
#include <polka.H>
#include "dfsCLR.H"


extern MyAnimator dfs; 

int n,now;
double loc[MAXVERT][2];
int adj[MAXVERT][MAXVERT],val[MAXVERT];


double
distance(int i, int j)
{
   double dx,dy;

   dx = loc[i][0] - loc[j][0];
   dy = loc[i][1] - loc[j][1];
   return ( sqrt( (dx*dx) + (dy*dy) ) );
}




void
visit(int k)
{
   int t;

   
   now += 1;
   dfs.SendAlgoEvt("VISIT", k, now);
   val[k] = now;
   for (t=0; t<n; ++t)
      if ((adj[k][t] != 0) && (val[t] == 0))
         { 
           visit(t);
           dfs.SendAlgoEvt("BACKTRACK", k);
         }
   dfs.SendAlgoEvt("DONE", k);
}



main(int argc, char *argv[])
{
   int i,j,edgecount;

   dfs.RegisterAlgoEvt("INIT","s");
   dfs.RegisterAlgoEvt("VERTEX","dff");
   dfs.RegisterAlgoEvt("EDGE","ddd");
   dfs.RegisterAlgoEvt("NEW_COMP","dd");
   dfs.RegisterAlgoEvt("END_COMP",NULL);
   dfs.RegisterAlgoEvt("VISIT","dd");
   dfs.RegisterAlgoEvt("BACKTRACK","d");
   dfs.RegisterAlgoEvt("DONE","d");
   dfs.RegisterAlgoEvt("WAIT",NULL);

   cout << "You should use an input file for this program" << endl;

   cout << "How many vertices?" << endl;
   cin >> n;
   if (n>MAXVERT) {
      cout << "Too many vertices.  Try a smaller number." << endl;
      exit(0);
    }

   dfs.SendAlgoEvt("INIT", "Depth First Search");
   cout << "Enter the locations" << endl;
   for (i=0; i<n; ++i)
      { cin >> loc[i][0] >> loc[i][1];
        dfs.SendAlgoEvt("VERTEX", i, loc[i][0], loc[i][1]);
      }

   edgecount = 0;
   cout << "Enter the adjacency matrix, one element per line, in row-major order" << endl;
   for (i=0; i<n; ++i)
      for (j=0; j<n; ++j)
         { cin >> adj[i][j];
           if (adj[i][j] != 0) {
              dfs.SendAlgoEvt("EDGE", edgecount, i, j);
              edgecount++;
              }
         }

   now = 0;
   for (j=0; j<n; ++j)
      val[j] = 0;

   for (j=0; j<n; ++j)
      if (val[j] == 0)
         { dfs.SendAlgoEvt("NEW_COMP", j, now);
           visit(j);
           dfs.SendAlgoEvt("END_COMP");
         }

   while (1)
      dfs.SendAlgoEvt("WAIT");
}



