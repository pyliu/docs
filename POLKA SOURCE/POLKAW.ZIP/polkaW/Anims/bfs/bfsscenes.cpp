#include <iostream.h>
#include <fstream.h>
#include <string.h>
#include "polka.H"
#include "bfs.H"

#define MAX(A,B)   ((A) > (B) ? (A) : (B))

const double SIZE = 0.05;
double fillval = 1.0;
double unfillval = -1.0;


MyAnimator bfs;

int
MyAnimator::Controller()
{
   int len;

// printf("                                                --%s\n",AlgoEvtName);

   if (!strcmp(AlgoEvtName,"INIT")) {
      len = gv.Init(AnimStrings[0]);
      gv.DoAnimate(len);
   }
   else if (!strcmp(AlgoEvtName,"VERTEX")) {
      len = gv.Vertex(AnimInts[0],AnimDoubles[0],AnimDoubles[1]);
      gv.DoAnimate(len);
   }
   else if (!strcmp(AlgoEvtName,"EDGE")) {
      len = gv.Edge(AnimInts[0],AnimInts[1],AnimInts[2]);
      gv.DoAnimate(len);
   }
   else if (!strcmp(AlgoEvtName,"NEW_COMP")) {
      len = gv.NewComp(AnimInts[0],AnimInts[1]);
      gv.DoAnimate(len);
   }
   else if (!strcmp(AlgoEvtName,"END_COMP")) {
      len = gv.EndComp();
      gv.DoAnimate(len);
   }
   else if (!strcmp(AlgoEvtName,"VISIT")) {
      len = gv.Visit(AnimInts[0],AnimInts[1]);
      gv.DoAnimate(len);
   }
   else if (!strcmp(AlgoEvtName,"BACKTRACK")) {
      len = gv.Backtrack(AnimInts[0]);
      gv.DoAnimate(len);
   }
   else if (!strcmp(AlgoEvtName,"DONE")) {
      len = gv.Done(AnimInts[0]);
      gv.DoAnimate(len);
   }
   else {
      gv.CheckInput();
   }

   return(1);
}


int
GraphView::Init(char *title)
{
   char t[100];
   sprintf(t, "GraphView: %s",title);
   Create(t);
   SetBgColor("white");

   lozenge = new Circle(this, 0, 0.1, 0.1, SIZE/2.0, "black", 1.0);
   lozenge->Originate(time);

   return (1);
}


int
GraphView::Vertex(int vnum, double x, double y)
{
   static char *letlist =
                 "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"; 
   char letter[2];

   vertex[vnum] = new Rectangle(this, 1, x-(SIZE/2.0), y-(SIZE/2.0), 
                                     SIZE, SIZE, "black", 1.0);
   vertex[vnum]->Originate(time);

   letter[1] = '\0';
   letter[0] = letlist[vnum];
   label[vnum] = new Text(this, 1, x, y, "yellow", 
                                  "lucidasanstypewriter-bold-14", letter, 1);
   label[vnum]->Originate(time);
   return(1);
}


int
GraphView::Edge(int count, int from, int to)
{
   int len;

   if (to <= from)   // only put the edges in once (handles both)
      return(0);

   Loc *frompt = vertex[from]->Where(PART_C);
   Loc *topt   = vertex[to]->Where(PART_C);
   edgenum[count] = edge[from][to] = edge[to][from] = new Line(this, 1, 
          frompt->XCoord(), frompt->YCoord(), 
          topt->XCoord()-frompt->XCoord(), topt->YCoord()-frompt->YCoord(),
          "black", 0.5, 1.0, 0);
   edge[from][to]->Originate(time);

   Action a("RAISE", 1);
   len = vertex[from]->Program(time, &a);
   len = vertex[to]->Program(time, &a);
   len = label[from]->Program(time, &a);
   len = label[to]->Program(time, &a);
  
   delete(frompt);
   delete(topt);
   return(len);
}





/* beginning of a new component, make the lozenge visible, and change the */
/* vertex to indicate it's been visited                                   */

int
GraphView::NewComp(int vnum, int val)
{
   char   str[5];
   int    len;
   Text  *pos;
   Loc   *atpt,*topt;

   atpt = lozenge->Where(PART_C);
   topt = vertex[vnum]->Where(PART_C);
   Action move("MOVE",atpt,topt,1);
   lozenge->Program(time, &move);

   Action fill("FILL", 1, &fillval, &fillval);
   lozenge->Program(time, &fill);

   Action vis("VIS", 1);
   len = lozenge->Program(time, &vis);

   Action color1("COLOR", "green");
   vertex[vnum]->Program(time+len, &color1);

   Action color2("COLOR", "black");
   len += label[vnum]->Program(time+len, &color2);

   delete(atpt);
   delete(topt);

   return(len+1);
}




/* move the lozenge to the given vertex and change the vertex's type */

int
GraphView::Visit(int vnum, int order)
{
   char   str[5];
   int    len;
   Text  *pos;
   Loc   *atpt,*topt;

   Action fill("FILL", 1, &fillval, &fillval);
   len = lozenge->Program(time, &fill);

   atpt = lozenge->Where(PART_C);
   topt = vertex[vnum]->Where(PART_C);
   Action move("MOVE",atpt,topt,0.01);
   len += lozenge->Program(time+len, &move);

   Action color1("COLOR", "green");
   vertex[vnum]->Program(time+len, &color1);

   Action color2("COLOR", "black");
   len += label[vnum]->Program(time+len, &color2);

   sprintf(str,"%d",order); 
   pos = new Text(this, 1, topt->XCoord()-0.035, topt->YCoord()+0.035,
                        "black", "lucidasanstypewriter-bold-14", str, 1);
   pos->Originate(time+len);

   delete(atpt);
   delete(topt);

   return(len+1);
}





/* make the lozenge proceed back to the given vertex */

int
GraphView::Backtrack(int vnum)
{
   int   len;
   Loc  *atpt,*topt;

   Action fill("FILL", 1, &unfillval, &unfillval);
   len = lozenge->Program(time, &fill);

   atpt = lozenge->Where(PART_C);
   topt = vertex[vnum]->Where(PART_C);
   Action move("MOVE",atpt,topt,0.01);
   len += lozenge->Program(time+len, &move);

   delete(atpt);
   delete(topt);

   return(len+1);
}





/* all the descendants of this vertex have been visited */
/* so change its color to indicate so			*/

int
GraphView::Done(int vnum)
{
   int len;

   Action color("COLOR", "blue");
   Action raise("RAISE", 1);
   vertex[vnum]->Program(time, &color);
//   vertex[vnum]->Program(time, &raise);

   Action color2("COLOR", "white");
   label[vnum]->Program(time, &color2);
   len = label[vnum]->Program(time, &raise);

   return(len);
}





/* the current connected component is ending, so make the */
/* lozenge invisible					  */

int
GraphView::EndComp()
{
   int len;

   Action vis("VIS", 1);
   len = lozenge->Program(time, &vis);
   return(len);
}



int
GraphView::DoAnimate(int frames)
{
   time = Animate(time, frames);
   return(1);
}



void
GraphView::message(int ti, char *str)
{
   static Text *msg = NULL;

   if (msg)
      msg->Delete(ti);
   msg = new Text(this, 1, 0.5, 0.03, "yellow", "10x20",
            str, 1);
   msg->Originate(ti);
}











