#include <iostream.h>
#include <fstream.h>
#include <math.h>
#include <polka.H>
#include "bfsCLR.H"


extern MyAnimator bfs; 

int n,now;
double loc[MAXVERT][2];
int adj[MAXVERT][MAXVERT],val[MAXVERT];


class Node {
  public:
   int nodenum;
   Node *next;
};




int
main(int argc, char *argv[])
{
   int i,j,edgecount,u,v;
   Node *qhead,*qtail,*node = NULL;

   bfs.RegisterAlgoEvt("INIT","s");
   bfs.RegisterAlgoEvt("VERTEX","dff");
   bfs.RegisterAlgoEvt("EDGE","ddd");
   bfs.RegisterAlgoEvt("NEW_COMP","dd");
   bfs.RegisterAlgoEvt("END_COMP",NULL);
   bfs.RegisterAlgoEvt("VISIT","dd");
   bfs.RegisterAlgoEvt("BACKTRACK","d");
   bfs.RegisterAlgoEvt("DONE","d");
   bfs.RegisterAlgoEvt("WAIT",NULL);

   cout << "You should use an input file for this program" << endl;

   cout << "How many vertices?" << endl;
   cin >> n;
   if (n>MAXVERT) {
      cout << "Too many vertices.  Try a smaller number." << endl;
      exit(0);
    }

   bfs.SendAlgoEvt("INIT", "Breadth First Search");
   cout << "Enter the locations" << endl;
   for (i=0; i<n; ++i)
      { cin >> loc[i][0] >> loc[i][1];
        bfs.SendAlgoEvt("VERTEX", i, loc[i][0], loc[i][1]);
      }

   edgecount = 0;
   cout << "Enter the adjacency matrix, one element per line, in row-major order" << endl;
   for (i=0; i<n; ++i)
      for (j=0; j<n; ++j)
         { cin >> adj[i][j];
           if (adj[i][j] != 0) {
              bfs.SendAlgoEvt("EDGE", edgecount, i, j);
              edgecount++;
              }
         }

   val[0] = 1;
   now = 1;
   bfs.SendAlgoEvt("VISIT", 0, now);

   node = new Node();
   node->nodenum = 0;
   node->next = NULL;
   qhead = qtail = node;

   while (qhead) {
      u = qhead->nodenum;
      bfs.SendAlgoEvt("NEW_COMP", u, now);
      for (v=0; v<n; ++v)
         if ((adj[u][v] != 0) && (val[v] == 0)) {
            now++;
            val[v] = now;
            bfs.SendAlgoEvt("VISIT", v, now);
            node = new Node();
            node->nodenum = v;
            node->next = NULL;
            if (qtail)
               qtail->next = node;
            else 
               qhead = node;
            qtail = node;
            bfs.SendAlgoEvt("BACKTRACK", u);
            }
      qhead = qhead->next; 
      bfs.SendAlgoEvt("END_COMP");
      bfs.SendAlgoEvt("DONE", u);
      }

   while (1)
      bfs.SendAlgoEvt("WAIT");
}
            



