#include <iostream.h>
//#include <stream.h>
#include <string.h>
//#include <strings.h>
#include "polka.H"
#include "balls.H"

// added
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
// end added

extern MyAnimator balls;

//extern "C" long lrand48();

#define BALLS 50
#define SIZE 3


main(int argc,char *argv[])
{
   int i,j;
   int x[BALLS],y[BALLS],vx[BALLS],vy[BALLS];
   int lx,by,rx,ty;
   int started[BALLS];
   int clock=0,min;
   int numballs,bounced;

   balls.RegisterAlgoEvt("Init","d");
   balls.RegisterAlgoEvt("Originate","ddd");
   balls.RegisterAlgoEvt("Time","d");
   balls.RegisterAlgoEvt("Collision","dddd");
   balls.RegisterAlgoEvt("WAIT",NULL);

// added
   srand( (unsigned)time( NULL ) );
// end added

   lx = by = 0;
   rx = ty = 100;
   balls.SendAlgoEvt("Init",rx);
   cout << "Number of balls (up to 50)" << endl;
   cin >> numballs;
   for (i = 0; i < numballs; ++i) {
      x[i] = (lx+rx)/2;
      y[i] = (ty+by)/2;
      vx[i] = rand()%13-6;
//      vx[i] = random()%13-6;
      if (vx[i] == 0) vx[i] = 1;
      vy[i] = rand()%13-6;
//      vy[i] = random()%13-6;
      if (vy[i] == 0) vy[i] = 1;
      balls.SendAlgoEvt("Originate",i,x[i],y[i]);
      started[i] = 0;
    };

   for ( ; ; ) {
      clock++;
      for (i = 0; i < numballs; ++i) {
	 x[i] += vx[i];
	 y[i] += vy[i];
         bounced = 0;
	 if (x[i] <= lx) {
	    x[i] = lx;
	    vx[i] = -vx[i] + (rand()%3 - 1);
//	    vx[i] = -vx[i] + (rand()%3 - 1);
            if (vx[i] > 6) vx[i] = 6;
            bounced = 1;
            started[i] = clock+1;  // collides on n, starts on n+1
	  };
	 if (x[i] >= rx) {
	    x[i] = rx;
	    vx[i] = -vx[i] + (rand()%3 - 1);;
//	    vx[i] = -vx[i] + (random()%3 - 1);;
            if (vx[i] < -6) vx[i] = -6;
            bounced = 1;
            started[i] = clock+1;
	  };
	 if (y[i] >= ty) {
	    y[i] = ty;
	    vy[i] = -vy[i] + (rand()%3 - 1);;
//	    vy[i] = -vy[i] + (random()%3 - 1);;
            if (vy[i] < -6) vy[i] = -6;
            bounced = 1;
            started[i] = clock+1;
	  };
	 if (y[i] <= by) {
	    y[i] = by;
	    vy[i] = -vy[i] + (rand()%3 - 1);;
//	    vy[i] = -vy[i] + (random()%3 - 1);;
            if (vy[i] > 6) vy[i] = 6;
            bounced = 1;
            started[i] = clock+1;
	  };
         if (bounced) // this avoids multiple collisions per time step
             balls.SendAlgoEvt("Collision",i,clock,x[i],y[i]);
       };
     min=1000000000;
     for (j=0; j<numballs; j++)
        if (started[j] < min) min=started[j];
     balls.SendAlgoEvt("Time",min);
     if (clock==10000) break;
    };
   while (1)
      balls.SendAlgoEvt("WAIT");
};



