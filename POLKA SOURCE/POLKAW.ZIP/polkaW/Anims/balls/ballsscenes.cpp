#include <iostream.h>
//#include <stream.h>
#include <string.h>
//#include <strings.h>
#include "polka.H"
#include "balls.H"


static char * Col[] = {
   "black",
   "yellow",
   "green",
   "red",
   "blue",
   "maroon",
   "orange"
};



const double RAD = 0.025;
MyAnimator balls;
int deb;

//
double fills[100];
//

void CBFct(AnimObject *, void *, double, double);


int
MyAnimator::Controller()
{
   if (!strcmp(AlgoEvtName,"Init")) {
      b.Init(AnimInts[0]);
   }
   else if (!strcmp(AlgoEvtName,"Originate")) {
      b.Originate(AnimInts[0],AnimInts[1],AnimInts[2]);
   }
   else if (!strcmp(AlgoEvtName,"Time"))  {
      b.Time(AnimInts[0]);
   }
   else if (!strcmp(AlgoEvtName,"Collision")) { 
      b.Collision(AnimInts[0],AnimInts[1],AnimInts[2],AnimInts[3]);
   }
   else
      b.CheckInput();
   return(1);
}


int
Balls::Init(int size)
{
   Create("Particle simulation");

   factor = double(size);
   return(1);
}


int
Balls::Originate(int ball, int x, int y)
{
   px[ball] = double(x)/factor;
   py[ball] = double(y)/factor;
   color[ball] = 0;

   release[ball] = 1;
   blocks[ball] = new Rectangle(this,1,px[ball]-RAD,py[ball]-RAD,
                        RAD*2.0,RAD*2.0,Col[ color[ball] ],1.0);
   blocks[ball]->SetCallback(CBFct, (void*)ball);
   blocks[ball]->Originate(0);
   return(1);
}


int
Balls::Time(int clock)
{
   if (clock > time)
      time = Animate(time,clock-time);
   return(1);
}



int
Balls::Collision(int ball, int clock, int x, int y)
{
   double dx,dy;
   Circle *c;
   Rectangle *r;

   dx = double(x)/factor;
   dy = double(y)/factor;

   if (dx < RAD) dx = RAD;
   else if (dx > (1.0-RAD)) dx = 1.0-RAD;
   if (dy < RAD) dy = RAD;
   else if (dy > (1.0-RAD)) dy = 1.0-RAD;
 
   Loc from(px[ball], py[ball]);
   Loc to(dx, dy);
   Action a1("MOVE",&from,&to,clock-release[ball]+1);
   blocks[ball]->Program(release[ball], &a1);
   color[ball] = (color[ball]+1) % 7;
   Action a2("COLOR",Col[ color[ball] ]);
   blocks[ball]->Program(clock, &a2);

   if (color[ball] % 2 == 1) {
      c = new Circle(this,1,dx,dy,RAD,Col[ color[ball] ],1.0);
      blocks[ball]->Change(clock,c,0);
      delete c;
      }
   else {
      r = new Rectangle(this,1,dx-RAD,dy-RAD,2.0*RAD,2.0*RAD,
                 Col[ color[ball] ],1.0);
      blocks[ball]->Change(clock,r,0);
      delete r;
      }

   release[ball] = clock+1;
   px[ball] = dx;
   py[ball] = dy;

   return(1);
}
   


void
CBFct(AnimObject *ao, void *d, double x, double y)
{
   printf("Picking object=%d at (%5.3lf, %5.3lf) with data=%d\n",
        ao, x, y, (int) d);
}


