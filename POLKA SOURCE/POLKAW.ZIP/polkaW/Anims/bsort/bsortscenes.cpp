#include <iostream.h>
#include <string.h>
//#include <stream.h>
//#include <strings.h>
#include <errno.h>
//#include <osfcn.h>
#include "polka.H"
#include "bsort.H"


MyAnimator bsort;


int
MyAnimator::Controller()
{
   static int time=0;
   int len;

//   cout << "In controller aen=" << AlgoEvtName << "\n";

   if (!strcmp(AlgoEvtName,"Init")) {
      r.Init();
      b.Init();
   }
   else if (!strcmp(AlgoEvtName,"Input")) {
      r.Input(AnimInts[0],AnimInts[1]);
      b.Input(AnimInts[0],AnimInts[1]);
   }
   else if (!strcmp(AlgoEvtName,"Ready")) {
      r.Ready(AnimInts[0]);
      len = b.Ready(AnimInts[0]);
      time = Animate(time, len);
   }
//   else if (!strcmp(AlgoEvtName,"Compare")) 
//      r.Compare(AnimInts[0],AnimInts[1]);
   else if (!strcmp(AlgoEvtName,"Exchange")) { 
      r.Exchange(AnimInts[0],AnimInts[1]);
      len = b.Exchange(AnimInts[0],AnimInts[1]);
      time = Animate(time, len);
   }
   else if (!strcmp(AlgoEvtName,"InPlace"))  {
      r.InPlace(AnimInts[0]);
      len = b.InPlace(AnimInts[0]);
      time = Animate(time, len);
   }
   else {
      r.CheckInput();
      b.CheckInput();
      }
   return(1);
}


int
Rects::Init()
{
   Create("Bubblesort (Rect View)");
   return(0);
}



/* save the values in the array */

int
Rects::Input(int index,int val)
{
   values[index] = val;
   if (val > max) max=val;
   if (val < min) min=val;
   return(1);
}




/* draw the array as a row of rectangles with the heights corresponding */
/* to the value of each array element.					*/

int
Rects::Ready(int n)
{
   RectangleGroup objs;
   Loc *center;
   int len,i;
   double x,y;
   char str[5];

   strcpy(objs.color,"red");
   objs.spacetype = SpacingSame;
   objs.horiz = 1;
   objs.align = AlignBottom;
   objs.useints = 1;
   objs.intvals = values;
   objs.intmin = min;
   objs.intmax = max;
   objs.Make(this,blocks,n,0.1,0.1,0.9,0.9);

   for (i=0; i<n; ++i)
      { center = blocks[i]->Where(PART_C);
	x = center->XCoord();
        y = center->YCoord();
	sprintf(str,"%d",values[i]);
	labels[i] = new Text(this,1,x,y,"black",NULL,str,1);
        blocks[i]->Originate(0);
        labels[i]->Originate(0);
      }

   Action a("DELAY",10);
   len = blocks[0]->Program(time,&a);
   time+= len;
   return(len);
}





/* make two rectangles simultaneously flash */

int
Rects::Compare(int i, int j)
{
   double flash[4];
   int len;

   flash[0] = 0.5; /* halffill */
   flash[2] = -1.0; /* outline */
   flash[1] = flash[3] = 0.0;
   Action a("FILL",4,flash,flash);
   ActionPtr b = a.Iterate(4);
   len = blocks[i]->Program(time,b);
   len = blocks[j]->Program(time,b);
   time+= len;
   delete b;

   return(len);
}





/* make the two rectangles exchange positions on the screen in one */
/* simultaneous movement					   */

int
Rects::Exchange(int i, int j)
{
   Rectangle *tempr;
   Text *tempt;
   LocPtr loc1,loc2;
   int len;

   loc1 = blocks[i]->Where(PART_SW);
   loc2 = blocks[j]->Where(PART_SW);
   Action a("MOVE",loc1,loc2,CLOCKWISE);
   Action *b = a.Rotate(180);
   len = blocks[i]->Program(time,&a);
   labels[i]->Program(time,&a);
   blocks[j]->Program(time,b);
   labels[j]->Program(time,b);
   time += len;

   tempr = blocks[i];
   blocks[i] = blocks[j];
   blocks[j] = tempr;

   tempt = labels[i];
   labels[i] = labels[j];
   labels[j] = tempt;

   delete b;
   return(len);
}





/* alter the fill style of the rectangle to show it is "in-place" */

int
Rects::InPlace(int i)
{
   int len;
   double f = 1.0;

   Action a("FILL",1,&f,&f);
   Action b("COLOR","white");
   blocks[i]->Program(time,&a);
   len = labels[i]->Program(time,&b);
   time += len;
   return(len);
}



