#include <iostream.h>
#include <string.h>
//#include <stream.h>
//#include <strings.h>
#include "polka.H"
#include "bsort.H"

extern MyAnimator bsort;

main(int argc, char *argv[])
{
   int n,i,j,temp,a[50],count;
   char str[100];

   bsort.RegisterAlgoEvt("Init",NULL);
   bsort.RegisterAlgoEvt("Input","dd");
   bsort.RegisterAlgoEvt("Ready","d");
   bsort.RegisterAlgoEvt("Compare","dd");
   bsort.RegisterAlgoEvt("Exchange","dd");
   bsort.RegisterAlgoEvt("InPlace","d");
   bsort.RegisterAlgoEvt("WAIT",NULL);

   bsort.SendAlgoEvt("Init",NULL);


   cout << "Enter number of elements in the array\n";
   cin >> n;

   cout << "Enter the elements\n";
   for (count=0; count<n; ++count)
      {
	   cin >> a[count];
	   bsort.SendAlgoEvt("Input",count,a[count]);
      }

   bsort.SendAlgoEvt("Ready",n);;

   for (j=n-2; j>=0; --j)
      { for (i=0; i<=j; ++i)
	   { bsort.SendAlgoEvt("Compare",i,i+1);
	     if (a[i] > a[i+1])
		{ temp = a[i];
		  a[i] = a[i+1];
		  a[i+1] = temp;
          bsort.SendAlgoEvt("Exchange",i,i+1);
		}
	   }
	bsort.SendAlgoEvt("InPlace",j+1);
      }
   bsort.SendAlgoEvt("InPlace",0);
   while (1)
      bsort.SendAlgoEvt("WAIT");

}


