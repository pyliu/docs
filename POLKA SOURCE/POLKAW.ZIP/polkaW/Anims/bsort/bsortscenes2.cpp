#include <iostream.h>
#include <string.h>
//#include <stream.h>
//#include <strings.h>
#include "polka.H"
#include "bsort.H"


int
Blocks::Init()
{
   Create("Bubblesort (Blocks view)");
   return(0);
}


/* save the values in the array */

int
Blocks::Input(int index,int val)
{
   values[index] = val;
   if (val > max) max=val;
   if (val < min) min=val;
   return(1);
}




/* draw the array as a row of rectangles with the heights corresponding */
/* to the value of each array element.					*/

int
Blocks::Ready(int n)
{
   RectangleGroup objs;
   Loc *center;
   int len,i;
   double x,y;
   char str[5];

   strcpy(objs.color,"red");
   objs.spacetype = SpacingNone;
   objs.horiz = 0;
   objs.align = AlignMiddle;
   objs.useints = 1;
   objs.intvals = values;
   objs.intmin = min;
   objs.intmax = max;
   objs.Make(this,blocks,n,0.1,0.1,0.9,0.9);

   for (i=0; i<n; ++i)
      { center = blocks[i]->Where(PART_C);
	x = center->XCoord();
        y = center->YCoord();
	sprintf(str,"%d",values[i]);
	labels[i] = new Text(this,1,x,y,"black",NULL,str,1);
        blocks[i]->Originate(0);
        labels[i]->Originate(0);
      }

   Action a("DELAY",10);
   len = blocks[0]->Program(time,&a);
   time += len;
   return(len);
}





/* make the two rectangles exchange positions on the screen in one */
/* simultaneous movement					   */

int
Blocks::Exchange(int i, int j)
{
   Rectangle *tempr;
   Text *tempt;
   LocPtr loc1,loc2;
   int len;

   loc1 = blocks[i]->Where(PART_S);
   loc2 = blocks[j]->Where(PART_S);
   Action a("MOVE",loc1,loc2,STRAIGHT);
   Action *b = a.Rotate(180);
   len = blocks[i]->Program(time,&a);
   labels[i]->Program(time,&a);
   blocks[j]->Program(time,b);
   labels[j]->Program(time,b);
   time += len;

   tempr = blocks[i];
   blocks[i] = blocks[j];
   blocks[j] = tempr;

   tempt = labels[i];
   labels[i] = labels[j];
   labels[j] = tempt;

   delete b;
   return(len);
}





/* alter the fill style of the rectangle to show it is "in-place" */

int
Blocks::InPlace(int i)
{
   int len;
   double f = 1.0;

   Action a("FILL",1,&f,&f);
   Action b("COLOR","white");
   blocks[i]->Program(time,&a);
   len = labels[i]->Program(time,&b);
   time += len;
   return(len);
}



/*
void
ANIMCompare2(p1,p2,p3,p4)
   int	p1;
   int	p2;
   int	p3;
   int	p4;
{
   double x1,y1,x2,y2;
   TANGO_LOC loc1, loc2;
   TANGO_IMAGE rect1, rect2, l1, l2;
   TANGO_PATH fivepath, onepath;
   TANGO_TRANS appear, invis1, invis2, ender;

   rect1 = (TANGO_IMAGE) ASSOCretrieve("ID", p1, p2);
   rect2 = (TANGO_IMAGE) ASSOCretrieve("ID", p3, p4);
   loc1 = TANGOimage_loc(rect1, TANGO_PART_TYPE_S);
   loc2 = TANGOimage_loc(rect2, TANGO_PART_TYPE_S);
   TANGOloc_inquire(loc1,&x1,&y1);
   TANGOloc_inquire(loc2,&x2,&y2);
   l1 = TANGOimage_create(TANGO_IMAGE_TYPE_LINE, x1,y1, 1, TANGO_COLOR_BLACK, 0.000000, 0.06, 1.000000, 1.000000, 0);
   l2 = TANGOimage_create(TANGO_IMAGE_TYPE_LINE, x2, y2,1, TANGO_COLOR_BLACK, 0.000000, 0.06, 1.000000, 1.000000, 0);
   fivepath = TANGOpath_null(5);
   appear = TANGOtrans_create(TANGO_TRANS_TYPE_DELAY, rect1, fivepath);
   TANGOtrans_perform(appear);
   onepath = TANGOpath_null(1);
   invis1 = TANGOtrans_create(TANGO_TRANS_TYPE_VISIBLE, l1, onepath);
   invis2 = TANGOtrans_create(TANGO_TRANS_TYPE_VISIBLE, l2, onepath);
   ender = TANGOtrans_compose(2, invis1, invis2);
   TANGOtrans_perform(ender);
}


*/
