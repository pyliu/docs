/***************************************************************/
/*							                                   */
/*	       		WinMain.cpp			                           */
/*							                                   */
/***************************************************************/
/*       Copyright 1997 Georgia Institute of Technology 
                     -- Roman S. Khramets                      */
#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <iostream.h>
#include <io.h>
#include <fcntl.h>
#include <stdiostr.h>

#include "resource.h"
#include "window_sizes.h"
#include "Init.h"

#include "perr.h"

#define BUTTON_WIDTH              6
#define SCROLL_BAR_WIDTH          30

#define STARTB_ID                 0
#define STEPB_ID                  (STARTB_ID + 1)
#define DELAY_ID                  (STARTB_ID + 3)
#define QUITB_ID                  (STARTB_ID + 5)

#define MIN_SCROLL_POS            0
#define LINE_SCROLL_STEP          1
#define PG_SCROLL_STEP            20
#define MAX_SCROLL_POS            100

/*----------------------------------- Types -------------------------------------*/

typedef void (*LPMAIN)(int argc, char *argv[]);

typedef struct {
	LPMAIN lpMain;
	int argc;
	char **argv;
} MainThreadParams;

/*--------------------------------- Function prototypes -------------------------*/

extern void speedCB(void *param);
extern void pauseCB(void *param);
extern void stepCB(void *param);
extern void closeCB(void *param);
extern void quitCB(void *param);

extern APP_CALLBACK AppRunPauseCB;
extern APP_CALLBACK AppStepCB;
extern APP_CALLBACK AppDelayCB;
extern APP_CALLBACK AppCloseCB;
extern APP_CALLBACK AppQuitCB;

extern int getPaused();
extern void main( int argc, char *argv[] );

extern LRESULT CALLBACK ViewWindowProc (HWND, UINT, WPARAM, LPARAM) ;
extern LRESULT CALLBACK DrawingAreaProc (HWND, UINT, WPARAM, LPARAM) ;
extern LRESULT CALLBACK ConsoleProc (HWND, UINT, WPARAM, LPARAM) ;
extern LRESULT CALLBACK ConsoleEditProc (HWND, UINT, WPARAM, LPARAM) ;

void getTextMetrics (int *cxChar, int *cyChar) ;
LRESULT CALLBACK WndProc (HWND, UINT, WPARAM, LPARAM) ;
/*---------------------------------- Common variables --------------------------*/

// x and y sizes of the
// system fixed font: the font that
// will be used for buttons and
// static text
int cxChar, cyChar;
// View class default window size
RECT viewWndDefRect;
// control panel window size
RECT mainWndRect;
// the application handler
HINSTANCE hApp;
// application's display mode (minimized, normal size, etc.)
int iAppCmdShow;
// handler to the control panel window
HWND hControlPanel = NULL;
// "edit" window handler
WNDPROC EditWindowProc;
/*-------------------------------------------------------------------------------*/

class View;
extern int _createControlPanel;

COLORREF wndBkColor = RGB(210, 180, 140);
HBRUSH   wndBkBrush;

int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance,
                    PSTR szCmdLine, int iCmdShow) {
     static char szAppName[] = "polkaW_classes" ;
     static char szViewWindow[] = "ViewWindow" ;
     static char szDrawingArea[] = "DrawingArea" ;
	 LOGBRUSH brushInfo;
     HWND        hwnd ;
     MSG         msg ;
     WNDCLASSEX  wndclass ;
     WNDCLASSEX  vwndclass ;   // ViewWindow
     WNDCLASSEX  dawndclass ;  // DrawArea
	 DWORD       wndStyle;
	 RECT        mainWndRect;

	 brushInfo.lbStyle = BS_SOLID;
	 brushInfo.lbColor = wndBkColor;
	 wndBkBrush = CreateBrushIndirect( &brushInfo );

	 // assign the application handler
	 hApp = hInstance;
	 iAppCmdShow = iCmdShow;

     // Register main window class
     wndclass.cbSize        = sizeof (wndclass) ;
     wndclass.style         = CS_HREDRAW | CS_VREDRAW ;
     wndclass.lpfnWndProc   = WndProc ;
     wndclass.cbClsExtra    = 0 ;
     wndclass.cbWndExtra    = 0 ;
     wndclass.hInstance     = hInstance ;
     wndclass.hIcon         = LoadIcon (hInstance, MAKEINTRESOURCE(POLKAW_CLASSES)) ;
     wndclass.hCursor       = LoadCursor (NULL, IDC_ARROW) ;
     wndclass.hbrBackground = wndBkBrush ;
     wndclass.lpszMenuName  = NULL ;
     wndclass.lpszClassName = szAppName ;
     wndclass.hIconSm       = LoadIcon (hInstance, szAppName) ;

     RegisterClassEx (&wndclass) ;

	 // register the window class for the
	 // View object
     vwndclass.cbSize        = sizeof (vwndclass) ;
     vwndclass.style         = CS_HREDRAW | CS_VREDRAW ;
     vwndclass.lpfnWndProc   = ViewWindowProc ;
     vwndclass.cbClsExtra    = 0 ;
     vwndclass.cbWndExtra    = 0 ;
     vwndclass.hInstance     = hInstance ;
     vwndclass.hIcon         = LoadIcon (hInstance, MAKEINTRESOURCE(POLKAW_CLASSES)) ;
     vwndclass.hCursor       = LoadCursor (NULL, IDC_ARROW) ;
     vwndclass.hbrBackground = wndBkBrush ;
     vwndclass.lpszMenuName  = NULL ;
     vwndclass.lpszClassName = szViewWindow ;
     vwndclass.hIconSm       = LoadIcon (hInstance, szAppName) ;

     RegisterClassEx (&vwndclass) ;

	 // register the window class for the
	 // drawing area of the View window
     dawndclass.cbSize        = sizeof (dawndclass) ;
     dawndclass.style         = CS_HREDRAW | CS_VREDRAW ;
     dawndclass.lpfnWndProc   = DrawingAreaProc ;
     dawndclass.cbClsExtra    = 0 ;
     dawndclass.cbWndExtra    = 0 ;
     dawndclass.hInstance     = hInstance ;
     dawndclass.hIcon         = NULL ;
     dawndclass.hCursor       = LoadCursor (NULL, IDC_ARROW) ;
     dawndclass.hbrBackground = (HBRUSH) GetStockObject (WHITE_BRUSH) ;
     dawndclass.lpszMenuName  = NULL ;
     dawndclass.lpszClassName = szDrawingArea ;
     dawndclass.hIconSm       = NULL ;

     RegisterClassEx (&dawndclass) ;

	 // get the system measurements for the
	 // standard system fixed font
	 getTextMetrics( &cxChar, &cyChar );

	 // create and display the main
	 // window (control panel)
	 mainWndRect.left  = 5;
	 mainWndRect.top   = 10;
	 mainWndRect.right = cxChar * CWND_X_SIZE;
	 mainWndRect.bottom = cyChar * CWND_Y_SIZE;

	 viewWndDefRect.left   = 5;
	 viewWndDefRect.top    = 110;
	 viewWndDefRect.right  = cxChar * CVWND_X_SIZE;
	 viewWndDefRect.bottom = cyChar * CVWND_Y_SIZE;

	 PolkaSetCallbacks(pauseCB, stepCB, speedCB, closeCB, quitCB);
	 PolkaInit();

//	 if( _createControlPanel ) {
		 wndStyle = 0;
		 wndStyle = WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX;
		 hwnd = CreateWindowEx (0, szAppName, "Polka for Windows",
							  wndStyle,
							  mainWndRect.left,
							  mainWndRect.top,
							  mainWndRect.right,
							  mainWndRect.bottom,
							  NULL,
							  NULL, hInstance, NULL) ;

		 hControlPanel = hwnd;
		 ShowWindow (hwnd, iCmdShow) ;
		 UpdateWindow (hwnd) ;
//	 }

	 // access the argc and argv
	 extern int __argc;
	 extern char **__argv;
	 //

	 int argc = 0;
	 char **argv = new char *[__argc];
	 
	 // set up the console
	 BOOL bSuccess;
	 HANDLE hStdIn, hStdOut, hStdErr; /* standard input, output, error handles */
	 int fd_rt;
	 FILE *f_rt;

	 bSuccess = AllocConsole();
	 PERR(bSuccess, "AllocConsole", ACTION_RETURN(-1))

	 bSuccess = SetConsoleTitle("Console");
	 PERR(bSuccess, "SetConsoleTitle", ACTION_RETURN(-1))

	 //CreateConsole(mainWndRect.left + mainWndRect.right + 5,
	 //  mainWndRect.top,
	 //  (9.0/10.0)*mainWndRect.right,
	 //	 100 + viewWndDefRect.bottom);

	 // check for I/O redirections
	 char *fileIn = NULL;
	 char *fileOut = NULL;

	 for( int i = 0; i < __argc; i++ ) {
		 if( __argv[i][0] == '<' ) {
			 PERR(fileIn == NULL, "Multiple input redirections", ACTION_RETURN(-1));
			 if( strlen(__argv[i]) > 1 ) {
				 fileIn = &__argv[i][1];
			 } else {
				 PERR(i - 1 < __argc, "Empty input file name", ACTION_RETURN(-1));
				 fileIn = __argv[++i];
			 }
		 } else if( __argv[i][0] == '>' ) {
			 PERR(fileOut == NULL, "Multiple output redirections", ACTION_RETURN(-1));
			 if( strlen(__argv[i]) > 1 ) {
				 fileOut = &__argv[i][1];
			 } else {
				 PERR(i - 1 < __argc, "Empty output file name", ACTION_RETURN(-1));
				 fileOut = __argv[++i];
			 }
		 } else {
			 argv[argc++] = __argv[i];
		 }
	 }
     // end check for I/O redirections

	 /*
	 CHAR bBuffer[256];
	 sprintf(bBuffer, "Argc: %d\nInput redirection: %s\nOutput redirection: %s\n",
		 __argc,
		 fileIn ? fileIn : "NULL",
		 fileOut ? fileOut : "NULL");
	 MessageBox(NULL, bBuffer, "For your information", MB_OK|MB_ICONINFORMATION);
	 */

     hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
     PERR(hStdOut != INVALID_HANDLE_VALUE, "GetStdHandle", ACTION_RETURN(-1));
     hStdIn = GetStdHandle(STD_INPUT_HANDLE);
     PERR(hStdIn != INVALID_HANDLE_VALUE, "GetStdHandle", ACTION_RETURN(-1));
     hStdErr = GetStdHandle(STD_ERROR_HANDLE);
     PERR(hStdErr != INVALID_HANDLE_VALUE, "GetStdHandle", ACTION_RETURN(-1));

	 // stdout
	 if( fileOut ) {
		 f_rt = fopen(fileOut, "wt");
		 fd_rt = _fileno(f_rt);
	 } else {
		 fd_rt = _open_osfhandle((long)hStdOut, _O_TEXT);
		 f_rt = _fdopen(fd_rt, "wt");
	 }

	 PERR(fd_rt != -1 && f_rt != NULL, "Error opening stdout", ACTION_RETURN(-1));
	 *stdout = *f_rt;

	 stdiobuf stdout_buf(stdout);
	 ostream  stdout_os(&stdout_buf);
	 cout = stdout_os;

	 // stdin
	 if( fileIn ) {
		 f_rt = fopen(fileIn, "rt");
		 fd_rt = _fileno(f_rt);
	 } else {
		 fd_rt = _open_osfhandle((long)hStdIn, _O_TEXT);
		 f_rt = _fdopen(fd_rt, "rt");
	 }

	 PERR(fd_rt != -1 && f_rt != NULL, "Error opening stdin", ACTION_RETURN(-1));
	 *stdin = *f_rt;

     stdiobuf stdin_buf(stdin);
     istream  stdin_os(&stdin_buf);
     cin = stdin_os;

	 // stderr
	 fd_rt = _open_osfhandle((long)hStdErr, _O_TEXT);
	 f_rt = _fdopen(fd_rt, "wt");
	 PERR(fd_rt != -1 && f_rt != NULL, "stderr", ACTION_RETURN(-1));
	 *stderr = *f_rt;

	 stdiobuf stderr_buf(stderr);
	 ostream  stderr_os(&stderr_buf);
	 cerr = stderr_os;
	 // end set up the console

	 main( argc, argv );

	 DeleteObject( wndBkBrush );
     return 0 ;
}


LRESULT CALLBACK WndProc (HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam) {
	 static HWND   hwndButtons[3] ;
	 static HWND   hwndScrollBar;
	 static int    curButton = 0;
	 static char  *labels[] = { "Run", "Pause" };
	 static float  scrollPos;
	 static float  sl;
	 HWND  hwndCtl;
     LONG  wNotifyCode;
     LONG  wID;
     HDC          hdc ;
     PAINTSTRUCT  ps ;
	 WORD nScrollCode;
	 WORD nPos;
     int          i ;

     switch( iMsg ) {
          case WM_CREATE :
			   i = STARTB_ID;
               hwndButtons[0] = CreateWindow ("button",
						"Start",
                        WS_GROUP | WS_TABSTOP | WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON | WS_EX_STATICEDGE,
                        cxChar * (1 + BUTTON_WIDTH * i),
						cyChar,
                        cxChar * BUTTON_WIDTH,
						7 * cyChar / 4,
                        hwnd,
						(HMENU) i,
                        ((LPCREATESTRUCT)lParam)->hInstance,
						NULL) ;

               i++;
               hwndButtons[1] = CreateWindow ("button",
				        "Step",
                        WS_TABSTOP | WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON | WS_EX_STATICEDGE,
                        cxChar * (2 + BUTTON_WIDTH * i),
						cyChar,
                        cxChar * BUTTON_WIDTH,
						7 * cyChar / 4,
                        hwnd,
						(HMENU) i,
                        ((LPCREATESTRUCT)lParam)->hInstance,
						NULL) ;

			   i++;
               CreateWindow ("static",
				        "Slow",
                        WS_CHILD | WS_VISIBLE | SS_CENTER,
                        cxChar * (4 + BUTTON_WIDTH * i),
						cyChar + cyChar * 0.3,
                        cxChar * 4,
						cyChar,
                        hwnd,
						(HMENU) i,
						((LPCREATESTRUCT)lParam)->hInstance,
						NULL) ;

			   i++;
			   hwndScrollBar = CreateWindow ("scrollbar",
				                 NULL,
                                 WS_CHILD | WS_VISIBLE | WS_TABSTOP | SBS_HORZ,
                                 cxChar * (3 + BUTTON_WIDTH * i),
								 cyChar,
                                 cxChar * SCROLL_BAR_WIDTH,
								 7 * cyChar / 4,
                                 hwnd,
								 (HMENU) i,
								 ((LPCREATESTRUCT)lParam)->hInstance,
								 NULL) ;
			   scrollPos = MAX_SCROLL_POS;
			   SetScrollRange (hwndScrollBar, SB_CTL, MIN_SCROLL_POS, MAX_SCROLL_POS, FALSE);
               SetScrollPos   (hwndScrollBar, SB_CTL, MAX_SCROLL_POS, TRUE) ;

			   i++;
               CreateWindow ("static",
				        "Fast",
                        WS_CHILD | WS_VISIBLE | SS_CENTER,
                        cxChar * ((4 + BUTTON_WIDTH * (i - 1)) + SCROLL_BAR_WIDTH),
						cyChar + cyChar * 0.3,
                        cxChar * 4,
						cyChar,
                        hwnd,
						(HMENU) i,
						((LPCREATESTRUCT)lParam)->hInstance,
						NULL) ;

               i++;
               hwndButtons[2] = CreateWindow ("button",
				        "Quit",
                        WS_TABSTOP | WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON | WS_EX_STATICEDGE,
                        cxChar * ((4 + BUTTON_WIDTH * (i - 1)) + SCROLL_BAR_WIDTH),
						cyChar,
                        cxChar * BUTTON_WIDTH,
						7 * cyChar / 4,
                        hwnd,
						(HMENU) i,
                        ((LPCREATESTRUCT)lParam)->hInstance,
						NULL) ;

               return 0 ;

          case WM_CTLCOLORSTATIC :
               SetTextColor ((HDC) wParam, RGB(0, 0, 0)) ;
               SetBkColor ((HDC) wParam, wndBkColor);
               return (LRESULT) wndBkBrush ;

		  case WM_HSCROLL:
			  nScrollCode = (int)LOWORD(wParam);  // scroll bar value
			  nPos = (short int)HIWORD(wParam);   // scroll box position

			  switch( nScrollCode ) {
                    case SB_PAGEDOWN:
                         scrollPos += PG_SCROLL_STEP;
                                                  // fall through
                    case SB_LINEDOWN:
                         scrollPos = min(MAX_SCROLL_POS, scrollPos + LINE_SCROLL_STEP);
                         break;

                    case SB_PAGEUP:
                         scrollPos -= PG_SCROLL_STEP;
                                                  // fall through
                    case SB_LINEUP:
                         scrollPos = max(MIN_SCROLL_POS, scrollPos - LINE_SCROLL_STEP);
                         break;

                    case SB_TOP:
                         scrollPos = MIN_SCROLL_POS;
                         break;

                    case SB_BOTTOM:
                         scrollPos = MAX_SCROLL_POS;
                         break;

                    case SB_THUMBPOSITION:
                    case SB_THUMBTRACK:
                         scrollPos = nPos;
                         break;

                    default:
                         break;
			  }

              SetScrollPos (hwndScrollBar, SB_CTL, scrollPos, TRUE);
			  sl = scrollPos/100.0;
			  AppDelayCB(&sl);
		  break;

          case WM_COMMAND :
               hwndCtl = (HWND) lParam;      // handle of control 

		       wNotifyCode = HIWORD(wParam); // notification code 
               wID = LOWORD(wParam);         // item, control, or accelerator identifier 

			   switch( wID ) {
			       case STARTB_ID:
					   curButton = 0;
					   AppRunPauseCB(NULL);
					   SetWindowText (hwndCtl, labels[1 - getPaused()]) ;
					   break;

				   case STEPB_ID:
					   if( curButton != 1 ) {
   					       SetWindowText (hwndButtons[0], labels[0]);
					   }
					   curButton = 1;
					   AppStepCB(NULL);
					   break;

				   case QUITB_ID:
					   AppQuitCB(NULL);
					   break;

				   case PAUSE_COMMAND:
					   if( getPaused() == 0 ) {  // if not already paused
						   AppRunPauseCB(NULL);
						   SetWindowText (hwndButtons[0], labels[0]) ;
					   }
					   break;

				   case RESUME_COMMAND:
					   if( getPaused() == 1 ) {  // if not already paused
						   AppRunPauseCB(NULL);
						   SetWindowText (hwndButtons[0], labels[1]) ;
					   }
					   break;

				   case RESET_COMMAND:
					   SetWindowText (hwndButtons[0], "Start") ;
					   scrollPos = MAX_SCROLL_POS;
					   SetScrollPos (hwndScrollBar, SB_CTL, scrollPos, TRUE);
					   sl = scrollPos/100.0;
					   AppDelayCB(&sl);
					   break;
			   }
               return 0;

		  case WM_SETFOCUS:
			   SetFocus( hwndButtons[curButton] );
			   return 0;

          case WM_DESTROY :
			   AppQuitCB(NULL);
               PostQuitMessage (0) ;
               return 0 ;
     }

     return DefWindowProc (hwnd, iMsg, wParam, lParam) ;
}


void getTextMetrics( int *cxChar, int *cyChar ) {
     HWND hwndButton ;
     HDC  hdc ;
     TEXTMETRIC   tm ;

	 // create a dummy window
     hwndButton = CreateWindow ("button", "",
              WS_DISABLED,
			  0, 0, 0, 0,
			  NULL, NULL,
			  NULL, NULL) ;

	 // get the text metrics
	 hdc = GetDC (hwndButton) ;
	 SelectObject (hdc, GetStockObject (SYSTEM_FIXED_FONT)) ;
	 GetTextMetrics (hdc, &tm) ;
	 *cxChar = tm.tmAveCharWidth ;
	 *cyChar = tm.tmHeight + tm.tmExternalLeading ;
	 ReleaseDC (hwndButton, hdc) ;

	 DestroyWindow(hwndButton);
}
