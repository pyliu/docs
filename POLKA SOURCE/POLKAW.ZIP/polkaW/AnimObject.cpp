/***************************************************************/
/*							                                   */
/*	       		AnimObject.cpp			                       */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#include "AnimObject.h"
#include "Set.h"


AnimObject::AnimObject(AnimObjectImpl *i) : object(i)
{
   type = i->Type();
   view = i->MyView();
   first = last = NULL;
   firstContinuous = lastContinuous = NULL;
   deleters = NULL;
   changers = NULL;
   continDeleters = NULL;
   attachments = NULL;
   attachedTo = NULL;
   attachDoneFrom = NULL;
   originateAt = INT_MAX;   // from math.h
   originated = 0;
   modified = 1;
   updating = 1;
   callbackFct = NULL;
   callbackData = NULL;
   objs = NULL;
   i->SetWrapper(this);
   addObject();
}


AnimObject::AnimObject(const AnimObject& a)
{
   AnimObjectImpl *ooo;

   ooo = a.object;   // this is a kludge for a CC compiler bug
   object = ooo->clone();

   type = a.type;
   view = a.view;
   modified = 1;
   updating = 1;
   firstContinuous = lastContinuous = NULL;
   first = last = NULL;
   deleters = NULL;
   changers = NULL;
   continDeleters = NULL;
   attachments = NULL;
   attachedTo = NULL;
   attachDoneFrom = NULL;
   originated = 0;
   originateAt = INT_MAX;   // from math.h
   callbackFct = a.callbackFct;
   callbackData = a.callbackData;
   objs = NULL;
   object->SetWrapper(this);
   addObject();
}


AnimObject&
AnimObject::operator=(const AnimObject& a)
{
   AnimObjectImpl *ooo;

   delete object;    // out with the old (from bitwise construction)

   ooo = a.object;   // this is a kludge for a CC compiler bug
   object = ooo->clone();

   type = a.type;
   view = a.view;
   modified = 1;
   updating = 1;
   firstContinuous = lastContinuous = NULL;
   first = last = NULL;
   deleters = NULL;
   changers = NULL;
   continDeleters = NULL;
   attachments = NULL;
   attachedTo = NULL;
   attachDoneFrom = NULL;
   originated = 0;
   originateAt = INT_MAX;   // from math.h
   callbackFct = a.callbackFct;
   callbackData = a.callbackData;
   objs = NULL;
   object->SetWrapper(this);
   addObject();
   return *this;
}


void
AnimObject::addObject()
{
   if (type == P_Set) return;  // did this rather than making a virtual
                               // Sets never go in AnimObject list
   AOPtr aop = new AONode;
   aop->object = this;
   if (!view->PendingHead)
      view->PendingHead = aop;
   else
      view->PendingTail->next = aop;
   aop->prev = view->PendingTail;
   aop->next = NULL;
   view->PendingTail = aop;

   viewAOP = aop;
}


void
AnimObject::deleteMe()  // this should never be called on a Set
{
   ActionInfoPtr a,old;
   ActionDeletePtr adp,adpold;
   ImplPtr i,iold;
   IntPtr t,told;
   AOPtr aop,before;
   Attachment att,attold;

   a = first;
   while (a) {   // get rid of programming nodes
       old = a;
       a = a->next;
       delete(old->action);
       delete old;
   }
   first = NULL;

   a = firstContinuous;
   while (a) {   // get rid of continuous programming nodes
       old = a;
       a = a->next;
       delete(old->action);
       delete old;
   }
   firstContinuous = NULL;

   i = changers;
   while (i) {   // get rid of change nodes
      iold = i;
      i = i->next;
      delete(iold);
   }
   changers = NULL;

   t = deleters;
   while (t) {   // get rid of delete nodes
      told = t;
      t = t->next;
      delete(told);
   }
   deleters = NULL;

   adp = continDeleters;
   while (adp) {   // get rid of delete nodes
      adpold = adp;
      adp = adp->next;
      delete(adpold);
   }
   continDeleters = NULL;

   att = attachments;
   while (att) {   // get rid of attachment nodes
      attold = att;
      att = att->next;
      attold->object->attachedTo = NULL;  // remove reference to this one
      delete(attold);
   }
   attachments = NULL;

   for (aop=objs; aop; ) {  // remove object from any sets it was in
      ((Set *)(aop->object))->RemoveFromSet(this);
      before = aop;
      aop = aop->next;
      delete(before);
    }
   objs = NULL;

   if (attachedTo)   // make sure others pointing to this disregard it
      attachedTo->removeAttachment(this);

    // Get the AOP out of the view's list too
   if (originated) {
      for (aop=view->AOHead; aop; aop=aop->next) {  
        if (aop->object == this) {
           if (aop->next)
              aop->next->prev = aop->prev;
           if (aop->prev)
              aop->prev->next = aop->next;
           if (aop == view->AOHead)
              view->AOHead = aop->next;
           if (aop == view->AOTail)
              view->AOTail = aop->prev;
           delete(aop);
           return;
         }
      }
   }
   else { // not originated
      for (aop=view->PendingHead; aop; aop=aop->next) {  
        if (aop->object == this) {
           if (aop->next)
              aop->next->prev = aop->prev;
           if (aop->prev)
              aop->prev->next = aop->next;
           if (aop == view->PendingHead)
              view->PendingHead = aop->next;
           if (aop == view->PendingTail)
              view->PendingTail = aop->prev;
           delete(aop);
           return;
         }
      }
   }
}


void
AnimObject::Originate(int ti)
{
   if (originated) {
      cout << "Attempt to Originate AnimObject already Originated" << endl;
      return;
      }
   originateAt = ti;
}

   
void
AnimObject::Change(int ti, AnimObject *newobj, int useoldpos)
{
   ImplPtr run;   // add a change node, keep them in numerical order

   if ((type == P_Set) || (newobj->Type() == P_Set)) {
      cout << "Changing to/from a Set AnimObject is not allowed" << endl;
      return;
    }

   if (updating == 0)    // not on Update list (which is 1 or -1)
      view->AddUpdateObject(this->viewAOP);
   updating = 1;

   ImplPtr ip = new ImplNode;
   ip->time = ti;
   ip->existingpos = useoldpos;
   ip->objimpl = (newobj->Object())->clone();
   if ((!changers) || (changers->time >= ti)) {
      ip->next = changers;
      changers = ip;
      }
   else {
      run = changers;
      while ((run->next) && (run->next->time < ti)) 
         run = run->next;
      ip->next = run->next;
      run->next = ip;
      }
}


void
AnimObject::Delete(int ti)
{
   IntPtr run;   // add a delete node, keep them in numerical order

   if (type == P_Set) // since Sets are in AnimObj list, makes no sense
      return;

   if (updating == 0)     // not on Update list (which is 1 or -1)
      view->AddUpdateObject(this->viewAOP);
   updating = 1;

   IntPtr ip = new IntNode;
   ip->value = ti;
   if ((!deleters) || (deleters->value >= ti)) {
      ip->next = deleters;
      deleters = ip;
      }
   else {
      run = deleters;
      while ((run->next) && (run->next->value < ti)) 
         run = run->next;
      ip->next = run->next;
      run->next = ip;
      }
}


void
AnimObject::RemoveContinuous(int ti, ActionPtr ap)
{
   ActionDeletePtr run;   // add a deletion node, keep them in numerical order

   if (type == P_Set) {   // sets are special
      for (AOPtr a=objs; a; a=a->next)
         a->object->RemoveContinuous(ti,ap);
      return;
   }

   ActionDeletePtr adp = new ActionDeleteNode;
   adp->value = ti;
   adp->act = ap;
   if ((!continDeleters) || (continDeleters->value >= ti)) {
      adp->next = continDeleters;
      continDeleters = adp;
      }
   else {
      run = continDeleters;
      while ((run->next) && (run->next->value < ti)) 
         run = run->next;
      adp->next = run->next;
      run->next = adp;
      }
}


int
AnimObject::Program(int t, ActionPtr ap)
{
   int r;

   if (view->debug) 
      printf("DEBUG: AnimObject::Program at frame=%d\n",t);

   if (type == P_Set) {   // sets are special
      for (AOPtr a=objs; a; a=a->next)
         r = a->object->Program(t,ap);
      return(r);
   }

   if (updating == 0)    // not on Update list (which is 1 or -1)
      view->AddUpdateObject(this->viewAOP);
   updating = 1;

   ActionInfoPtr aip = new ActionInfo;
   aip->time = t;
   aip->originalAction = ap;
   aip->action = ap->Copy();
   aip->offsets = aip->doing = aip->action->head;
   aip->next = NULL;
   aip->prev = last;
   if (!first)
      { first = last = aip;
      }
   else
      { last->next = aip;
        last = aip;
      }
   return(ap->count);
}


int
AnimObject::ProgramContinuous(int t, ActionPtr ap)
{
   int r;

   if (view->debug) 
      printf("DEBUG: AnimObject::ProgramContinuous at frame=%d\n",t);

   if (type == P_Set) {   // sets are special
      for (AOPtr a=objs; a; a=a->next)
         r = a->object->ProgramContinuous(t,ap);
      return(r);
   }

   if (updating == 0)    // not on Update list (which is 1 or -1)
      view->AddUpdateObject(this->viewAOP);
   updating = 1;

   ActionInfoPtr aip = new ActionInfo;
   aip->time = t;
   aip->originalAction = ap;
   aip->action = ap->Copy();
   aip->offsets = aip->doing = aip->action->head;
   aip->next = NULL;
   aip->prev = lastContinuous;
   if (!firstContinuous)
      { firstContinuous = lastContinuous = aip;
      }
   else
      { lastContinuous->next = aip;
        lastContinuous = aip;
      }
   return(ap->count);
}


void
AnimObject::Update(int ti)    // should never get called on a Set
{
   ActionInfoPtr temp,old;
   int finished;
   Attachment att;

   if (view->debug)
      printf("DEBUG: AnimObject::Update time=%d\n",ti);

 /* This is complicated.  Basically, when an AnimObject has no programming*/
 /* anymore, we don't immediately take it off the updating list.  We wait one*/
 /* frame to do that.  This is so that if you're in the mode where only*/
 /* updated objects get redrawn, we make sure to redraw the object the last*/
 /* time it's on the update list.  If we took an object off the list right*/
 /* away, then we walked the update list to redraw, we would miss it.*/
 /* Below we've come around the second time on an object with no programming*/

   if (updating == -1) {  // pending removal from Update list, see below
      view->RemoveUpdateObject(this->viewAOP);
      updating = 0;
      return;
      }

   if (deleters && doDeletes(ti)) 
      return;

   doContDeletes(ti);  // see if contin Actions are scheduled to be removed

   temp = first;
   while (temp)
   { finished = 0;
     if (! temp->doing) {   // some kind of null action
        finished = 1;
        old = temp;
        }
     else if (temp->time < ti) // somehow skipped animating some frames
        { while ((temp->doing) && (temp->time < ti))
             { object->Trans(temp->action->type,
                                 temp->doing->dx,temp->doing->dy);
               temp->doing = temp->doing->nexto;
               if (!(temp->doing)) 
                  { finished = 1;
                    old = temp;
                    break;
                  }
               temp->time++;
  	     }
        }
     if (!finished)
        { if (temp->time == ti)    // time is right, perform the action 
             { object->Trans(temp->action->type,
                               temp->doing->dx,temp->doing->dy);
               temp->doing = temp->doing->nexto;
               temp->time++;
               if (!(temp->doing))
	          { old = temp;
                    finished = 1;
  		  }
               else
                  temp = temp->next;
	     }
          else
             temp = temp->next;
        }
     if (finished)
        temp = DeleteActionInfoPtr(old);
   }  // while

   temp = firstContinuous;
   while (temp) {
      if ((temp->time <= ti) && (temp->doing)) {
         object->Trans(temp->action->type,
                               temp->doing->dx,temp->doing->dy);
         temp->doing = temp->doing->nexto;
         if (!(temp->doing))   // hit end of list, so go back
            temp->doing = temp->offsets;
         }
      temp = temp->next;
      }
            
   doChanges(ti);

   attachDoneFrom = this;
   for (att=attachments; att; att=att->next)
       att->object->propagateAttachment(this,att,this);
   attachDoneFrom = NULL;

   if (!first && !firstContinuous && !changers && !deleters) 
      updating = -1;
        // nothing is pending anymore, get ready to move back to plain list
        // It will happen next time around
        // Don't want to remove it here because we want it to get
        //     drawn by drawAllUpdaters
}

              
Attachment
AnimObject::AttachTo(AnimObject *ao, PART dept, PART indept,
                     double xoff, double yoff)
{
   Attachment a;

   if (view->debug)
      printf("DEBUG: AnimObject::AttachTo %d to %d, parts %d - %d\n",
                 this,ao,dept,indept);

   if (type == P_Set) {
      cout << "Cannot attach a Set to another AnimObject" << endl;
      return NULL;
    }
   if (ao->Type() == P_Set) {
      cout << "Attaching to a Set AnimObject is not allowed" << endl;
      return NULL;
    }

   // check if ao already has attachment, if so, remove it
   if (attachedTo)
      ao->removeAttachment(this);

   a = new AttachNode;
   a->object = this;
   a->indept = indept;
   a->dept = dept;
   a->xoffset = xoff;
   a->yoffset = yoff;
   a->next = NULL;
   ao->addAttachment(a);
   attachedTo = ao;
   return(a);
}


int
AnimObject::Detach(Attachment att)
{
   Attachment a;

   if (view->debug)
      printf("DEBUG: AnimObject::Detach object %d from attachment %d\n",
                 this,att);

   if (att->object != this)
      return(0);
   if (!attachedTo) 
      return(0);
   for (a=attachedTo->getAttachments(); a; a=a->next)
       if (a == att) break;
   if (!a)
      return(0);

   attachedTo->removeAttachment(this);
   attachedTo = NULL;
   delete(att);
   return(1);
}


void
AnimObject::addAttachment(Attachment a)
{
   a->next = attachments;
   attachments = a;
}


void
AnimObject::removeAttachment(AnimObject *remover)
{
   Attachment att,old;

   if (!attachments) return;

   if (attachments->object == remover) {
      attachments = attachments->next;
      return;
    }
   old = attachments;
   for (att=attachments->next; att; att=att->next) {
       if (att->object == remover) {
          old->next = att->next;
          return;
       }
       old = att;
   }
}


void
AnimObject::propagateAttachment(AnimObject *fromobj, Attachment att, 
        AnimObject *starter)
{
   Loc        *deptloc, *indeptloc;
   double      xdiff, ydiff, currx, curry;
   Attachment  mine;

   if (attachDoneFrom == view->GetUpdatingObject())  
      return;            // Already propagated through this AnimObject.  
                         // Short-circuit here.

   DamageIt();
   deptloc = Where(att->dept);
   indeptloc = fromobj->Where(att->indept);
   xdiff = indeptloc->XCoord() - deptloc->XCoord();
   ydiff = indeptloc->YCoord() - deptloc->YCoord();
   object->MyLoc(currx, curry);
   object->Warp(currx+xdiff+(att->xoffset), curry+ydiff+(att->yoffset));
   DamageIt();

   attachDoneFrom = starter;

   for (mine=attachments; mine; mine=mine->next)
       mine->object->propagateAttachment(this,mine,starter);

   attachDoneFrom = NULL;

   delete deptloc;
   delete indeptloc;
}


// This takes an ActionInfoPtr out of an object's list of Actions, adjusts
// the list to make sure it's still correct (fixing first and last), deletes 
// the Action's memory, and then returns the next element in the list
//
struct ActionInfo *
AnimObject::DeleteActionInfoPtr(struct ActionInfo *temp)
{
   ActionInfoPtr old;

   if (temp == first)
      { first = temp->next;
        if (temp != last)
           first->prev = NULL;
        else
           last = NULL;
        old = temp;
        temp = first;
      }
   else
      { if (temp != last)
           temp->next->prev = temp->prev;
        else
           last = temp->prev;
        temp->prev->next = temp->next;
        old = temp;
        temp = temp->next;
      }
   if (old->action)
      delete old->action;  // removes offsets through Action's destructor
   delete old;
   return(temp);
}


/* This walks the list of Continuous Actions, checking for any with the ID
   of the given Action.  If it finds any, it removes them from the list,
   adjusts the list to make sure it's still correct (fixing first and last),
   deletes the ActionInfoPtr's memory, and then returns */

void
AnimObject::deleteContinActionInfoPtr(ActionPtr ap, int ti)
{
   ActionInfoPtr old,runner;
   
   runner = firstContinuous;
   while (runner) 
      if ((runner->originalAction == ap) &&
          (runner->time <= ti))     {  // got a match
         if (runner == firstContinuous)
            { firstContinuous = runner->next;
              if (runner != lastContinuous)
                 firstContinuous->prev = NULL;
              else
                 lastContinuous = NULL;
              old = runner;
              runner = firstContinuous;
              if (old->action)
                 delete old->action;
              delete old;
            }
         else  // runner != firstContinuous (in middle of list somewhere)
            { if (runner != lastContinuous)
                 runner->next->prev = runner->prev;
              else
                 lastContinuous = runner->prev;
              runner->prev->next = runner->next;
              old = runner;
              runner = runner->next;
              if (old->action)
                 delete old->action;
              delete old;
            }
         }
      else  // no match
         runner = runner->next;
}


int
AnimObject::doDeletes(int ti)
{
   if (deleters->value <= ti) {  // list is in sorted order
      object->DamageIt();
      view->RemoveUpdateObject(this->viewAOP);
      updating = 0;
      deleteMe();
      delete object;
      object = 0;   
      // deleter node will be freed by deleteMe()
      return(1);
   }
   return(0);
}


void
AnimObject::doContDeletes(int ti)
{
   ActionDeletePtr oldadp;

   while (continDeleters) {
      if (continDeleters->value <= ti) {  // list is in sorted order
         deleteContinActionInfoPtr(continDeleters->act,ti);
         oldadp = continDeleters;
         continDeleters = continDeleters->next;
         delete oldadp;
         }
      else
         break;
   }
}


void
AnimObject::doChanges(int ti)
{
   ImplPtr c,old;
   double x,y;

   for (c=changers; c && (c->time <= ti) ; ) {  // list is in sorted order
      object->DamageIt();
      type = c->objimpl->Type();
      view = c->objimpl->MyView();
      if (c->existingpos) {   // use exisiting object's pos, not one
         object->MyLoc(x,y);   // given when new impl created.
         c->objimpl->Warp(x,y);
         }
      delete object;
      object = c->objimpl; 
      old = c;
      c = changers = c->next;
      delete old;
      object->DamageIt();
   }
}


int
AnimObject::Intercepts(double dlx, double dby, double drx, double dty)
{
   double lx,by,rx,ty;

   object->BoundBox(&lx,&by,&rx,&ty);
   if (lx > drx) return(0);
   if (rx < dlx) return(0);
   if (ty < dby) return(0);
   if (by > dty) return(0);
   return(1);
}


void 
AnimObject::IsInSet(AnimObject *set)
{
   AOPtr newone = new AONode;  
   newone->object = set;
   newone->next = objs;
   newone->prev = NULL;
   if (objs)
     objs->prev = newone;
   objs = newone;
}


void
AnimObject::SetIsGone(AnimObject *gone)
{
   AOPtr ao;    // a set this object was in is gone, so remove the ref

   for (ao=objs; ao; ao=ao->next) {
     if (ao->object == gone) {
        if (ao->next)
           ao->next->prev = ao->prev;
        if (ao->prev)
           ao->prev->next = ao->next;
        if (ao == objs)
           objs = ao->next;
        delete(ao);
        return;
      }
   }
}
