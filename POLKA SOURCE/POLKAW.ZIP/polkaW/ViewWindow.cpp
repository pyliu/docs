/***************************************************************/
/*							                                   */
/*	       		ViewWindow.cpp			                       */
/*							                                   */
/***************************************************************/
/*       Copyright 1997 Georgia Institute of Technology 
                     -- Roman S. Khramets                      */

#include "ViewWindow.h"


ViewWindow::ViewWindow() {
	theView = NULL;
}


ViewWindow::ViewWindow( LPCTSTR title,
					    DWORD   dwStyle,
						RECT    *viewWndRect,
						HWND    hWndParent,
						HANDLE  hAppInstance,
						View    *aView ) {
	create( title, dwStyle, viewWndRect,
		hWndParent, hAppInstance, aView );
}


void ViewWindow::create( LPCTSTR title,
						 DWORD   dwStyle,
						 RECT    *viewWndRect,
						 HWND    hWndParent,
						 HANDLE  hAppInstance,
						 View    *aView ) {
    hWnd = CreateWindowEx( 0,
		"ViewWindow", title, dwStyle,
		viewWndRect->left, viewWndRect->top,
		viewWndRect->right, viewWndRect->bottom,
		hWndParent, NULL, (HINSTANCE)hAppInstance,
		(LPVOID)this);
	theView = aView;
}
