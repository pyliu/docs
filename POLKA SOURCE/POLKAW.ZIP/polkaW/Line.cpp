/***************************************************************/
/*							                                   */
/*	       		Line.cpp			                           */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#include "Line.h"


Line& 
Line::operator=(const Line& rhs) 
{
   if  (this == &rhs) return *this;
   AnimObject::operator=(rhs);
   return *this;
}
