/***************************************************************/
/*							                                   */
/*	       		TextImpl.cpp		                           */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#include "TextImpl.h"
#include "View.h"
#include "Drawable.h"
#include "Pixmap.h"


TextImpl::TextImpl(View *a, int v, double lx, double ly, COLOR c, 
            const char *fn, const char *ts, int o) : AnimObjectImpl(a,v,lx,ly)
{
   type = P_Text;
   strcpy(colorname,c);
   color = load_color(colorname);
   if (fn) { 
      fontid = load_font(fn); 
      strcpy(fontname,fn);
      }
   else {
      fontid = inq_font(); 
      fontname[0] = '\0';
      }
   strcpy(tstring,ts);
   orient = o;
   text_info(fontid,ts,&xext,&yext,&xoff,&yoff);
}


TextImpl::TextImpl(const TextImpl& t) : AnimObjectImpl( t )
{
   strcpy(colorname,t.colorname);
   color = t.color;
   fontid = t.fontid; 
   strcpy(fontname,t.fontname);
   strcpy(tstring,t.tstring);
   orient = t.orient;
   xext = t.xext;
   yext = t.yext;
   xoff = t.xoff;
   yoff = t.yoff;
}
   

TextImpl::~TextImpl()
{
   Erase();
}


void 
TextImpl::GetValues(View* *vi, int *v, double *lx, double *ly, COLOR c, 
            char* fn, char* ts, int *o)
{
   if (vi) *vi=view;
   if (v) *v=visibility;
   if (lx) *lx=locx;
   if (ly) *ly=locy;
   if (c) strcpy(c,colorname);
   if (fn) strcpy(fn,fontname);
   if (ts) strcpy(ts,tstring);
   if (o) *o=orient;
}	


LocPtr
TextImpl::Where(PART p)
{
   double	   lx,by,rx,ty;

   BoundBox(&lx,&by,&rx,&ty);

   switch (p)
   {
      case PART_C :
	 return( new Loc((lx + rx)/2.0,(by + ty)/2.0) );
      case PART_NW :
	 return( new Loc(lx,ty) );
      case PART_N :
	 return( new Loc((lx+ rx)/2.0,ty) );
      case PART_NE :
	 return( new Loc(rx,ty) );
      case PART_E :
	 return( new Loc(rx,(ty + by)/2.0) );
      case PART_SE :
	 return( new Loc(rx,by) );
      case PART_S :
	 return( new Loc((lx + rx)/2.0,by) );
      case PART_SW :
	 return( new Loc(lx,by) );
      case PART_W :
	 return( new Loc(lx,(by + ty)/2.0) );
   }
   return( new Loc(0.0,0.0) );
}


void
TextImpl::BoundBox(double *lx, double *by, double *rx, double *ty)
{
   double ex,ox,ey,oy;

   ex = view->SIZE_REAL_X(xext);
   ox = view->SIZE_REAL_X(xoff);
   ey = view->SIZE_REAL_Y(yext);
   oy = view->SIZE_REAL_Y(yoff);
   if (orient == 0) /* lower left */
      { *lx = locx - ox;
	*rx = locx + ex;
	*by = locy - oy;
	*ty = locy + ey;
      }
   else
      { *lx = locx - ex/2.0;
	*rx = locx + ex/2.0;
	*by = locy - ey/2.0;
	*ty = locy + ey/2.0;
      }
}


void
TextImpl::transSpecial(char *atype, double dx, double dy)
{
   if (streql(atype,"COLOR")) {
      color = get_pathcolor(dx,dy);
      DamageIt();
      }
   else if (streql(atype,"ALTER")) {
      DamageIt();
      strcpy(tstring,get_pathstring(dx,dy));
      text_info(fontid,tstring,&xext,&yext,&xoff,&yoff);
      DamageIt();
      }
}


void
TextImpl::Draw()
{
   drawer(color);
}


void
TextImpl::Erase()
{
   drawer(view->GetBgColor());
}


void
TextImpl::drawer(COLORINDEX col)
{
   double x0,y0;
   int oldfont; 
   FILL_STYLE oldfill;

   if (!visibility)
      return;

   if (orient == 0)
      {
        x0 = locx;
        y0 = locy;
      }
   else
      {
        x0 = locx - (view->SIZE_REAL_X(xext) / 2.0) - view->SIZE_REAL_X(xoff);
        y0 = locy - (view->SIZE_REAL_Y(yext) / 2.0) - view->SIZE_REAL_Y(yoff);
      }

   set_color(col);
   oldfont = set_font(fontid);
   oldfill = fill_style(POLKA_FILL_SOLID);
   XDrawString(view->DrawWindow(),inq_gc(),
               view->TO_PIX_X(x0),view->TO_PIX_Y(y0),tstring,strlen(tstring));
   fill_style(oldfill);
   set_font(oldfont);   
}
