/***************************************************************/
/*							                                   */
/*	       		Rectangle.cpp			                       */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#include "Rectangle.h"


Rectangle& 
Rectangle::operator=(const Rectangle& rhs) 
{
   if  (this == &rhs) return *this;
   AnimObject::operator=(rhs);
   return *this;
}
