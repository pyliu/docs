/***************************************************************/
/*							                                   */
/*	       		Bitmap.h			                           */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#ifndef __BITMAP_H
#define __BITMAP_H

#include "AnimObject.h"
#include "BitmapImpl.h"

class Bitmap: public AnimObject {
  public:
    Bitmap(View *vi, int v, double lx, double ly, int wid, int hei, 
            char data[], COLOR fg, COLOR bg)
    : AnimObject( new BitmapImpl(vi, v, lx, ly, wid, hei, data, fg, bg) ) {};
    Bitmap& operator=(const Bitmap&);
    void GetValues(View**vi, int *v, double *lx, double *ly, 
            int *wid, int *hei, char data[], COLOR fg, COLOR bg)
        { ((BitmapImpl*)object)->GetValues(vi,v,lx,ly,wid,hei,data,fg,bg); };
};

#endif
