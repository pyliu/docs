/***************************************************************/
/*							                                   */
/*	       		RectangleGroup.h			                   */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#ifndef __RECTANGLE_GROUP_H
#define __RECTANGLE_GROUP_H

#include "AnimObjectGroup.h"
#include "View.h"
#include "Rectangle.h"

class RectangleGroup : public AnimObjectGroup {
   public:
     double fill;
     RectangleGroup();
     int Make(View*, Rectangle *[], int, double, double, double, double);
};

#endif
