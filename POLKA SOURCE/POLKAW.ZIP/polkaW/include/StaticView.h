/***************************************************************/
/*							                                   */
/*	       		StaticView.h			                       */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#ifndef __STATIC_VIEW_H
#define __STATIC_VIEW_H

//#include <X11/StringDefs.h>

#include "polka_local.H"
#include "BaseView.h"

/* ********************************************************************

Class StaticView

******************************************************************** */

class ShapeNode;
class Shape;


class StaticView : public BaseView {
//  friend void staticresizeCB(Widget, XtPointer, XtPointer);
//  friend void staticresizeEH(Widget, XtPointer, XEvent *, Boolean *);

 private:
   int          created;          /* has window been made for it yet?        */
   int          mapped;           /* is it currently visible?                */
   int          debug;            /* is debugging on?                        */

//   Widget       topshell;         /* used to Popdown anim windows            */
//   Widget       easel;	          /* onscreen workSpace widget to 
//                                                         display anim frames */
//   Window	destwin; 	  /* current X window final target, blt into */
//   Pixmap       window;           /* offscreen to draw into, blt from        */

   COLORINDEX   bgcolor;          /* X bg color for window                   */
   int		pixX;		  /* window's width			     */
   int		pixY;		  /*          height			     */

   int          damaged;          /* used in drawing new shapes              */
   int          cliplx,clipby,cliprx,clipty;

   ShapeNode   *shapes;           /* Objects waiting to join the world   */
   ShapeNode   *shapesTail;

   void setupStaticWindow(const char *);
   void prepareAnim(/*Window*/);

   void addPendingShape(int, Shape *);
   void drawPendingShapes(int);
   void animNextFrame();
   void clear();

 protected:
   int     time;

 public:
   StaticView();
   ~StaticView();
   int Create(const char *title="Polka", int wid=0, int hei=0);
                // We want to take wid and hei defaults from resource file
   void Map();
   void UnMap();
   void Restart();
   void Refresh();
   int Animate(int, int);       
   int AnimateOne(int);
   int Simulate(int, int);       
   int CheckInput();

   void DrawPoint(int, int, int, const char *);
   void DrawLine(int, int, int, int, int, const char *);
   void DrawRectangle(int, int, int, int, int, const char *);
   void DrawEllipse(int, int, int, int, int, const char *);
   void DrawText(int, int, int, const char *, const char *, const char *);

   void SetDebug(int d) { debug = d; };
   int GetDebug() { return debug; };
   void GetDimension(int& x, int& y)
       { x = pixX; y = pixY; };
   int GetMapped() { return mapped; };

   /****** The routines below should not be called by outside code **********/

//   Window DrawWindow() { return window;};
   void AccumClip(int, int, int, int);
};

#endif
