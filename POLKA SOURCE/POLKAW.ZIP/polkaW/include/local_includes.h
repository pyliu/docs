/***************************************************************/
/*							                                   */
/*	       		local_includes.h			                   */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#ifndef __LOCAL_INCLUDES_H
#define __LOCAL_INCLUDES_H

#include <stdlib.h>
#include <stream.h>
#include <stdio.h>
#include <strings.h>
#include <stdarg.h>
#include <limits.h>
#include <math.h>

#endif
