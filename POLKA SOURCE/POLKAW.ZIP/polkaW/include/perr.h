#ifndef __PERR_H
#define __PERR_H

#define PERR(bSuccess, msg, action) { \
    if( !(bSuccess) ) { MessageBox(NULL, msg, "Error!", MB_OK|MB_ICONERROR); action; } }

#define ACTION_RETURN(x) { return (x); }
#define ACTION_NOTHING() { }

#endif
