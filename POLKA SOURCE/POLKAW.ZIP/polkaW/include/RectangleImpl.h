/***************************************************************/
/*							                                   */
/*	       		RectangleImpl.h			                       */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#ifndef __RECTANGLE_IMPL_H
#define __RECTANGLE_IMPL_H

#include "AnimObjectImpl.h"

class RectangleImpl: public AnimObjectImpl {
  private:
    double sizex,sizey;
    char colorname[32];
    COLORINDEX color;
    double fill;
    void drawer(COLORINDEX, FILL_STYLE);
    void transSpecial(char*, double, double);
  public:
    RectangleImpl(View *view, int v, double lx, double ly, 
                 double sx, double sy, COLOR c="black", double f=0.0) ;
    RectangleImpl(const RectangleImpl&);
    AnimObjectImpl *clone() const     // redef of virtual constructor
       { return new RectangleImpl(*this); };
    ~RectangleImpl();
    LocPtr Where(PART);
    void BoundBox(double*, double*, double*, double*);
    void Draw();
    void Erase();
    void GetValues(View**, int *, double *, double *, 
                 double *, double *, COLOR, double *);
  };

#endif
