/***************************************************************/
/*							                                   */
/*	       		common_includes.h			                   */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#ifndef __COMMON_INCLUDES_H
#define __COMMON_INCLUDES_H


/****** Forward declarations to make some compilers happy **********/

class BaseView;
class View;
class StaticView;
class AnimObject;
class ActionInfo;
class ActionDeleteNode;
class ImplNode;
class IntNode;
class TimerCBNode;
class OFFSET;

#endif
