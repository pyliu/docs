/***************************************************************/
/*							                                   */
/*	       		Set.h			                               */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#ifndef __SET_H
#define __SET_H

#include "polka_local.H"

#include "AnimObject.h"
#include "View.h"

class Set: public AnimObject {
  public: 
    Set(View * view, int num, AnimObject *ao[]); 
    Set(const Set& s);
    ~Set();
    AOPtr Objs() { return objs; };
    void RemoveFromSet(AnimObject *);
  private:
    void another(AnimObject *);
    Set& operator=(const Set&);
};

#endif
