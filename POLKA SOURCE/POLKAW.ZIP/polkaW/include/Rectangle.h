/***************************************************************/
/*							                                   */
/*	       		Rectangle.h			                           */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#ifndef __RECTANGLE_H
#define __RECTANGLE_H

#include "AnimObject.h"
#include "View.h"
#include "RectangleImpl.h"

class Rectangle: public AnimObject {
  public:
    Rectangle(View *vi, int v, double lx, double ly, 
                 double sx, double sy, COLOR c="black", double f=0.0) 
      : AnimObject( new RectangleImpl(vi, v, lx, ly, sx, sy, c, f) ) {};
    Rectangle& operator=(const Rectangle&);
    void GetValues(View**vi, int *v, double *lx, double *ly, 
                 double *sx, double *sy, COLOR c, double *f)
          { ((RectangleImpl*)object)->GetValues(vi,v,lx,ly,sx,sy,c,f); };
};

#endif
