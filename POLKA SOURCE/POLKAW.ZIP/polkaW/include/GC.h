/***************************************************************/
/*							                                   */
/*	       		GC.h	                                       */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#ifndef __GC_H
#define __GC_H

#include <windows.h>
#include "System.h"
#include "polka_local.H"
#include "polka_gc.H"

#define MAX_CLIPPING_RECTANGLES    10
#define None                       NULL

#define WhitePixel()      RGB(255,255,255)
#define BlackPixel()      RGB(0,0,0)

#define LineSolid         PS_SOLID
#define LineOnOffDash     PS_DASH
#define LineDoubleDash    PS_DASH

#define JoinMiter         PS_JOIN_MITER
#define JoinRound         PS_JOIN_ROUND
#define JoinBevel         PS_JOIN_BEVEL

#define CapButt           PS_ENDCAP_FLAT
#define CapRound          PS_ENDCAP_ROUND
#define CapProjecting     PS_ENDCAP_SQUARE

typedef BOOL Bool;
enum {
	Unsorted,
	YSorted,
	YXSorted,
	YXBanded
};

class __GC {
	friend class __Drawable;
	friend void XSetFillStyle( GC gc, UINT lbStyle );
    friend void XSetStipple( GC gc, LOGBRUSH *brushInfo );
public:
	__GC();
	~__GC();

	int XSetClipRectangles( int aClip_x_origin,      // (x,y) origin for
							int aClip_y_origin,      // clipping
							XRectangle *aRectangles, // a set of clipping rectangles
							int n,                  // number of clipping rectangles
							int ordering            // sorting order
						  );

	int XSetClipMask( Pixmap mask ); // the clipping mask - not supported!!!
	void XSetBackground( Pixel bkColor )  { background = bkColor; }
    void XSetForeground( Pixel fgColor );
    void XSetLineAttributes( DWORD line_width,
						     DWORD line_style,
						     DWORD cap_style,
						     DWORD join_style ); 
	void XSetFont( Font fontid );

	// accessors
	COLORREF   getBkColor()    { return background; }
	COLORREF   getTextColor()  { return textColor; }
	EXTLOGPEN *getPen()        { return &elpPen; }
	LOGBRUSH  *getPenBrush()   { return &lbPenBrush; }
	LOGBRUSH  *getBrush()      { return &lbBrush; }
	HFONT      getFont()       { return hFont; }

protected:
    int clip_x_origin;      // (x,y) origin for
    int clip_y_origin;      // clipping
    // clipping rectangles
	XRectangle rectangles[MAX_CLIPPING_RECTANGLES];
    // number of clipping rectangles
	int nRectangles;

	COLORREF   background; // background color
	COLORREF   textColor;
	EXTLOGPEN  elpPen;
	LOGBRUSH   lbPenBrush;
	LOGBRUSH   lbBrush;
	HFONT      hFont;

	void assignDefaults();
};


typedef void XGCValues;
GC XCreateGC( unsigned long valueMask, // mask for setting only certain fields of *values
 	          XGCValues *values // values
			);


int XSetClipRectangles( GC gc,                  // graphics context
						int clip_x_origin,      // (x,y) origin for
						int clip_y_origin,      // clipping
						XRectangle *rectangles, // a set of clipping rectangles
						int n,                  // number of clipping rectangles
						int ordering            // sorting order
					  );


int XSetClipMask( GC gc,      // graphics context
			      Pixmap mask // the clipping mask - not supported!!!
				);

void XSetBackground( GC gc,
				     Pixel bkColor );

void XSetForeground( GC gc, 
				     Pixel fgColor );

void XSetLineAttributes( GC    gc,
						 DWORD line_width,
						 DWORD line_style,
						 DWORD cap_style,
						 DWORD join_style );

void XSetFont( GC gc, 
			   Font fontid );

#endif