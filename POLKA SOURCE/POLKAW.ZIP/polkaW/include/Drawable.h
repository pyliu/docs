/***************************************************************/
/*							                                   */
/*	       		Drawable.h	                                   */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#ifndef __DRAWABLE_H
#define __DRAWABLE_H

#include <windows.h>
#include "System.h"
#include "polka_local.H"

enum { CoordModeOrigin, CoordModePrevious };
enum { Nonconvex };

BOOL XCopyArea( Drawable src,  // handle to source device context 
			    Drawable dest, // window to blt to
				GC  gc,        // the graphics context - mainly for cliping
			    int nXSrc,     // x-coordinate of source rectangle�s upper-left corner 
			    int nYSrc,     // y-coordinate of source rectangle�s upper-left corner 
			    int nWidth,    // width of destination rectangle 
			    int nHeight,   // height of destination rectangle 
			    int nXDest,    // x-coordinate of destination rectangle�s upper-left corner 
	            int nYDest     // y-coordinate of destination rectangle�s upper-left corner 
		      );
void XDrawRectangle( Drawable window, GC gc,
	int nStartX, int nStartY, int nWidth, int nHeight );
void XFillRectangle( Drawable window, GC gc,
	int nStartX, int nStartY, int nWidth, int nHeight );
void XDrawLine( Drawable window, GC gc,
	int nFromX, int nFromY, int nToX, int nToY );
void XDrawLines( Drawable window, GC gc,
	const XPoint *points, int nPoints, int mode );
void XFillPolygon( Drawable window, GC gc,
	const XPoint *points, int nPoints, int shape, int mode );
void XDrawEllipse( Drawable window, GC gc,
	int upperX, int upperY, unsigned int width, unsigned int height );
void XFillEllipse( Drawable window, GC gc,
	int upperX, int upperY, unsigned int width, unsigned int height );
void XDrawArc( Drawable window, GC gc,
	int upperX, int upperY,
	unsigned int width,
	unsigned int height,
	int angle1, int angle2 );
void XFillArc( Drawable window, GC gc,
	int upperX, int upperY,
	unsigned int width,
	unsigned int height,
	int angle1, int angle2 );
void XDrawString( Drawable window, GC gc,
	int x, int y, char *str, int length );
void XDrawCircle( Drawable window, GC gc,
	int x, int y, unsigned int radius );
void XFillCircle( Drawable window, GC gc,
	int x, int y, unsigned int radius );


class __Drawable {
public:
	__Drawable();
	virtual ~__Drawable();

	virtual BOOL XCopyArea( GC  gc,       // graphics context
		                    int nXDest,   // x-coordinate of destination rectangle�s upper-left corner 
							int nYDest,   // y-coordinate of destination rectangle�s upper-left corner 
							int nWidth,   // width of destination rectangle 
							int nHeight,  // height of destination rectangle 
						    Drawable src, // handle to source device context 
						    int nXSrc,    // x-coordinate of source rectangle�s upper-left corner 
						    int nYSrc     // y-coordinate of source rectangle�s upper-left corner 
						  );

	void XDrawRectangle( GC gc, int nStartX, int nStartY,
		int nWidth, int nHeight );
	void XFillRectangle( GC gc, int nStartX, int nStartY,
		int nWidth, int nHeight );
	void XDrawLine( GC gc, int nFromX, int nFromY,
		int nToX, int nToY );
	void XDrawLines( GC gc, const XPoint *points,
		int nPoints, int mode );
	void XFillPolygon( GC gc, const XPoint *points,
		int nPoints, int shape, int mode );
	void XDrawEllipse( GC gc, int upperX, int upperY,
		unsigned int width, unsigned int height );
	void XFillEllipse( GC gc, int upperX, int upperY,
		unsigned int width, unsigned int height );
	void XDrawArc( GC gc, int upperX, int upperY,
		unsigned int width, unsigned int height,
		int angle1, int angle2 );
	void XFillArc( GC gc, int upperX, int upperY,
		unsigned int width, unsigned int height,
		int angle1, int angle2 );
	void XDrawString( GC gc, int x, int y, char *str, int length );
	void XDrawCircle( GC gc, int x, int y, unsigned int radius );
	void XFillCircle( GC gc, int x, int y, unsigned int radius );

	// accessors
	HDC getDC() { return hdc; }

protected:
	// device context to this Drawable
	HDC hdc;

	void copyPolyFillAttributes( GC gc );
	void copyLineDrawingAttributes( GC gc );
	void copyTextDrawingAttributes( GC gc );
	int setUpPath( GC gc, const XPoint *points, int nPoints, int mode );
	void calcArc( int upperX,
		          int upperY,
				  unsigned int width,
				  unsigned int height,
				  int angle1,
				  int angle2,
				  int &startX,
				  int &startY,
				  int &stopX,
				  int &stopY );
};

#endif