/***************************************************************/
/*							                                   */
/*	       		misc.h			                               */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#ifndef __MISC_H
#define __MISC_H

extern WNDPROC EditWindowProc;
WNDPROC getEditWindowProc();

#endif