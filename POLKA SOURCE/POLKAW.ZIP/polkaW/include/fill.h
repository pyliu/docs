/***************************************************************/
/*							                                   */
/*	       		fill.h			                               */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#ifndef __FILL_H // windows.h must be included before this file
#define __FILL_H

// fill styles
#define FillSolid             BS_SOLID
#define FillOpaqueStippled    BS_PATTERN8X8


void XSetFillStyle( GC gc, UINT lbStyle );
void XSetStipple( GC gc, LOGBRUSH *brushInfo );

#endif