/***************************************************************/
/*							                                   */
/*	       		PolygonImpl.h			                       */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#ifndef __POLYGON_IMPL_H
#define __POLYGON_IMPL_H

#include "AnimObjectImpl.h"

class PolygonImpl: public AnimObjectImpl {
  private:
    int vertices;
    double vx[32];
    double vy[32];
    char colorname[32];
    COLORINDEX color;
    double fill;
    void drawer(COLORINDEX, FILL_STYLE);
    void transSpecial(char *, double, double);
  public:
    PolygonImpl(View *view, int v, double lx, double ly, int vert, 
                double vx[], double vy[], COLOR c="black", double f=0.0);
    PolygonImpl(const PolygonImpl&);
    AnimObjectImpl *clone() const     // redef of virtual constructor
       { return new PolygonImpl(*this); };
    ~PolygonImpl();
    LocPtr Where(PART);
    void BoundBox(double*, double*, double*, double*);
    void Draw();
    void Erase();
    void GetValues(View**, int *, double *, double *, int *, 
                double[], double[], COLOR, double *);
  };

#endif
