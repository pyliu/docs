/***************************************************************/
/*							                                   */
/*	       		BitmapImpl.h	 		                       */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#ifndef __BITMAP_IMPL_H
#define __BITMAP_IMPL_H

#include "AnimObjectImpl.h"

class BitmapImpl: public AnimObjectImpl {
  private:
    Pixmap pixmap;
    int iwidth,iheight;
    char fgcolname[32];
    char bgcolname[32];
    char *bmdata;
    void transSpecial(char*, double, double);
  public:
    BitmapImpl(View *, int, double, double, int, int, char[], COLOR, COLOR);
    BitmapImpl(const BitmapImpl&);
    AnimObjectImpl *clone() const     // redef of virtual constructor
       { return new BitmapImpl(*this); };
    ~BitmapImpl();
    LocPtr Where(PART);
    void BoundBox(double*, double*, double*, double*);
    void Draw();
    void Erase();
    void GetValues(View**, int *, double *, double *, 
            int *, int *, char[], COLOR, COLOR);
};

#endif
