/***************************************************************/
/*							                                   */
/*	       		ResizeMode.h			                       */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#ifndef __RESIZE_MODE_H
#define __RESIZE_MODE_H

typedef int ResizeMode;

#endif
