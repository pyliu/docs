/***************************************************************/
/*							                                   */
/*	       		Polygon.h			                           */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#ifndef __POLYGON_H
#define __POLYGON_H

#include "AnimObject.h"
#include "PolygonImpl.h"

class Polygon: public AnimObject {
  public:
    Polygon(View *vi, int v, double lx, double ly, int vert, 
                double vx[], double vy[], COLOR c="black", double f=0.0)
      : AnimObject( new PolygonImpl(vi, v, lx, ly, vert, vx, vy, c, f) ) {} ;
    Polygon& operator=(const Polygon&);
    void GetValues(View**vi, int *v, double *lx, double *ly, int *vert, 
                double vx[], double vy[], COLOR c, double *f)
          { ((PolygonImpl*)object)->GetValues(vi,v,lx,ly,vert,vx,vy,c,f); };
};

#endif
