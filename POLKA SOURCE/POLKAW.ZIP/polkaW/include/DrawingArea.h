/***************************************************************/
/*							                                   */
/*	       		DrawingArea.h			                       */
/*							                                   */
/***************************************************************/
/*       Copyright 1997 Georgia Institute of Technology 
                     -- Roman S. Khramets                      */

#ifndef __DRAWING_AREA_H
#define __DRAWING_AREA_H

#include "System.h"
#include "Widget.h"

class DrawingArea: public __Widget {
public:
	DrawingArea();
	~DrawingArea();
};

#endif