/***************************************************************/
/*							                                   */
/*	       		polka.H			                               */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#ifndef _POLKA_H
#define _POLKA_H

#define False 0
#define True  1

#include "common_includes.h"
#include "ResizeMode.h"

#include "Init.h"
#include "Animator.h"
#include "BaseView.h"
#include "View.h"
#include "StaticView.h"


/* ********************************************************************

Constituent Classes Loc, AnimObject, and Action

******************************************************************** */

#include "Loc.h"
#include "AnimObjectImpl.h"
#include "LineImpl.h"
#include "RectangleImpl.h"
#include "CircleImpl.h"
#include "EllipseImpl.h"
#include "PolylineImpl.h"
#include "PieImpl.h"
#include "SplineImpl.h"
#include "PolygonImpl.h"
#include "TextImpl.h"
#include "BitmapImpl.h"
#include "SetImpl.h"

#include "AnimObject.h"
#include "Line.h"
#include "Rectangle.h"
#include "Circle.h"
#include "Ellipse.h"
#include "Polyline.h"
#include "Pie.h"
#include "Spline.h"
#include "Polygon.h"
#include "Text.h"
#include "Bitmap.h"
#include "Set.h"

#include "AnimObjectGroup.h"
#include "LineGroup.h"
#include "RectangleGroup.h"
#include "CircleGroup.h"

#include "Action.h"

#endif    /* _POLKA_H */
