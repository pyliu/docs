/***************************************************************/
/*							                                   */
/*	       		Loc2Desc.h			                           */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#ifndef __LOC2DESC_H
#define __LOC2DESC_H

#include "Loc.h"

class Loc2Desc {
   public:
      int rows;
      int cols;
      double llx,lly;
      double urx,ury;
      Loc2Desc();
      int Make(Loc*[]);
 } ;

#endif
