/***************************************************************/
/*							                                   */
/*	       		Loc1Desc.h			                           */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#ifndef __LOC1DESC_H
#define __LOC1DESC_H

#include "Loc.h"

class Loc1Desc {
   public:
      int num;
      double fx,fy;
      double tx,ty;
      Loc1Desc();
      int Make(Loc*[]);
} ;

#endif
