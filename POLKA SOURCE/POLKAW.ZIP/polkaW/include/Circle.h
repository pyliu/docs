/***************************************************************/
/*							                                   */
/*	       		Circle.h			                           */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#ifndef __CIRCLE_H
#define __CIRCLE_H

#include "AnimObject.h"
#include "Circle.h"
#include "CircleImpl.h"

class Circle: public AnimObject {
  public:
    Circle(View *vi, int v, double lx, double ly, double r, 
              COLOR c="black", double f=0.0)
      : AnimObject( new CircleImpl(vi, v, lx, ly, r, c, f) ) {};
    Circle& operator=(const Circle&);
    void GetValues(View**vi, int *v, double *lx, double *ly, double *r, 
              COLOR c, double *f)
          { ((CircleImpl*)object)->GetValues(vi,v,lx,ly,r,c,f); };
};

#endif
