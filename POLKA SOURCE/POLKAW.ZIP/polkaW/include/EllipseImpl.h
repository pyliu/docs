/***************************************************************/
/*							                                   */
/*	       		EllipseImpl.h			                       */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#ifndef __ELLIPSE_IMPL_H
#define __ELLIPSE_IMPL_H

#include "AnimObjectImpl.h"

class EllipseImpl: public AnimObjectImpl {
  private:
    double sizex,sizey;
    char colorname[32];
    COLORINDEX color;
    double fill;
    void drawer(COLORINDEX, FILL_STYLE);
    void transSpecial(char*, double, double);
  public:
    EllipseImpl(View *view, int v, double lx, double ly, 
                double sx, double sy, COLOR c="black", double f=0.0);
    EllipseImpl(const EllipseImpl&);
    AnimObjectImpl *clone() const     // redef of virtual constructor
       { return new EllipseImpl(*this); };
    ~EllipseImpl();
    LocPtr Where(PART);
    void BoundBox(double*, double*, double*, double*);
    void Draw();
    void Erase();
    void GetValues(View**, int *, double *, double *, 
                double *, double *, COLOR, double *);
  };

#endif
