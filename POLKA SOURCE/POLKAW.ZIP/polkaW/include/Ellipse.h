/***************************************************************/
/*							                                   */
/*	       		Ellipse.h			                           */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#ifndef __ELLIPSE_H
#define __ELLIPSE_H

#include "AnimObject.h"
#include "EllipseImpl.h"

class Ellipse: public AnimObject {
  public:
    Ellipse(View *vi, int v, double lx, double ly, 
                double sx, double sy, COLOR c="black", double f=0.0)
      : AnimObject( new EllipseImpl(vi, v, lx, ly, sx, sy, c, f) ) {};
    Ellipse& operator=(const Ellipse&);
    void GetValues(View**vi, int *v, double *lx, double *ly, 
                double *sx, double *sy, COLOR c, double *f)
          { ((EllipseImpl*)object)->GetValues(vi,v,lx,ly,sx,sy,c,f); };
};

#endif
