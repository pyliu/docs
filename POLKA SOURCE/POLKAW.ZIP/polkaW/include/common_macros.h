/***************************************************************/
/*							                                   */
/*	       		common_macros.h			                       */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#ifndef __COMMON_MACROS_H
#define __COMMON_MACROS_H

#define   WIDTH             500
#define   HEIGHT            500
#define   MAXSTRINGLENGTH   256
#define   ZERO              0
#define   MYPI              ((double)3.14159)

#define WHITE             0
#define YELLOW            1
#define GREEN             2
#define BLUE              3
#define ORANGE            4
#define RED               5
#define MAROON            6
#define BLACK             7

#define   POLKA_BASE_FILL         0
#define   POLKA_NUM_FILL         41
#define   POLKA_FILL_OUTLINE     POLKA_BASE_FILL
#define   POLKA_FILL_SOLID       POLKA_BASE_FILL + POLKA_NUM_FILL - 1

#define   POLKA_ACTION_POINTS      20
#define   POLKA_ACTION_NUMTYPES    3


#define   MIN(A,B)        ( (A) < (B) ? (A) : (B) )

#ifndef ABS
#define  ABS(A)       ( (A) < 0.0 ? -(A) : (A) )
#endif

#define  BETWEEN(A,X,B) ( ((A) <= (X)) && ((X) <= (B)) )
#define  MAXPARAMS   16

#endif
