/***************************************************************/
/*							                                   */
/*	       		BaseView.h			                           */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#ifndef __BASE_VIEW_H
#define __BASE_VIEW_H

/* ********************************************************************

Class BaseView

******************************************************************** */


class BaseView {
   public:
     virtual int Animate(int, int) = 0;
     virtual int AnimateOne(int) = 0;
};

#endif
