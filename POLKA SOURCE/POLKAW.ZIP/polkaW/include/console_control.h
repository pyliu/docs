/***************************************************************/
/*							                                   */
/*	       		console_control.h	                           */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#ifndef __CONSOLE_CONTROL_H
#define __CONSOLE_CONTROL_H

enum {SUSPENDED, OUTPUT, INPUT};

void editSuspend();
void editOutput();
char *editInput();
void editEnter();
int getEditState();
void setEditState(int aState);

#endif