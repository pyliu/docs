/***************************************************************/
/*							                                   */
/*	       		Action.h			                           */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#ifndef __ACTION_H
#define __ACTION_H

#include "polka_local.H"
#include "polka_action.H"

#include "Loc.h"

/*********************************************************************
Class Action
******************************************************************** */

enum MOTION {
   STRAIGHT,
   CLOCKWISE,
   COUNTERCLOCKWISE
};


class Action {
   friend AnimObject;

   private:
      char           type[32];
      struct OFFSET *head;
      struct OFFSET *tail;
      int  	     count;
      void               AddOffsetAtEnd(double x, double y);
      void               DeleteOffsetFromFront();
      void               DeleteOffsetFromEnd();

   public:
      Action() { *type= '\0'; head = tail = NULL; count = 0; };
      Action(const char *t) { strcpy(type,t); head = tail = NULL; count = 0; };
      Action(const char *, int, double [], double []);
      Action(const char *, int);
      Action(const char *, MOTION);
      Action(const char *, const char *);
      Action(const char *, LocPtr, LocPtr, MOTION);
      Action(const char *, LocPtr, LocPtr, double);
      Action(const char *, LocPtr, LocPtr, int);
      ~Action();

      void      Print();
inline int       Length() { return( count ); };
      double    Deltax();
      double    Deltay();
      ActionPtr AddHead(int);
      ActionPtr AddTail(int);
      ActionPtr DeleteHead(int);
      ActionPtr DeleteTail(int);
      ActionPtr Copy();
      ActionPtr ChangeType(const char *);
      ActionPtr Reverse();
      ActionPtr Smooth();
      ActionPtr Rotate(int);
      ActionPtr Scale(double, double);
      ActionPtr Extend(double, double);
      ActionPtr Interpolate(double);
      ActionPtr Example(LocPtr, LocPtr);
      ActionPtr Iterate(int);
      ActionPtr Concatenate(ActionPtr);
      ActionPtr Compose(ActionPtr);
};

#endif
