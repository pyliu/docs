/***************************************************************/
/*							                                   */
/*	       		Init.h			                               */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#ifndef __INIT_H
#define __INIT_H

/* ********************************************************************
Initialization
******************************************************************** */

//typedef void (*APP_CALLBACK)(Widget, XtPointer, XtPointer);

typedef void (*APP_CALLBACK)(void *param/*Widget, XtPointer, XtPointer*/);

void PolkaInit();

//void PolkaInitialize(Display *, XtAppContext, Widget);

void PolkaInitialize(/*Display *, XtAppContext, Widget*/);
void PolkaDisableControls();
void PolkaSetCallbacks(APP_CALLBACK, APP_CALLBACK, APP_CALLBACK,
                       APP_CALLBACK, APP_CALLBACK);
void PolkaReset();
void PolkaResume();
void PolkaPause();
void PolkaSpeed(int);

#define RESET_COMMAND         100
#define PAUSE_COMMAND         101
#define RESUME_COMMAND        102

#endif
