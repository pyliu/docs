/***************************************************************/
/*							                                   */
/*	       		Polyline.h			                           */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#ifndef __POLYLINE_H
#define __POLYLINE_H

#include "AnimObject.h"
#include "PolylineImpl.h"

class Polyline: public AnimObject {
  public:
    Polyline(View *vi, int v, double lx, double ly, int ve, 
                double vtx[], double vty[], COLOR c="black", 
                double w=0.0, double s=1.0, int a=0)
    : AnimObject( new PolylineImpl(vi, v, lx, ly, ve, vtx, vty, c, w, s, a))
          {};
    Polyline& operator=(const Polyline&);
    void GetValues(View**vi, int *v, double *lx, double *ly, int *ve, 
                double vtx[], double vty[], COLOR c, 
                double *w, double *s, int *a)
          { ((PolylineImpl*)object)->GetValues(vi,v,lx,ly,ve,vtx,vty,c,
                               w,s,a); };
};

#endif
