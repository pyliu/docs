/***************************************************************/
/*							                                   */
/*	       		constants.h			                           */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#ifndef __CONSTANTS_H
#define __CONSTANTS_H

#include "ResizeMode.h"

extern const ResizeMode ConstantAspect;
extern const ResizeMode CoordStretch;

#endif
