/***************************************************************/
/*							                                   */
/*	       		Line.h			                               */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#ifndef __LINE_H
#define __LINE_H

#include "AnimObject.h"
#include "View.h"
#include "LineImpl.h"

class Line: public AnimObject {
  public:
    Line(View *vi, int v, double lx, double ly, double sx, double sy, 
            COLOR c="black", double w=0.0, double s=1.0, int a=0)
      : AnimObject( new LineImpl(vi, v, lx, ly, sx, sy, c, w, s, a) ) {};
    Line& operator=(const Line&);
    void GetValues(View**vi, int* v, double* lx, double* ly, 
                   double* sx, double* sy, COLOR c, double* w,
                   double* s, int* a)
          { ((LineImpl*)object)->GetValues(vi,v,lx,ly,sx,sy,c,w,s,a); };
};

#endif
