/***************************************************************/
/*							                                   */
/*	       		CircleGroup.h			                       */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#ifndef __CIRCLE_GROUP_H
#define __CIRCLE_GROUP_H

#include "AnimObjectGroup.h"
#include "View.h"
#include "Circle.h"

class CircleGroup : public AnimObjectGroup {
   public:
     double fill;
     CircleGroup();
     int Make(View*, Circle *[], int, double, double, double, double);
};

#endif
