/***************************************************************/
/*							                                   */
/*	       		AnimObjectImpl.h			                   */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#ifndef __ANIM_OBJECT_IMPL_H
#define __ANIM_OBJECT_IMPL_H

#include "polka_local.H"

#include "AnimObjectCommon.h"
#include "Loc.h"

/* ********************************************************************
Class AnimObjectImpl
******************************************************************** */


class AnimObjectImpl {
  private:
    virtual void transSpecial(char*, double, double) {};
  protected:
    View *view;
    class AnimObject *wrapper;
    AnimObjectType type;
    int visibility;
    double locx,locy;
  public:
    AnimObjectImpl(View *, int, double, double);
    AnimObjectImpl(const AnimObjectImpl&);
    virtual ~AnimObjectImpl() {};
    virtual AnimObjectImpl *clone() const = 0; // virtual constructor
    void SetWrapper(AnimObject *w) { wrapper = w; };
    void Warp(double x, double y) { locx=x; locy=y; }; // AnimObject::doChanges
    void MyLoc(double& x, double& y) { x=locx; y=locy; } // uses these two
    AnimObjectType Type() { return type; };
    View *MyView() { return view; };
    void DamageIt();
    virtual void Trans(char*, double, double);
    virtual void Draw() = 0;
    virtual void Erase() = 0;
    virtual LocPtr Where(PART) { return new Loc(locx,locy); };
    virtual void BoundBox(double *, double *, double *, double *) = 0;
    virtual int IsPickIn(double, double);
};

#endif
