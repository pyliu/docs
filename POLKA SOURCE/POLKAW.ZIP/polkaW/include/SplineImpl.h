/***************************************************************/
/*							                                   */
/*	       		SplineImpl.h			                       */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#ifndef __SPLINE_IMPL_H
#define __SPLINE_IMPL_H

#include "AnimObjectImpl.h"

class SplineImpl: public AnimObjectImpl {
  private:
    int vertices;
    double vx[32];
    double vy[32];
    char colorname[32];
    COLORINDEX color;
    double width;
    double style;
    void drawer(COLORINDEX);
    void transSpecial(char *, double, double);
  public:
    SplineImpl(View *view, int v, double lx, double ly, int ve, 
                double vx[], double vy[], COLOR c="black", double w=0.0, 
                double s=1.0);
    SplineImpl(const SplineImpl&);
    AnimObjectImpl *clone() const     // redef of virtual constructor
       { return new SplineImpl(*this); };
    ~SplineImpl();
    LocPtr Where(PART);
    void BoundBox(double*, double*, double*, double*);
    void Draw();
    void Erase();
    void GetValues(View**, int *, double *, double *, int *, 
                double[], double[], COLOR, double *, double *);
  };

#endif
