/***************************************************************/
/*							                                   */
/*	       		LineGroup.h			                           */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#ifndef __LINE_GROUP_H
#define __LINE_GROUP_H

#include "AnimObjectGroup.h"
#include "View.h"
#include "Line.h"

class LineGroup : public AnimObjectGroup {
   public:
      double linewidth;
      double linestyle;
      int arrow;
      LineGroup();
      int Make(View*, Line *[], int, double, double, double, double);
};

#endif
