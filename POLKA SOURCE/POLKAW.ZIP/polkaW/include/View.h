/***************************************************************/
/*							                                   */
/*	       		View.h			                               */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#ifndef __VIEW_H
#define __VIEW_H

#include "polka_local.H"

#include "BaseView.h"
#include "AnimObject.h"
#include "ResizeMode.h"


/* ********************************************************************

Class View

******************************************************************** */

#define REFRESH_ALL        0
#define REFRESH_MODIFIED   1

extern const ResizeMode ConstantAspect;
extern const ResizeMode CoordStretch;

// forward declarations
//
#include "System.h"
//

class View : public BaseView {
  friend class AnimObject;    // maybe make these specific mem fcts later
  friend class AnimObjectImpl;
  friend void resizeEH( Widget w );
//  friend void resizeCB(Widget, XtPointer, XtPointer);
  friend void SelectPoint(View *xtp, int x, int y);

 private:
   int          created;          /* has window been made for it yet?        */
   int          mapped;           /* is it currently visible?                */
   int          debug;            /* is debugging on?                        */
   int          redrawall;        /* redraw all objects for next frame?      */

// system dependent
   Widget       topshell; /* used to Popdown anim windows            */
   Widget       easel;    /* onscreen workSpace widget to 
                             display anim frames                     */
   Window	    destwin;  /* current X window final target, blt into */
   Pixmap       window;   /* offscreen to draw into, blt from        */
//
   
   COLORINDEX   bgcolor;          /* X bg color for window                   */
   ResizeMode   resizeMode;       /* what to do when viewer resizes          */
   int		pixX;		  /* window's width			     */
   int		pixY;		  /*          height			     */
   double       aspectx;          /* aspect ratio, pixels -> coords          */
   double       aspecty;          /* aspect ratio, pixels -> coords          */
   double	olx,oby,orx,oty;  /* originals				     */
   double	lx,by,rx,ty;	  /* working vals			     */
   double       dx,dy;
   double       damlx,damrx,
                damby,damty;      /* damaged bounding box                    */
   double       boxpad;           /* padding to check object intersection    */
   int          needrefresh;      /* do next animation frame by refresh?     */
   int          getMouse;	  /* Waiting for mouse input (T/F)	     */
   int	        mousex,mousey;    /*    Coords of mouse input		     */
   int		numobjects;	  /* # of basic AnimObjects in window        */
   int		motionblur;	  /* disable clear for printing window dumps */
   AOPtr	AOHead;   	  /* current configuration of AnimObjects    */
   AOPtr	AOTail;
   AOPtr        PendingHead;      /* AnimObjects waiting to join the world   */
   AOPtr        PendingTail;
   AOPtr        UpdateHead;       /* AnimObjects with pending Actions        */
   AOPtr        UpdateTail;
   AnimObject  *updatingObject;   /* Used to determine where                 */
                                  /* attachment chain originated from        */
   TimerCBNode *timerCallbacks;   /* list of user callbacks at a frame #     */
   int          inTimerCallback;  /* can't call Animate if true              */

   void setupWindow(const char *);

   // Change from: void prepareAnim( Window )
   void prepareAnim( Window );
   //

   void animNextFrame();
   void clear();

   void originateAnimObjects(int);
   void updateAll(int);
   void drawAll();
   void drawAllUpdaters();

   void fastDraw();
   void fastOriginate(int);

   inline void fixPad() { boxpad = 2.0 / (double)pixX * dx; };
   inline double  ROUNDER(double Z) {return( Z > 0.0 ? 
                                        (Z + 0.5) : (Z - 0.5) );};

 protected:
   int     time;

 public:
   View();
   ~View();
   int Create(const char *title="Polka", ResizeMode rm=CoordStretch,
              int wid=0, int hei=0);
                // We want to take wid and hei defaults from resource file
   void Map();
   void UnMap();
   void Restart();
   void Refresh();

   int Animate(int, int);       
   int AnimateOne(int);
   int Simulate(int, int);       
   int FastAnimate(int, int);
   void RegisterTimerCallback(int, TIMER_CALLBACK, void*);
   int CheckInput();

   int PickCoord(double&, double&);
   int PickAnimObject(class AnimObject* &);
   AnimObject *ObjectAt(double, double);

   void SetDebug(int d) { debug = d; };
   void SetRedrawAll(int r) { redrawall = r; }
   void SetCoord(double, double, double, double);
   void SetBgColor(const char *);
   int GetDebug() { return debug; };
   void GetCoord(double& ilx, double& iby, double& irx, double& ity)
       { ilx = lx; iby = by; irx = rx; ity = ty; };
   COLORINDEX GetBgColor() { return bgcolor; };
   void GetDimension(int& x, int& y)
       { x = pixX; y = pixY; };
   int GetMapped() { return mapped; };


   /****** The routines below should not be called by outside code **********/

   inline int     PIXX() { return(pixX); };
   inline int     PIXY() { return(pixY); };
   inline int     TO_PIX_X(double A)     
         { return( (int) ROUNDER( pixX * (((A)-lx)/dx) ) ); };
   inline int     TO_PIX_Y(double A)     
         { return( (int) ROUNDER( pixY * ((dy-(A)+by)/dy) ) ); };
   inline double  TO_REAL_X(int B)    
         { return( ((double)(B)/(double)pixX) * dx + lx ); };
   inline double  TO_REAL_Y(int B)    
         { return( ((double)(pixY-B)/(double)pixY) * dy + by ); };
   inline int     SIZE_PIX_X(double A)   
         { return( (int) ROUNDER( pixX * ((A)/dx)) ); };
   inline int     SIZE_PIX_Y(double A)   
         { return( (int) ROUNDER( pixY * ((A)/dy)) ); };
   inline double  SIZE_REAL_X(int B)  
         { return( ((double)(B)/(double)pixX) * dx); };
   inline double  SIZE_REAL_Y(int B)  
         { return( ((double)(B)/(double)pixY) * dy); };
   void RefreshNeeded(int r) { needrefresh = r; };
   void AlterLLCoord(double, double);
   void AlterURCoord(double, double);

   // Change from: Window DrawWindow()
   Pixmap DrawWindow() { return window; };
   //

   void DamageCheck(double l_x, double b_y, double r_x, double t_y) {
      if (l_x < damlx) damlx = l_x;
      if (r_x > damrx) damrx = r_x;
      if (b_y < damby) damby = b_y;
      if (t_y > damty) damty = t_y;
      };
   AnimObject *GetUpdatingObject() { return updatingObject; };
   void AddUpdateObject(AOPtr);
   void RemoveUpdateObject(AOPtr);
};

#endif
