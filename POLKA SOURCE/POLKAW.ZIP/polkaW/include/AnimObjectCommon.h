/***************************************************************/
/*							                                   */
/*	       		AnimObjectCommon.h			                   */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#ifndef __ANIM_OBJECT_COMMON_H
#define __ANIM_OBJECT_COMMON_H

enum AnimObjectType {
   P_Line,
   P_Rectangle,
   P_Circle,
   P_Ellipse,
   P_Polygon,
   P_Polyline,
   P_Pie,
   P_Spline,
   P_Text,
   P_Bitmap,
   P_Set,
   P_Misc
};


typedef struct _AttachNode
{
   class  AnimObject *object;
   PART              dept;
   PART              indept;
   double            xoffset;
   double            yoffset;
   struct _AttachNode *next;
} AttachNode, *Attachment;

#endif
