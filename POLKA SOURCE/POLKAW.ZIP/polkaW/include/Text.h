/***************************************************************/
/*							                                   */
/*	       		Text.h			                               */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */
#ifndef __TEXT_H
#define __TEXT_H

#include "AnimObject.h"
#include "TextImpl.h"

class Text: public AnimObject {
  public:
    Text(View *vi, int v, double lx, double ly, COLOR c, 
            const char *fn, const char *ts, int o)
      : AnimObject( new TextImpl(vi, v, lx, ly, c, fn, ts, o) ) {};
    Text& operator=(const Text&);
    void GetValues(View**vi, int *v, double *lx, double *ly, COLOR c, 
            char* fn, char* ts, int *o)
          { ((TextImpl*)object)->GetValues(vi,v,lx,ly,c,fn,ts,o); };
};

#endif
