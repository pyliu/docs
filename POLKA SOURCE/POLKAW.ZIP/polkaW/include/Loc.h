/***************************************************************/
/*							                                   */
/*	       		Loc.h			                               */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#ifndef __LOC_H
#define __LOC_H

/*** forward declarations ***/
typedef class Loc       *LocPtr;
typedef class Action    *ActionPtr;



/* ********************************************************************
Class Loc
******************************************************************** */

#ifndef _EQUAL
#define  _EQUAL(A,B)   ( ((A) - 0.000001 < (B)) && ((B) < (A) + 0.000001) )
#endif


class Loc {
   private:
      double	x;
      double	y;

   public:
      Loc() { x = 0.0; y = 0.0; };
      Loc(double cx, double cy) {
         this->x = cx;
         this->y = cy;
         };
      ~Loc() { };

      LocPtr Copy() { return ( new Loc (x,y) ); };
      LocPtr Modify(double mx, double my) {
         return ( new Loc (this->x+mx,this->y+my) );
         };
      void Alter(double newx, double newy) { x=newx; y=newy; };
      double XCoord() { return( x ); };
      double YCoord() { return( y ); };
      int operator == (Loc &loc) {
         return( _EQUAL(x,loc.x) && _EQUAL(y,loc.y) );
      };
};

#endif
