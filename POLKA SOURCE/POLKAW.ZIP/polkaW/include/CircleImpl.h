/***************************************************************/
/*							                                   */
/*	       		CircleImpl.h			                       */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#ifndef __CIRCLE_IMPL_H
#define __CIRCLE_IMPL_H

#include "AnimObjectImpl.h"

class CircleImpl: public AnimObjectImpl {
  private:
    double radius;
    char colorname[32];
    COLORINDEX color;
    double fill;
    void drawer(COLORINDEX, FILL_STYLE);
    void transSpecial(char*, double, double);
  public:
    CircleImpl(View *view, int v, double lx, double ly, double r, 
              COLOR c="black", double f=0.0);
    CircleImpl(const CircleImpl&);
    AnimObjectImpl *clone() const     // redef of virtual constructor
       { return new CircleImpl(*this); };
    ~CircleImpl();
    LocPtr Where(PART);
    void BoundBox(double*, double*, double*, double*);
    int IsPickIn(double, double);
    void Draw();
    void Erase();
    void GetValues(View**, int *, double *, double *, double *, 
              COLOR, double *);
  };

#endif
