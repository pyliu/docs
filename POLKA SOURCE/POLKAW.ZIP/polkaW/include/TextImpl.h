/***************************************************************/
/*							                                   */
/*	       		TextImpl.h			                           */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#ifndef __TEXT_IMPL_H
#define __TEXT_IMPL_H

#include "AnimObjectImpl.h"

class TextImpl: public AnimObjectImpl {
  private:
    char colorname[32];
    COLORINDEX color;
    char fontname[128];
    int fontid;
    char tstring[128];
    int orient;
    int xext,xoff;
    int yext,yoff;
    void drawer(COLORINDEX);
    void transSpecial(char*, double, double);
  public:
    TextImpl(View *view, int v, double lx, double ly, COLOR c, 
            const char *fn, const char *ts, int o);
    TextImpl(const TextImpl&);
    AnimObjectImpl *clone() const     // redef of virtual constructor
       { return new TextImpl(*this); };
    ~TextImpl();
    LocPtr Where(PART);
    void BoundBox(double*, double*, double*, double*);
    void Draw();
    void Erase();
    void GetValues(View**, int *, double *, double *, COLOR, 
            char*, char*, int *);
};

#endif
