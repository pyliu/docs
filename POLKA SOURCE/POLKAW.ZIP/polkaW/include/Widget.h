/***************************************************************/
/*							                                   */
/*	       		Widget.h			                           */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#ifndef __WIDGET_H
#define __WIDGET_H

#include "System.h"
#include "Window.h"

Window XtWindow( Widget widget );

class __Widget: public __Window {
public:
	__Widget();
};

#endif