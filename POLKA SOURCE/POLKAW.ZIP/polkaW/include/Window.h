/***************************************************************/
/*							                                   */
/*	       		Window.h			                           */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#ifndef __WINDOW_H
#define __WINDOW_H

#include <windows.h>
#include "System.h"
#include "Drawable.h"


class __Window: public __Drawable {
public:
	__Window();
	~__Window();

	virtual void destroyWindow();
	virtual HWND setWnd( HWND aWnd );
	HWND getWnd() { return hWnd; }

	BOOL ShowWindow( int nCmdShow );
    BOOL UpdateWindow();

protected:
	// window handler
	HWND  hWnd;
};

#endif