/***************************************************************/
/*							                                   */
/*	       		Pixmap.h			                           */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#ifndef __PIXMAP_H
#define __PIXMAP_H

#include <windows.h>
#include "System.h"
#include "Window.h"


Pixmap XCreatePixmap( Window wnd, int w, int h );
Pixmap XCreatePixmap( Drawable drawable, int w, int h );
void XFreePixmap( Pixmap window );
Pixmap XCreatePixmapFromBitmapData( Drawable drawable,
								    char data[],
									unsigned int width,
									unsigned int height,
									unsigned long fg,
									unsigned long bg,
									unsigned int depth );

class __Pixmap: public __Drawable {
public:
	__Pixmap();
	__Pixmap( Window wnd );
	__Pixmap( Window wnd,
		      int aWidth,
			  int aHeight );
	__Pixmap( Drawable wnd,
		      int aWidth,
			  int aHeight );
	__Pixmap( HWND hwnd );
	__Pixmap( HWND hwnd,
		      int aWidth,
			  int aHeight );
    ~__Pixmap();

	// create bitmap compatible (in terms of number
	// of colors available, etc.) with the window on
	// the screen
    void createCompatiblePixmap( HWND hwnd,
		                         int aWidth,
								 int aHeight );
    void createCompatiblePixmap( HDC hdc,
		                         int aWidth,
								 int aHeight,
								 int );
	void createCompatiblePixmap( HWND hwnd );

	// accessors
	int  getWidth()  { return nWidth; }
	int  getHeight() { return nHeight; }

	// free the pixmap
	void XFreePixmap();

protected:
	// windows handle to the
	// bitmap
	HBITMAP  hBitmap;
	// bitmap width
	int      nWidth;
	// bitmap height
	int      nHeight;
};

#endif