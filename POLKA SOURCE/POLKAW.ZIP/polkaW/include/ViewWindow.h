/***************************************************************/
/*							                                   */
/*	       		ViewWindow.h			                       */
/*							                                   */
/***************************************************************/
/*       Copyright 1997 Georgia Institute of Technology 
                     -- Roman S. Khramets                      */

#ifndef __VIEWWINDOW_H
#define __VIEWWINDOW_H

#include "Widget.h"
#include "DrawingArea.h"

class View;

class ViewWindow: public __Widget {
	friend LRESULT CALLBACK ViewWindowProc (HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam);

public:
	ViewWindow();

	ViewWindow( LPCTSTR title,
		        DWORD   dwStyle,
		        RECT    *viewWndRect,
				HWND    hWndParent,
				HANDLE  hAppInstance,
				View    *aView );

	void create( LPCTSTR title,
		         DWORD   dwStyle,
		         RECT    *viewWndRect,
				 HWND    hWndParent,
				 HANDLE  hAppInstance,
				 View    *aView );

	DrawingArea *getDrawingArea() { return &easel; }
	View *getView() { return theView; }

protected:
	DrawingArea easel;
	View *theView; // view associated with the view window
	HWND  botleftrowcol[6];
	HWND  botrightrowcol[3];
};

#endif