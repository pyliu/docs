/***************************************************************/
/*							                                   */
/*	       		Pie.h			                               */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#ifndef __PIE_H
#define __PIE_H

#include "AnimObject.h"
#include "PieImpl.h"

class Pie: public AnimObject {
  public:
    Pie(View *vi, int v, double lx, double ly, 
                double rad, double bang=0.0, double del=1.0, 
                COLOR c="black", double f=1.0)
      : AnimObject( new PieImpl(vi, v, lx, ly, rad, bang, del, c, f) ) {};
    Pie& operator=(const Pie&);
    void GetValues(View**vi, int *v, double *lx, double *ly, 
                double *rad, double *bang, double *del, 
                COLOR c, double *f)
          { ((PieImpl*)object)->GetValues(vi,v,lx,ly,rad,bang,del,c,f); };
};

#endif
