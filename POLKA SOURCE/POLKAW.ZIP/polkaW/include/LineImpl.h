/***************************************************************/
/*							                                   */
/*	       		LineImpl.h			                           */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#ifndef __LINE_IMPL_H
#define __LINE_IMPL_H

#include "AnimObjectImpl.h"

class LineImpl: public AnimObjectImpl {
   private:
    double sizex,sizey;
    char colorname[32];
    COLORINDEX color;
    double width;
    double style;
    int arrow;
    double arrowf1x,arrowf1y;
    double arrowf2x,arrowf2y;
    double arrowf3x,arrowf3y;
    double arrowf4x,arrowf4y;
    void drawer(COLORINDEX);
    void transSpecial(char*, double, double);
  public:
    LineImpl(View *view, int v, double lx, double ly, double sx, double sy, 
            COLOR c="black", double w=0.0, double s=1.0, int a=0);
    LineImpl(const LineImpl&);
    AnimObjectImpl *clone() const     // redef of virtual constructor
       { return new LineImpl(*this); };
    ~LineImpl();
    LocPtr Where(PART);
    void BoundBox(double*, double*, double*, double*);
    int IsPickIn(double, double);
    void Draw();
    void Erase();
    void GetValues(View**, int*, double*, double*, 
                   double*, double*, COLOR, double*,
                   double*, int*);
};

#endif
