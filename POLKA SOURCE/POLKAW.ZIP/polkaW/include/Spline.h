/***************************************************************/
/*							                                   */
/*	       		Spline.h			                           */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#ifndef __SPLINE_H
#define __SPLINE_H

#include "AnimObject.h"
#include "SplineImpl.h"

class Spline: public AnimObject {
  public:
    Spline(View *vi, int v, double lx, double ly, int ve, 
                double vx[], double vy[], COLOR c="black", double w=0.0, 
                double s=1.0)
      : AnimObject( new SplineImpl(vi, v, lx, ly, ve, vx, vy, c, w, s) ) {};
    Spline& operator=(const Spline&);
    void GetValues(View**vi, int *v, double *lx, double *ly, int *ve, 
                double vx[], double vy[], COLOR c, double *w, double *s)
          { ((SplineImpl*)object)->GetValues(vi,v,lx,ly,ve,vx,vy,c,w,s); };
};

#endif
