/***************************************************************/
/*							                                   */
/*	       		SetImpl.h			                           */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#ifndef __SET_IMPL_H
#define __SET_IMPL_H

#include "AnimObjectImpl.h"
#include "Set.h"

class SetImpl: public AnimObjectImpl {
  public: 
    SetImpl(View *v);
    SetImpl(const SetImpl& s) : AnimObjectImpl(s) {};
    AnimObjectImpl *clone() const     // redef of virtual constructor
       { return new SetImpl(*this); };
    LocPtr Where(PART);
    void BoundBox(double *, double *, double *, double *);
    void Draw();
    void Erase();
};

#endif
