/***************************************************************/
/*							                                   */
/*	       		AnimObjectGroup.h			                   */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#ifndef __ANIM_OBJECT_GROUP_H
#define __ANIM_OBJECT_GROUP_H

#include "common_includes.h"

enum Align {
   AlignBottom, AlignTop, AlignMiddle, AlignLeft, AlignRight
};

enum Spacing {
   SpacingNone, SpacingSame, SpacingAbsolute
};

class AnimObjectGroup {
   public:
     int horiz;
     Align align;
     int vis;
     char color[32];
     Spacing spacetype;
     double spacing;

     int useints;
     int *intvals;
     int intmax;
     int intmin;

     int usedoubles;
     double *doublevals;
     double doublemax;
     double doublemin;

     AnimObjectGroup();
};

#endif
