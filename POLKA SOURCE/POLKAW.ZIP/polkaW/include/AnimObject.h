/***************************************************************/
/*							                                   */
/*	       		AnimObject.h			                       */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#ifndef __ANIM_OBJECT_H
#define __ANIM_OBJECT_H

#include "polka_local.H"

#include "AnimObjectCommon.h"
#include "AnimObjectImpl.h"
#include "Action.h"
#include "View.h"

typedef  void (*CALLBACKFCT)(AnimObject*, void *, double, double);

class AnimObject {
  friend void SelectPoint(View *xtp, int x, int y);
  private:
    View *view;
    int originated;
    int originateAt;
    int modified;
    int updating;
    void *objData;
    void (*callbackFct)(AnimObject *, void *, double, double);
    void *callbackData;
    struct ActionInfo *first;       // list of regular Actions
    struct ActionInfo *last;
    struct ActionInfo *firstContinuous; // list of continuous running Actions
    struct ActionInfo *lastContinuous;
    struct ImplNode *changers;
    struct IntNode *deleters;
    struct ActionDeleteNode *continDeleters;
    Attachment attachments;
    AnimObject *attachedTo;
    AnimObject *attachDoneFrom;
    AOPtr viewAOP;
    void addObject();
    void deleteMe(); 
    int doDeletes(int);
    void doContDeletes(int);
    void doChanges(int);
    Attachment getAttachments() { return attachments; };
    void addAttachment(Attachment);
    void removeAttachment(AnimObject *);
    void propagateAttachment(AnimObject *, Attachment, AnimObject *);
    struct ActionInfo *DeleteActionInfoPtr(struct ActionInfo *);
    void deleteContinActionInfoPtr(ActionPtr,int);
  protected:
    AnimObjectImpl *object;
    AOPtr objs;  // things in set, or sets in which object (non-set) is in
    AnimObjectType type;
    AnimObject(AnimObjectImpl *p);
    AnimObject& operator=(const AnimObject&);
  public:
    AnimObject(const AnimObject&);
    ~AnimObject() 
       { deleteMe();
         delete object;
         object = 0; }
    int operator==(const AnimObject* a) 
       { return (this == a); }
    void Originate(int);
    void Change(int, AnimObject *, int useoldpos=0);
    void Delete(int);
    int Program(int, ActionPtr);
    int ProgramContinuous(int, ActionPtr);
    void RemoveContinuous(int, ActionPtr);
    LocPtr Where(PART p) { return(object->Where(p)); };
    Attachment AttachTo(AnimObject *, PART, PART, double x=0.0, double y=0.0);
    int Detach(Attachment);
    void SetAttachTraverseObject(AnimObject *a) { attachDoneFrom=a; };
    void StoreData(void *od)  { objData = od; };
    void *RetrieveData() { return objData; };
    void SetCallback(CALLBACKFCT cb, void *d=NULL) {
            callbackFct = cb;
            callbackData = d;
            };

    void Update(int);       //  from here on, should not be used by outsiders
    void Draw() { object->Draw(); };
    void Erase() { object->Erase(); };
    void BoundBox(double *lx, double *by, double *rx, double *ty) 
           { object->BoundBox(lx,by,rx,ty); };
    int IsPickIn(double px, double py)
           { return(object->IsPickIn(px, py)); };
    void DamageIt() { object->DamageIt(); };
    int Intercepts(double, double, double, double);
    void Nullify() { object = 0; }; // called only by Change
    int OriginateTime() { return originateAt; };
    void SetOriginated(int o) { originated = o; };
    int Originated() { return originated; };
    int GetUpdating() { return updating; };
    View *MyView() { return view; };
    AnimObjectType Type() { return type; };
    AnimObjectImpl *Object() { return object; };
    void SetModify(int m) { modified = m; };
    int Modified() { return modified; };
    void IsInSet(AnimObject *);
    void SetIsGone(AnimObject *);
};

#endif
