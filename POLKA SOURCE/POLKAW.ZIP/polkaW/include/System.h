/***************************************************************/
/*							                                   */
/*	       		System.h	                                   */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#ifndef __SYSTEM_H
#define __SYSTEM_H

class __Drawable;
typedef __Drawable *Drawable;

class __Window;
typedef __Window *Window;

class __Pixmap;
typedef __Pixmap *Pixmap;

class __Widget;
typedef __Widget *Widget;

class __GC;
typedef __GC *GC;

#endif