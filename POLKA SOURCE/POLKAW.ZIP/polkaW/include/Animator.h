/***************************************************************/
/*							                                   */
/*	       		Animator.h			                           */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#ifndef __ANIMATOR_H
#define __ANIMATOR_H

#include "polka_local.H"
#include "common_macros.h"

#include "BaseView.h"

/* ********************************************************************

Class Animator

******************************************************************** */

typedef struct _ALGOEVT {
      char *name;
      char *params;
      struct _ALGOEVT *next;
} ALGOEVT;



class Animator {
 private:
   ALGOEVT *evts;
   class BaseView *views[50];
   int numviews;   

 protected:
   char    AlgoEvtName[32];
   int     AnimInts[MAXPARAMS];
   double  AnimDoubles[MAXPARAMS];
   char   *AnimStrings[MAXPARAMS];
   
   virtual int Controller() = 0;

 public:
   Animator();
   void RegisterAlgoEvt(const char *, const char *);
   int SendAlgoEvt(const char * ...);
   void RegisterView(class BaseView *);
   void RemoveView(class BaseView *);
   int Animate(int, int);   
};

#endif
