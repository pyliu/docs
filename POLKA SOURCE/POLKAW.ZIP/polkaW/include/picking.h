/***************************************************************/
/*							                                   */
/*	       		picking.h			                           */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#ifndef __PICKING_H
#define __PICKING_H

extern int askingForInput;
extern int gotPoint;
extern int xPoint, yPoint;

class View;
void SelectPoint(View *xtp, int x, int y);

#endif