/***************************************************************/
/*							                                   */
/*	       		window_sizes.h			                       */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#ifndef __WINDOW_SIZES_H
#define __WINDOW_SIZES_H

#define CWND_X_SIZE               66
#define CWND_Y_SIZE               ((float)5.4)

#define CVWND_X_SIZE              66
#define CVWND_Y_SIZE              40

#endif