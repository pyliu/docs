/***************************************************************/
/*							                                   */
/*	       		LineImpl.cpp			                       */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#include "LineImpl.h"
#include "View.h"

#include "Pixmap.h"


LineImpl::LineImpl(View *an, int v, double lx, double ly, 
           double sx, double sy, COLOR c, double w, double s, int a) 
          :  AnimObjectImpl(an,v,lx,ly) 
{
   type = P_Line;
   sizex = sx;
   sizey = sy;
   strcpy(colorname,c);
   color = load_color(colorname);
   width = w;
   style = s;
   arrow = a;
   /* figure out arrow here */
   if ((arrow == 1) || (arrow == 3))
      compute_arrow_off(sx,sy,&arrowf1x,&arrowf1y,&arrowf2x,&arrowf2y);
   if ((arrow == 2) || (arrow == 3))
      compute_arrow_off(-sx,-sy,&arrowf3x,&arrowf3y,&arrowf4x,&arrowf4y);
}


LineImpl::LineImpl(const LineImpl& l) : AnimObjectImpl( l )
{
   sizex = l.sizex;
   sizey = l.sizey;
   strcpy(colorname,l.colorname);
   color = l.color;  // know it's already been loaded
   width = l.width;
   style = l.style;
   arrow = l.arrow;
   /* figure out arrow here */
   if ((arrow == 1) || (arrow == 3)) {
      arrowf1x = l.arrowf1x;
      arrowf1y = l.arrowf1y;
      arrowf2x = l.arrowf2x;
      arrowf2y = l.arrowf2y;
      }
   if ((arrow == 2) || (arrow == 3)) {
      arrowf3x = l.arrowf3x;
      arrowf3y = l.arrowf3y;
      arrowf4x = l.arrowf4x;
      arrowf4y = l.arrowf4y;
      }
}
   

LineImpl::~LineImpl()
{
   Erase();
}


void
LineImpl::GetValues(View* *an, int* v, double* lx, double* ly, 
           double* sx, double* sy, COLOR c, double* w, double* s, int* a) 
{
   if (an) *an=view;
   if (v) *v=visibility;
   if (lx) *lx=locx;
   if (ly) *ly=locy;
   if (sx) *sx=sizex;
   if (sy) *sy=sizey;
   if (c) strcpy(c,colorname);
   if (w) *w=width;
   if (s) *s=style;
   if (a) *a=arrow;
}


LocPtr
LineImpl::Where(PART p)
{
   double	   xmin,xmax,ymin,ymax;

   BoundBox(&xmin,&ymin,&xmax,&ymax);

   switch (p)
   {
      case PART_NW :
	 return( new Loc(xmin,ymax) );
      case PART_N :
	 return( new Loc((xmin+xmax)/2.0,ymax) );
      case PART_NE :
	 return( new Loc(xmax,ymax) );
      case PART_E :
	 return( new Loc(xmax,(ymin+ymax)/2.0) );
      case PART_SE :
	 return( new Loc(xmax,ymin) );
      case PART_S :
	 return( new Loc((xmin+xmax)/2.0,ymin) );
      case PART_SW :
	 return( new Loc(xmin,ymin) );
      case PART_W :
	 return( new Loc(xmin,(ymin+ymax)/2.0) );
      case PART_C :
	 return( new Loc((xmin+xmax)/2.0,(ymin+ymax)/2.0) );
   }
   return( new Loc(0.0,0.0) );
}


void
LineImpl::BoundBox(double *lx, double *by, double *rx, double *ty)
{
   double ax0,ax1,ay0,ay1;

   *lx = (sizex > ZERO ? locx : locx+sizex);
   *rx = (sizex > ZERO ? locx+sizex : locx);
   *ty = (sizey > ZERO ? locy+sizey : locy);
   *by = (sizey > ZERO ? locy: locy+sizey);
   if ((arrow & 0x1) != 0)    // below is dumb, but it works
      {        // need to take arrows into account on boundbox
        ax0 = locx+sizex+arrowf1x;
        ax1 = locx+sizex+arrowf2x;
        if (ax0 < *lx) *lx = ax0;
        if (ax1 < *lx) *lx = ax1;
        if (ax0 > *rx) *rx = ax0;
        if (ax1 > *rx) *rx = ax1;
        ay0 = locy+sizey+arrowf1y;
        ay1 = locy+sizey+arrowf2y;
        if (ay0 < *by) *by = ay0;
        if (ay1 < *by) *by = ay1;
        if (ay0 > *ty) *ty = ay0;
        if (ay1 > *ty) *ty = ay1;
      }
   if ((arrow & 0x2) != 0)
      { 
        ax0 = locx+arrowf3x;
        ax1 = locx+arrowf4x;
        if (ax0 < *lx) *lx = ax0;
        if (ax1 < *lx) *lx = ax1;
        if (ax0 > *rx) *rx = ax0;
        if (ax1 > *rx) *rx = ax1;
        ay0 = locy+arrowf3y;
        ay1 = locy+arrowf4y;
        if (ay0 < *by) *by = ay0;
        if (ay1 < *by) *by = ay1;
        if (ay0 > *ty) *ty = ay0;
        if (ay1 > *ty) *ty = ay1;
      }
}


int
LineImpl::IsPickIn(double xpt, double ypt)
{
   double top,bottom,left,right,dist;

   top = (sizey > 0.0 ? locy+sizey : locy);
   bottom = (sizey > 0.0 ? locy : locy+sizey);
   left = (sizex > 0.0 ? locx : locx+sizex);
   right = (sizex > 0.0 ? locx+sizex : locx);

   if ( ((xpt<left)||(xpt>right)) && ((ypt>top)||(ypt<bottom)))
      return(0);    // not within endpoints of line

   // Distance from point to line
   dist = ABS( (sizey*xpt) - (sizex*ypt) + (sizex*locy) - (sizey*locx) ) /
          sqrt( (sizey*sizey) + (sizex*sizex));

   if (dist < 0.01)
      return(1);
   else
      return(0);
}   


void
LineImpl::transSpecial(char *atype, double dx, double dy)
{
   if (streql(atype,"FILL"))
      { width +=  dx;
	if (width < 0.0)
	   width = 0.0;
	else if (width > 1.0)
	   width = 1.0;
        style +=  dy;
	if (style < 0.0)
	   style = 0.0;
	else if (style > 1.0)
	   style = 1.0;
        DamageIt();
      }
   else if (streql(atype,"RESIZE"))
      { DamageIt();
        sizex += dx;
	sizey += dy;
        if ((arrow == 1) || (arrow == 3))
           compute_arrow_off(sizex,sizey,&arrowf1x,&arrowf1y,
                                &arrowf2x,&arrowf2y);
        if ((arrow == 2) || (arrow == 3))
           compute_arrow_off(-sizex,-sizey,&arrowf3x,&arrowf3y,
                                &arrowf4x,&arrowf4y);
        DamageIt();
      }
   else if (streql(atype,"COLOR")) {
      color = get_pathcolor(dx,dy);
      DamageIt();
      }
}

   
void
LineImpl::Draw()
{
   drawer(color);
}


void
LineImpl::Erase()
{
   drawer(view->GetBgColor());
}


void
LineImpl::drawer(COLORINDEX col)
{
   int x0,y0,x1,y1,ax0,ay0,ax1,ay1;
   LINE_STYLE lstyle,old;

   if (!visibility)
      return;

   x0 = view->TO_PIX_X(locx);
   y0 = view->TO_PIX_Y(locy);
   x1 = view->TO_PIX_X(locx+sizex);
   y1 = view->TO_PIX_Y(locy+sizey);

   set_color(col);
   lstyle = get_linestyle(width,style);
   if (lstyle != SOLID)
     old = line_style(lstyle);

   XDrawLine(view->DrawWindow(),inq_gc(),x0,y0,x1,y1);

   if ((arrow & 0x1) != 0)
      { 
        ax0 = view->TO_PIX_X(locx+sizex+arrowf1x);
        ay0 = view->TO_PIX_Y(locy+sizey+arrowf1y);
        ax1 = view->TO_PIX_X(locx+sizex+arrowf2x);
        ay1 = view->TO_PIX_Y(locy+sizey+arrowf2y);
        XDrawLine(view->DrawWindow(),inq_gc(),x1,y1,ax0,ay0);
        XDrawLine(view->DrawWindow(),inq_gc(),x1,y1,ax1,ay1);
      }
   if ((arrow & 0x2) != 0)
      { 
        ax0 = view->TO_PIX_X(locx+arrowf3x);
        ay0 = view->TO_PIX_Y(locy+arrowf3y);
        ax1 = view->TO_PIX_X(locx+arrowf4x);
        ay1 = view->TO_PIX_Y(locy+arrowf4y);
        XDrawLine(view->DrawWindow(),inq_gc(),x0,y0,ax0,ay0);
        XDrawLine(view->DrawWindow(),inq_gc(),x0,y0,ax1,ay1);
      }

   if (lstyle != SOLID)
      line_style(old);
}
