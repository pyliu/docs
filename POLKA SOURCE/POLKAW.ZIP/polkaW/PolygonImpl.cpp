/***************************************************************/
/*							                                   */
/*	       		PolygonImpl.cpp		                           */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#include "PolygonImpl.h"
#include "View.h"
#include "Pixmap.h"


PolygonImpl::PolygonImpl(View *a, int v, double lx, double ly, int ve, 
                 double vtx[], double vty[], COLOR c, double f) 
                 : AnimObjectImpl(a,v,lx,ly)
{
   int i;

   type = P_Polygon;
   vertices = ve;
   for (i=0; i<vertices-1; i++) {
       vx[i] = vtx[i];
       vy[i] = vty[i];
     }
   strcpy(colorname,c);
   color = load_color(colorname);
   fill = f;
}


PolygonImpl::PolygonImpl(const PolygonImpl& p) : AnimObjectImpl( p )
{
   vertices = p.vertices;
   for (int i=0; i<vertices-1; i++) {
       vx[i] = p.vx[i];
       vy[i] = p.vy[i];
     }
   strcpy(colorname,p.colorname);
   color = p.color;
   fill = p.fill;
}


PolygonImpl::~PolygonImpl()
{
   Erase();
}


void 
PolygonImpl::GetValues(View* *vi, int *v, double *lx, double *ly, int *ve, 
                double vtx[], double vty[], COLOR c, double *f)
{
   if (vi) *vi=view;
   if (v) *v=visibility;
   if (lx) *lx=locx;
   if (ly) *ly=locy;
   if (ve) *ve=vertices;
   for (int i=0; i<vertices; i++) {
       if (vtx) vtx[i] = vx[i];
       if (vty) vty[i] = vy[i];
   }
   if (c) strcpy(c,colorname);
   if (f) *f=fill;
}	


LocPtr
PolygonImpl::Where(PART p)
{
   double	   xmin,ymin,xmax,ymax;

   BoundBox(&xmin,&ymin,&xmax,&ymax);

   switch (p)
   {
      case PART_C :
	 return( new Loc((xmin + xmax)/2.0,(ymin + ymax)/2.0) );
      case PART_NW :
	 return( new Loc(xmin,ymax) );
      case PART_N :
	 return( new Loc((xmin+ xmax)/2.0,ymax) );
      case PART_NE :
	 return( new Loc(xmax,ymax) );
      case PART_E :
	 return( new Loc(xmax,(ymin + ymax)/2.0) );
      case PART_SE :
	 return( new Loc(xmax,ymin) );
      case PART_S :
	 return( new Loc((xmin + xmax)/2.0,ymin) );
      case PART_SW :
	 return( new Loc(xmin,ymin) );
      case PART_W :
	 return( new Loc(xmin,(ymin + ymax)/2.0) );
   }
   return( new Loc(0.0,0.0) );
}


void
PolygonImpl::BoundBox(double *lx, double *by, double *rx, double *ty)
{
   double x,y,xmin,xmax,ymin,ymax;
   int i;

   xmin = xmax = locx;
   ymin = ymax = locy;   /* Find the bounding box */
   for (i=0; i<(vertices - 1); ++i)
      { if ((x = (locx+vx[i])) > xmax) xmax = x;
	if ((x = (locx+vx[i])) < xmin) xmin = x;
	if ((y = (locy+vy[i])) > ymax) ymax = y;
	if ((y = (locy+vy[i])) < ymin) ymin = y;
      }
   *lx = xmin; *rx = xmax; *ty = ymax; *by = ymin;
}


void
PolygonImpl::transSpecial(char *atype, double dx, double dy)
{
   int i,v;

   if (streql(atype,"FILL"))
      { fill +=  dx;
	if (fill < 0.0)
	   fill = 0.0;
	else if (fill > 1.0)
	   fill = 1.0;
        DamageIt();
      }
   else if (streql(atype,"COLOR")) {
      color = get_pathcolor(dx,dy);
      DamageIt();
      }
   else if (streqln(atype,"RESIZE",6)) {
      if (('1' <= *(atype+6)) && (*(atype+6) <= '7')) {
         DamageIt();
         v = (int) (*(atype+6) - '0');
         for (i=v-1; i<vertices-1; i++) {
            vx[i] += dx;
            vy[i] += dy;
            }
         DamageIt();
         }
      }      
   else if (streqln(atype,"GRAB",4)) {
      if (('1' <= *(atype+4)) && (*(atype+4) <= '7')) {
         DamageIt();
         v = (int) (*(atype+4) - '1');
         vx[v] += dx;
         vy[v] += dy;
         DamageIt();
         }
      }      
}

   
void
PolygonImpl::Draw()
{
   FILL_STYLE curfill;

   curfill = get_fillstyle(fill);
   drawer(color,curfill);
}


void
PolygonImpl::Erase()
{
   FILL_STYLE curfill;

   curfill = get_fillstyle(fill);
   if (curfill == POLKA_FILL_OUTLINE)
      drawer(view->GetBgColor(),POLKA_FILL_OUTLINE);
   else
      drawer(view->GetBgColor(),POLKA_FILL_SOLID);
}


void
PolygonImpl::drawer(COLORINDEX col, FILL_STYLE curfill)
{
   int i;
   FILL_STYLE oldfill;
   XPoint pts[10];

   if (!visibility)
      return;

   pts[0].x = view->TO_PIX_X(locx);
   pts[0].y = view->TO_PIX_Y(locy);
   for (i=1; i<vertices; i++) {
      pts[i].x = view->TO_PIX_X(locx + vx[i-1]);
      pts[i].y = view->TO_PIX_Y(locy + vy[i-1]);
      }
   set_color(col);
   if (curfill == POLKA_FILL_OUTLINE)
      {
        pts[vertices].x = view->TO_PIX_X(locx);
        pts[vertices].y = view->TO_PIX_Y(locy);
        XDrawLines(view->DrawWindow(),inq_gc(),pts,vertices+1,CoordModeOrigin);
      }
   else
      {
        oldfill = fill_style(curfill);
        XFillPolygon(view->DrawWindow(),inq_gc(),pts,vertices,Nonconvex,CoordModeOrigin);
        fill_style(oldfill);
      }
}
