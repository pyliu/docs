/***************************************************************/
/*							                                   */
/*	       		Polyline.cpp	                               */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#include "Polyline.h"


Polyline& 
Polyline::operator=(const Polyline& rhs) 
{
  if  (this == &rhs) return *this;
  AnimObject::operator=(rhs);
  return *this;
}
