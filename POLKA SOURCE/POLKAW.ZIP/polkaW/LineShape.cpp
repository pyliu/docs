/***************************************************************/
/*							                                   */
/*	       		LineShape.cpp			                       */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#include "polka_staticwindow.H"
#include "StaticView.h"


LineShape::LineShape(int px, int py, int pxs, int pys, const char *col)
{
   x = px;
   y = py;
   xs = pxs;
   ys = pys;
   color = load_color(col);
}


void
LineShape::draw(/*Window win, int winheight, StaticView *sv*/)
{
   set_color(color);
//   XDrawLine(_display,win,inq_gc(),x,winheight-y,x+xs,winheight-y-ys);
//   sv->AccumClip( (xs>0) ? x : x+xs,
//                  (ys>0) ? y : y+ys,
//                  (xs>0) ? x+xs : x,
//                  (ys>0) ? y+ys : y );
}
