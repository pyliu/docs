/***************************************************************/
/*							                                   */
/*	       		BitmapImpl.cpp			                       */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#include "BitmapImpl.h"
#include "View.h"
#include "polka_gc.h"
#include "GC.h"
#include "Pixmap.h"


BitmapImpl::BitmapImpl(View *vi, int v, double lx, double ly, int height, 
         int width, char data[], COLOR fg, COLOR bg) 
          : AnimObjectImpl(vi,v,lx,ly)
{
   FILL_STYLE oldfill;
   COLORINDEX fgcolor,bgcolor;
   Pixel xfg,xbg;

   int bmsize,i;

   type = P_Bitmap;
   iheight = height;
   iwidth = width;
   strcpy(fgcolname,fg);
   strcpy(bgcolname,bg);

   bmsize = (width / 8) * height;   // char is of size=8 bits
   bmdata = new char[bmsize];

   for (i=0; i<bmsize; i++)
      *(bmdata+i) = data[i];

   /* Must remove clip_rectangle set by animation loop damage routines */
   XSetClipMask(inq_gc(), None);

   if (_color_screen) {
     fgcolor = load_color(fg);
     bgcolor = load_color(bg);
     xfg = GetXColor(fgcolor);
     xbg = GetXColor(bgcolor);
	 if( (pixmap = XCreatePixmapFromBitmapData(view->DrawWindow(),
		              bmdata, width, height, xfg, xbg, 24)) == None ) {
		 exit(-1);
	 }
   }
}


BitmapImpl::BitmapImpl(const BitmapImpl& b) : AnimObjectImpl( b )
{
   int bmsize,i;

   iheight = b.iheight;
   iwidth = b.iwidth;
   strcpy(fgcolname,b.fgcolname);
   strcpy(bgcolname,b.bgcolname);
   bmsize = (iwidth / 8) * iheight;   // char is of size=4
   bmdata = new char[bmsize];
   for (i=0; i<bmsize; i++)
      *(bmdata+i) = b.bmdata[i];
   /* Must remove clip_rectangle set by animation loop damage routines */
   XSetClipMask(inq_gc(), None);
   pixmap = XCreatePixmap(view->DrawWindow(), b.iwidth,
              b.iheight);
   XCopyArea(b.pixmap,pixmap,inq_gc(),0,0,
               b.iwidth,b.iheight,0,0);
}
   

BitmapImpl::~BitmapImpl()
{
   Erase();
   delete(bmdata);
   XFreePixmap(pixmap);
}


void 
BitmapImpl::GetValues(View* *vi, int *v, double *lx, double *ly, 
            int *wid, int *hei, char data[], COLOR fg, COLOR bg)
{
   int bmsize,i;

   if (vi) *vi=view;
   if (v) *v=visibility;
   if (lx) *lx=locx;
   if (ly) *ly=locy;
   if (wid) *wid=iwidth;
   if (hei) *hei=iheight;
   if (data) {
      bmsize = (iwidth / 8) * iheight;   // char is of size=4
      for (i=0; i<bmsize; i++)
         data[i] = bmdata[i];
      }
   if (fg) strcpy(fg,fgcolname);
   if (bg) strcpy(bg,bgcolname);
}	


LocPtr
BitmapImpl::Where(PART p)
{
   double	   lx,by,rx,ty;

   BoundBox(&lx,&by,&rx,&ty);

   switch (p)
   {
      case PART_C :
	 return( new Loc((lx + rx)/2.0,(by + ty)/2.0) );
      case PART_NW :
	 return( new Loc(lx,ty) );
      case PART_N :
	 return( new Loc((lx+ rx)/2.0,ty) );
      case PART_NE :
	 return( new Loc(rx,ty) );
      case PART_E :
	 return( new Loc(rx,(ty + by)/2.0) );
      case PART_SE :
	 return( new Loc(rx,by) );
      case PART_S :
	 return( new Loc((lx + rx)/2.0,by) );
      case PART_SW :
	 return( new Loc(lx,by) );
      case PART_W :
	 return( new Loc(lx,(by + ty)/2.0) );
   }
   return( new Loc(0.0,0.0) );
}


void
BitmapImpl::BoundBox(double *lx, double *by, double *rx, double *ty)
{
   *lx = locx;
   *by = locy;
   *rx = locx + view->SIZE_REAL_X(iwidth);
   *ty = locy + view->SIZE_REAL_Y(iheight);
}


void
BitmapImpl::Draw()
{
   if (!visibility)
      return;
   XCopyArea(pixmap,view->DrawWindow(),inq_gc(),0,0,
               iwidth,iheight,view->TO_PIX_X(locx),
                              view->TO_PIX_Y(locy)-iheight);
}


void
BitmapImpl::Erase()
{
   FILL_STYLE oldfill;

   if (!visibility)
      return;

   set_color(view->GetBgColor());
   oldfill = fill_style(40);
   XFillRectangle(view->DrawWindow(),inq_gc(),
          view->TO_PIX_X(locx),view->TO_PIX_Y(locy)-iheight,iwidth,iheight);
   fill_style(oldfill);
}


void
BitmapImpl::transSpecial(char *, double, double)
{
}
