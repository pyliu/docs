/***************************************************************/
/*							                                   */
/*	       		RectangleShape.cpp	                           */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#include "polka_staticwindow.H"
#include "StaticView.h"


RectangleShape::RectangleShape(int px, int py, int pxs, int pys, const char *col)
{
   x = px;
   y = py;
   xs = pxs;
   ys = pys;
   color = load_color(col);
}


void
RectangleShape::draw(/*Window win, int winheight, StaticView *sv*/)
{
//   FILL_STYLE oldfill;
//
//   set_color(color);
//   oldfill = fill_style(POLKA_FILL_SOLID);
//   XFillRectangle(_display,win,inq_gc(),x,winheight-y-ys,xs,ys);
//   fill_style(oldfill);
//   sv->AccumClip(x,y,x+xs,y+ys);
}
