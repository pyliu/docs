/***************************************************************/
/*							                                   */
/*	       		EllipseShape.cpp                               */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#include "polka_staticwindow.H"
#include "StaticView.h"


EllipseShape::EllipseShape(int px, int py, int pxs, int pys, const char *col)
{
   x = px;
   y = py;
   xs = pxs;
   ys = pys;
   color = load_color(col);
}


void
EllipseShape::draw(/*Window win, int winheight, StaticView *sv*/)
{
   FILL_STYLE oldfill;

   set_color(color);
   oldfill = fill_style(POLKA_FILL_SOLID);
//   XFillArc(_display,win,inq_gc(),x-xs,winheight-y-ys,xs<<1,ys<<1,0,23040);
   fill_style(oldfill);
//   sv->AccumClip(x-xs,y-ys,x+xs,y+ys);
}
