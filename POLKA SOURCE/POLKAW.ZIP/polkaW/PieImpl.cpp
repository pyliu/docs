/***************************************************************/
/*							                                   */
/*	       		PieImpl.cpp			                           */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#include "PieImpl.h"
#include "View.h"
#include "Pixmap.h"


PieImpl::PieImpl(View *a, int v, double lx, double ly, double r,
                  double ba, double de, COLOR c, double f) 
          : AnimObjectImpl(a,v,lx,ly)
{
   type = P_Pie;
   radius = r;
   begangle = ba;
   delta = de;
   strcpy(colorname,c);
   color = load_color(colorname);
   fill = f;
}


PieImpl::PieImpl(const PieImpl& c) : AnimObjectImpl( c )
{
   radius = c.radius;
   begangle = c.begangle;
   delta = c.delta;
   strcpy(colorname,c.colorname);
   color = c.color;
   fill = c.fill;
}
  

PieImpl::~PieImpl()
{
   Erase();
}


void 
PieImpl::GetValues(View* *vi, int *v, double *lx, double *ly, 
                double *rad, double *bang, double *del, 
                COLOR c, double *f)
{
   if (vi) *vi=view;
   if (v) *v=visibility;
   if (lx) *lx=locx;
   if (ly) *ly=locy;
   if (rad) *rad=radius;
   if (bang) *bang=begangle;
   if (del) *del=delta;
   if (c) strcpy(c,colorname);
   if (f) *f=fill;
}


LocPtr
PieImpl::Where(PART p)
{
   double	   x0,y0,corner;

   x0 = locx;
   y0 = locy;
   corner = sqrt( (radius * radius) / 2.0 );
   switch (p)
   {
      case PART_C :
	 return( new Loc(x0,y0) );
      case PART_NW :
	 return( new Loc(x0-corner,y0+corner) );
      case PART_N :
	 return( new Loc(x0,y0+radius) );
      case PART_NE :
	 return( new Loc(x0+corner,y0+corner) );
      case PART_E :
	 return( new Loc(x0+radius,y0) );
      case PART_SE :
	 return( new Loc(x0+corner,y0-corner) );
      case PART_S :
	 return( new Loc(x0,y0-radius) );
      case PART_SW :
	 return( new Loc(x0-corner,y0-corner) );
      case PART_W :
	 return( new Loc(x0-radius,y0) );
   }
   return( new Loc(0.0,0.0) );
}


void
PieImpl::BoundBox(double *lx, double *by, double *rx, double *ty)
{
   *lx = locx - radius;
   *rx = locx + radius;
   *ty = locy + radius;
   *by = locy - radius;
}


void
PieImpl::transSpecial(char *atype, double dx, double dy)
{
   if (streql(atype,"FILL"))
      { fill +=  dx;
	if (fill < 0.0)
	   fill = 0.0;
	else if (fill > 1.0)
	   fill = 1.0;
        DamageIt();
      }
   else if (streql(atype,"GRAB"))
      { begangle += dx;
        delta += dy;
        DamageIt();
      }
   else if (streql(atype,"RESIZE"))
      { DamageIt();
        radius += dx;
	if (radius < ZERO)
	   radius = ZERO;
        DamageIt();
      }
   else if (streql(atype,"COLOR")) {
      color = get_pathcolor(dx,dy);
      DamageIt();
      }
}

   
void
PieImpl::Draw()
{
   FILL_STYLE curfill;

   curfill = get_fillstyle(fill);
   drawer(color,curfill);
}

void
PieImpl::Erase()
{
   FILL_STYLE curfill;

   curfill = get_fillstyle(fill);
   if (curfill == POLKA_FILL_OUTLINE)
      drawer(view->GetBgColor(),POLKA_FILL_OUTLINE);
   else
      drawer(view->GetBgColor(),POLKA_FILL_SOLID);
}


void
PieImpl::drawer(COLORINDEX col, FILL_STYLE curfill)
{
   int x0,y0,radx,rady;
   FILL_STYLE oldfill;

   if (!visibility)
      return;

   x0 = view->TO_PIX_X(locx);
   y0 = view->TO_PIX_Y(locy);
   radx = view->SIZE_PIX_X(radius);
   rady = view->SIZE_PIX_Y(radius);
   set_color(col);

   if (curfill == POLKA_FILL_OUTLINE)
      {
        XDrawArc(view->DrawWindow(),inq_gc(),x0-radx,y0-rady,
                 radx<<1,rady<<1, int(begangle*23040), int(delta*23040));
      }
   else 
      {
        oldfill = fill_style(curfill);
        XFillArc(view->DrawWindow(),inq_gc(),x0-radx,y0-rady,
                 radx<<1,rady<<1, int(begangle*23040), int(delta*23040));
        fill_style(oldfill);       // 23040 == 360*64
      }
}
