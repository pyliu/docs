/***************************************************************/
/*							                                   */
/*	       		Text.cpp			                           */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#include "Text.h"


Text& 
Text::operator=(const Text& rhs) 
{
   if  (this == &rhs) return *this;
   AnimObject::operator=(rhs);
   return *this;
}
