/***************************************************************/
/*							                                   */
/*	       		Set.cpp			                               */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#include "Set.h"
#include "SetImpl.h"


Set::Set(View *v, int num, AnimObject *ao[]) : AnimObject( new SetImpl(v) )
{
   int i;
   AOPtr o;
   Set *set;

   type = P_Set;

   for (i=0; i<num; i++)
     { if (ao[i]->Type() != P_Set)
         another(ao[i]);
       else {
         set = (Set *) ao[i];
         for (o=set->Objs(); o; o=o->next)
           another(o->object);
       }
     }
}


Set::Set(const Set& s) : AnimObject( s )
{
   AOPtr a,newone,lasta;

   type = P_Set;
   lasta = NULL;
   for (a = s.objs; a; a=a->next) {
      newone = new AONode;
      newone->object = a->object;
      newone->next = NULL;
      newone->prev = lasta;
      if (objs)
        lasta->next = newone;
      else
        objs = newone;
      lasta = a;    
      newone->object->IsInSet(this);  // put ref from obj to this set
   }
}


Set::~Set()
{
   AOPtr a,old;

   a = objs;
   while (a) {
       a->object->SetIsGone(this);  // removes ref from obj to this set
       old = a;
       a = a->next;
       delete(old);
   }
}
  
      
void
Set::RemoveFromSet(AnimObject *gone)
{
   AOPtr ao;    // an AnimObject was deleted, so get it out of this set

   for (ao=objs; ao; ao=ao->next) {
     if (ao->object == gone) {
        if (ao->next)
           ao->next->prev = ao->prev;
        if (ao->prev)
           ao->prev->next = ao->next;
        if (ao == objs)
           objs = ao->next;
        delete(ao);
        return;
      }
   }
}
  

void
Set::another(AnimObject *ao)
{
   AOPtr o,lasta;

   o = objs;
   lasta = NULL;
   while (o) {
     if (o->object == ao)  // this object is already in the set, forget it
        return;
     lasta = o;
     o = o->next;
   }
   
   AOPtr newone = new AONode;  // not already in, so add it
   newone->object = ao;
   newone->next = NULL;
   newone->prev = lasta;
   if (objs)
     lasta->next = newone;
   else
     objs = newone;

   ao->IsInSet(this);  // designate that the object is in this set
}


Set& 
Set::operator=(const Set& rhs) 
{
   if  (this == &rhs) return *this;
   AnimObject::operator=(rhs);
   return *this;
}
