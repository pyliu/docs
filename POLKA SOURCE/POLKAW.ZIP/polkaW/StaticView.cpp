/***************************************************************/
/*							                                   */
/*	       		StaticView.cpp		                           */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#include "polka_staticwindow.H"
#include "StaticView.h"


StaticView::StaticView()
{
   debug = 0;
   mapped = 1;
   created = 0;
   time = 0;
   pixX = 0;
   pixY = 0;
//   window = 0;   /* need it this way to start (no resize) */
}


StaticView::~StaticView()
{
   ShapeNodePtr walker,curr;

   if (!created) return;

   walker = shapes;
   while (walker) {
      curr = walker;
      walker = walker->next;
      delete curr->shape;
      delete curr;
      }

//   XFreePixmap(_display,window);    // offscreen bitmap
//   XtDestroyWidget(topshell);
}


int
StaticView::Create(const char *title, int wid, int hei)
{
   ShapeNodePtr walker,curr;
//   Window w;

   PolkaInit();   // just to be safe

   pixX = wid;	 // If these are 0 here, they will be overriden
   pixY = hei;	 // in setupWindow

   if (!created) 
      setupStaticWindow(title);  // sets up X window and Xt widgets 

   /* Do default values */
   bgcolor = WHITE;
   if (created) {        // need to remove old stuff
      walker = shapes;
      while (walker) {
         curr = walker;
         walker = walker->next;
         delete curr->shape;
         delete curr;
         }
    }
   shapes = shapesTail = NULL;

   if (!created) {
//      w = XtWindow(easel);
//      prepareAnim(w);  /* sets destwin & window member variables */
// Fix it later !!!
	  prepareAnim();
      time = 0;   // need to reset
      }

   created = 1;
   return(1);
}


void
StaticView::Restart()
{
   ShapeNodePtr walker,curr;

   if (!created) 
      return;

   /* Do default values */
   bgcolor = WHITE;
   mapped = 1;
   debug = 0;
      
   walker = shapes;
   while (walker) {
      curr = walker;
      walker = walker->next;
      delete curr->shape;
      delete curr;
      }
   shapes = shapesTail = NULL;

   clear();
   time = 0;   // need to reset
}


void
StaticView::Map()
{
   if (mapped) return;
//   if (created)
//      XtPopup(topshell, XtGrabNone);
   mapped = 1;
}


void
StaticView::UnMap()
{
   if (!mapped) return;
//   if (created)
//     XtPopdown(topshell);
   mapped = 0;
}


int
StaticView::CheckInput()
{ 
   CheckXEvents(); 
   return(0);
}


void
StaticView::Refresh()
{
//   /* Must remove clip_rectangle set by animation loop damage routines */
//   XSetClipMask(_display, inq_gc(), None);

   animNextFrame();
//   XFlush(_display);
}
   

void
StaticView::clear()
{
   if (debug)
      printf("DEBUG: StaticView::clear()\n");

   int oldcolor = set_color(bgcolor);

//   XSetFillStyle(_display, inq_gc(), FillSolid);
//
//   /* Must remove clip_rectangle set by animation loop damage routines */
//   XSetClipMask(_display, inq_gc(), None);
//   XFillRectangle(_display, window, inq_gc(), 0, 0, pixX, pixY);
   animNextFrame();
   set_color(oldcolor);
}


void
StaticView::DrawPoint(int ti, int x, int y, const char *col)
{
   PointShape *pt = new PointShape(x,y,col);
   addPendingShape(ti, pt);
}


void
StaticView::DrawLine(int ti, int x, int y, int xs, int ys, const char *col)
{
   LineShape *l = new LineShape(x,y,xs,ys,col);
   addPendingShape(ti, l);
}


void
StaticView::DrawRectangle(int ti, int x, int y, int xs, int ys, const char *col)
{
   RectangleShape *r = new RectangleShape(x,y,xs,ys,col);
   addPendingShape(ti, r);
}



void
StaticView::DrawEllipse(int ti, int x, int y, int xs, int ys, const char *col)
{
   EllipseShape *e = new EllipseShape(x,y,xs,ys,col);
   addPendingShape(ti, e);
}


void
StaticView::DrawText(int ti, int x, int y, const char *st, 
                       const char *fnt, const char *col)
{
   TextShape *t = new TextShape(x,y,st,fnt,col);
   addPendingShape(ti, t);
}


void
StaticView::addPendingShape(int ti, Shape *sh)
{
   ShapeNode *sn = new ShapeNode;
   sn->appeartime = ti;
   sn->shape = sh;

   if (!shapes)
      shapes = sn;
   else
      shapesTail->next = sn;
   sn->prev = shapesTail;
   sn->next = NULL;
   shapesTail = sn;
}


void
StaticView::drawPendingShapes(int frame)
{
   ShapeNodePtr sh,old;

   if (debug)
      printf("DEBUG: StaticView::drawPendingShapes\n");

   for (sh=shapes; sh; ) 
      if (sh->appeartime <= frame) {
         damaged = 1;
//         sh->shape->draw(window,pixY,this);   
// Fix it later !!!!
         sh->shape->draw();   

         // remove from shapes list
         if (sh == shapes)
            shapes = sh->next;
         else
            sh->prev->next = sh->next;
         if (sh == shapesTail)
            shapesTail = sh->prev;
         else
            sh->next->prev = sh->prev;
         old = sh;
         sh = sh->next;

         delete old->shape;
         delete old;
         }
      else
        sh = sh->next;   

}


void
StaticView::AccumClip(int lx, int by, int rx, int ty)
{
   if (lx < cliplx) cliplx = lx;
   if (ty > clipty) clipty = ty;
   if (rx > cliprx) cliprx = rx;
   if (by < clipby) clipby = by;
}


int
StaticView::Animate(int start, int frames)
{
   int t;
   XRectangle xrect;
   
   if (debug)
      printf("DEBUG: StaticView::Animate start=%d for %d frames\n",start,frames);

   if (!mapped)
      return(Simulate(start, frames));

   BatchMode(1);
   for (t=0; t<frames; t++, start++)
       { CheckXEvents();

         cliplx = pixX;  cliprx = 0;   // set intial values
         clipby = pixY;  clipty = 0;
         damaged = 0;

//         // Remove any prior clipping
//         XSetClipMask(_display, inq_gc(), None);

         drawPendingShapes(start);   // may damage the area

         if (damaged) {
            xrect.x = cliplx;
            xrect.y = pixY - clipty;
            xrect.width = cliprx - cliplx + 1;
            xrect.height = clipty - clipby + 1;
//            XSetClipRectangles(_display,inq_gc(),0,0,&xrect,1,YXBanded);
            animNextFrame();          // blt onscreen
            }

         if (_delay)
            micro_sleep(_delay);

       }
   BatchMode(0);

   return(start);
}


int
StaticView::Simulate(int start, int frames)
{
   int t;
   
   if (debug)
      printf("DEBUG: StaticView::Simulate start=%d for %d frames\n",start,frames);

                  // Remove any prior clipping
//   XSetClipMask(_display, inq_gc(), None);

   for (t=0; t<frames; t++, start++)
       { 
         drawPendingShapes(start);
       }

   CheckXEvents();
   return(start);
}


/* animate1 is like Animate except no checking input or pausing.  It's
   used by the Animator's Animate routine to have a number of views
   going at once.                                                   */

int
StaticView::AnimateOne(int start)
{
   XRectangle xrect;
   
   if (debug)
      printf("DEBUG: StaticView::animate1 start=%d\n",start);

   if (!mapped)
      return(Simulate(start, 1));

   cliplx = pixX;  cliprx = 0;   // set intial values
   clipby = pixY;  clipty = 0;
   damaged = 0;

                  // Remove any prior clipping
//   XSetClipMask(_display, inq_gc(), None);

   drawPendingShapes(start);    // may damage the area

   if (damaged) {
      xrect.x = cliplx;
      xrect.y = pixY - clipty;
      xrect.width = cliprx - cliplx + 1;
      xrect.height = clipty - clipby + 1;
//      XSetClipRectangles(_display,inq_gc(),0,0,&xrect,1,YXBanded);
      animNextFrame();          // blt onscreen
      }

   return(start+1);
}


/************************************************************************/
/* StaticView::prepareAnim - Create Pixmaps to hold animation frame(s). */
/*		             Whenever the frame dimensions are changed  */
/*		             (eg. by resizing the window) call this     */
/*		             function to create new Pixmaps and update  */
/*		             View information.			        */
/*				 				        */
/************************************************************************/
void
StaticView::prepareAnim(/*Window wind*/)
{
//   int	     old;
//   Arg	     wargs[3];
//   Dimension w, h;
//   Window    newwin;
//   
//   if (debug)
//      printf("DEBUG: StaticView::prepareAnim\n");
//
//   destwin = wind;
//
//   /* Create offscreen frame(s)...Pixmap(s) */
//
//   XtSetArg(wargs[0], XtNwidth, &w);
//   XtSetArg(wargs[1], XtNheight, &h);
//   XtGetValues(easel, wargs, 2);
//
//   /* Must remove clip_rectangle set by animation loop damage routines */
//   XSetClipMask(_display, inq_gc(), None);
//
//   newwin = XCreatePixmap(_display, DefaultRootWindow(_display), w, h,
//  	         	  DefaultDepth(_display, DefaultScreen(_display)));
//
//   /* Pixmaps always start in an unknown state...clear it */
//   old = set_color(WHITE);
//   XFillRectangle(_display, newwin, inq_gc(), 0, 0, w, h);
//   set_color(old);
//
//   if (window) { // Not true only the first time through
//
//                 // Copy old stuff into new one
//      XCopyArea(_display, window, newwin, inq_gc(), 0, 0, pixX, pixY, 
//                                                              0, h-pixY);
//                 // Out with the old
//      XFreePixmap(_display, window);
//      }
//
//  /* In with the new */
//  window = newwin;
//
//   pixX = w;	/* Update global data */
//   pixY = h;
}


/***********************************************************************/
/* StaticView::animNextFrame -- Display next animation frame by	       */
/*			        PixBlting offscreen Pixmap to onscreen */
/*			        window.				       */
/*								       */
/***********************************************************************/
void
StaticView::animNextFrame()
{
   if (debug)
      printf("DEBUG: StaticView::animNextFrame\n");

//   XCopyArea(_display, window, destwin, inq_gc(), 0, 0, pixX, pixY, 0, 0);
}
