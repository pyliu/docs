/***************************************************************/
/*							                                   */
/*	       		Widget.cpp			                           */
/*							                                   */
/***************************************************************/
/*       Copyright 1997 Georgia Institute of Technology 
                     -- Roman S. Khramets                      */

#include "Widget.h"


__Widget::__Widget() {
}


Window XtWindow( Widget widget ) {
	return (Window)widget;
}