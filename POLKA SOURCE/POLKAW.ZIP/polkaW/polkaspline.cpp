/************************************************************************/
/*									                                    */
/*			POLKASPLINE.C					                            */
/*									                                    */
/*	Spline functions written by Steven P. Reiss.			            */
/*									                                    */
/************************************************************************/
/*      Copyright 1993 -- Georgia Tech -- John T. Stasko		        */


#include "polka_local.H"
#include "View.h"
#include "Pixmap.h"

/************************************************************************/
/*	Spline drawing definitions					                        */
/************************************************************************/

#define NUMPOINTS	200
#define SMOOTHNESS	1.0

typedef struct _LINELIST {
   int size;
   int count;
   char mallocd;
   int *x;
   int *y;
} LINELIST;

/************************************************************************/
/*	Spline Macro routines						*/
/************************************************************************/

#define DOUBLE(x)	((double)(x))
#define ROUND(x)	((int)((x)+0.5))

#define ThirdPoint(x0,y0,x1,y1,tx,ty) { 		\
   tx = (2*x0 + x1) / 3.0;				\
   ty = (2*y0 + y1) / 3.0;				\
}

#define Midpoint(x0,y0,x1,y1,mx,my) {			\
   mx = (x0 + x1) / 2.0;				\
   my = (y0 + y1) / 2.0;				\
}

#define INIT_LINELIST(ll,ct) {			       \
   (ll)->size = ct;				       \
   (ll)->count = 0;				       \
   (ll)->x = (int *) malloc(sizeof(int)*ct);   \
   (ll)->y = (int *) malloc(sizeof(int)*ct);   \
}



#define FREE_LINELIST(ll) {			       \
   if ((ll)->x) { 			       \
      free((char *)(ll)->x);				       \
      free((char *)(ll)->y);				       \
      (ll)->x = (int *) NULL;                          \
      (ll)->y = (int *) NULL;                          \
    };						       \
}

#define AddLine(ll,x0,y0,x1,y1) {			\
   if (ll->count >= ll->size) { 			\
      GrowBuf(ll);					\
    };							\
   if (ll->count == 0) {				\
      ll->x[0] = ROUND(x0);				\
      ll->y[0] = ROUND(y0);				\
      ll->count = 1;					\
    };							\
   ll->x[ll->count] = ROUND(x1);			\
   ll->y[ll->count] = ROUND(y1);			\
   ++(ll->count);					\
}

#define CanApproxWithLine(x0,y0,x2,y2,x3,y3,fg) {			\
   double triangleArea, sideSquared, dx, dy;				\
									\
   triangleArea = x0*y2 - x2*y0 + x2*y3 - x3*y2 + x3*y0 - x0*y3;	\
   triangleArea *= triangleArea;					\
   dx = x3 - x0;							\
   dy = y3 - y0;							\
   sideSquared = dx*dx + dy*dy; 					\
   fg = triangleArea <= SMOOTHNESS * sideSquared;			\
};

/************************************************************************/
/*	Forward definitions						*/
/************************************************************************/

static	void		CreateOpenLineList(LINELIST *,int [],int [],int );
static	void		CalcBSpline(LINELIST *, int, int, int, int, int,
                                       int, int, int );
static	void		AddBezierArc(LINELIST *,double ,double ,double ,
                             double , double ,double ,double ,double );
static	void		GrowBuf(LINELIST *);

/************************************************************************/
/*	TANGOspline -- draw a spline through given points 		*/
/************************************************************************/

void 
make_a_spline(int count,int x[],int y[], View *v)
{
   LINELIST ll;
   XPoint pts[NUMPOINTS];
   int i;

   INIT_LINELIST(&ll,NUMPOINTS);

   CreateOpenLineList(&ll, x, y, count);
   for (i=0; i<ll.count; i++) {
      pts[i].x = ll.x[i];
      pts[i].y = ll.y[i];
      }
   XDrawLines(v->DrawWindow(),inq_gc(),pts,ll.count,CoordModeOrigin);

   FREE_LINELIST(&ll);
}

/************************************************************************/
/*	CreateOpenLineList -- create line list for open spline		*/
/************************************************************************/

static void CreateOpenLineList(LINELIST *ll,int cpx[],int cpy[],int cpcount)
{
    register int cpi;

    ll->count = 0;

    CalcBSpline(ll, cpx[0], cpy[0], cpx[0], cpy[0], cpx[0], cpy[0], cpx[1], cpy[1] );
    CalcBSpline(ll, cpx[0], cpy[0], cpx[0], cpy[0], cpx[1], cpy[1], cpx[2], cpy[2] );

    for (cpi = 1; cpi < cpcount - 2; ++cpi) {
	CalcBSpline(ll, cpx[cpi - 1], cpy[cpi - 1], cpx[cpi], cpy[cpi],
			cpx[cpi + 1], cpy[cpi + 1], cpx[cpi + 2], cpy[cpi + 2] );
     };

    CalcBSpline(ll, cpx[cpi - 1], cpy[cpi - 1], cpx[cpi], cpy[cpi],
		    cpx[cpi + 1], cpy[cpi + 1], cpx[cpi + 1], cpy[cpi + 1] );
    CalcBSpline(ll, cpx[cpi], cpy[cpi], cpx[cpi + 1], cpy[cpi + 1],
		    cpx[cpi + 1], cpy[cpi + 1], cpx[cpi + 1], cpy[cpi + 1] );
}

/************************************************************************/
/*	CalcBSpline -- add points for spline to list			*/
/************************************************************************/

static void CalcBSpline(LINELIST *ll,int cminus1x,int cminus1y,int cx,int cy,
                    int cplus1x,int cplus1y,int cplus2x,int cplus2y )
{
   double p0x, p1x, p2x, p3x, tempx, p0y, p1y, p2y, p3y, tempy;
   double fcx,fcy,fc1x,fc1y,fcm1x,fcm1y,fc2x,fc2y;

   fcx = cx;
   fcy = cy;
   fc1x = cplus1x;
   fc1y = cplus1y;
   fcm1x = cminus1x;
   fcm1y = cminus1y;
   fc2x = cplus2x;
   fc2y = cplus2y;

   ThirdPoint(fcx,fcy,fc1x,fc1y, p1x,p1y );
   ThirdPoint(fc1x,fc1y,fcx,fcy, p2x,p2y );
   ThirdPoint(fcx,fcy,fcm1x,fcm1y, tempx,tempy);
   Midpoint(tempx, tempy, p1x, p1y, p0x, p0y);
   ThirdPoint(fc1x,fc1y,fc2x,fc2y, tempx,tempy );
   Midpoint(tempx, tempy, p2x, p2y, p3x, p3y);

   AddBezierArc(ll, p0x, p0y, p1x, p1y, p2x, p2y, p3x, p3y);
}

/************************************************************************/
/*	AddBezierArc -- add arc to					*/
/************************************************************************/

static void AddBezierArc(LINELIST *ll,double x0,double y0,double x1,double y1,
                        double x2,double y2,double x3,double y3)
{
   double midx01, midx12, midx23, midlsegx, midrsegx, cx;
   double midy01, midy12, midy23, midlsegy, midrsegy, cy;
   char fg;

   Midpoint(x0, y0, x1, y1, midx01, midy01);
   Midpoint(x1, y1, x2, y2, midx12, midy12);
   Midpoint(x2, y2, x3, y3, midx23, midy23);
   Midpoint(midx01, midy01, midx12, midy12, midlsegx, midlsegy);
   Midpoint(midx12, midy12, midx23, midy23, midrsegx, midrsegy);
   Midpoint(midlsegx, midlsegy, midrsegx, midrsegy, cx, cy);

   CanApproxWithLine(x0, y0, midlsegx, midlsegy, cx, cy, fg);
   if (fg) {
      AddLine(ll, x0, y0, cx, cy);
    }
   else if ( (midx01 != x1) || (midy01 != y1) ||
		(midlsegx != x2) || (midlsegy != y2) ||
		(cx != x3) || (cy != y3) ) {
	AddBezierArc(ll, x0, y0, midx01, midy01, midlsegx, midlsegy, cx, cy );
    };

   CanApproxWithLine(cx, cy, midx23, midy23, x3, y3, fg);
   if (fg) {
      AddLine(ll, cx, cy, x3, y3);
    }
   else if ( (cx != x0) || (cy != y0) ||
		(midrsegx != x1) || (midrsegy != y1) ||
		(midx23 != x2) || (midy23 != y2) ) {
	AddBezierArc(ll, cx, cy, midrsegx, midrsegy, midx23, midy23, x3, y3 );
    };
}

/************************************************************************/
/*	GrowBuf -- augment a line list					*/
/************************************************************************/

static void GrowBuf(LINELIST *ll)
{
   ll->size = (ll->size) * 2;

   ll->x = (int *) realloc((char *)ll->x, (ll->size)*sizeof(int));
   ll->y = (int *) realloc((char *)ll->y, (ll->size)*sizeof(int));
}
