/***************************************************************/
/*							                                   */
/*	       		EllipseImpl.cpp			                       */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#include "EllipseImpl.h"
#include "View.h"
#include "Pixmap.h"


EllipseImpl::EllipseImpl(View *a, int v, double lx, double ly, double sx, 
                   double sy, COLOR c, double f) 
             : AnimObjectImpl(a,v,lx,ly)
{
   type = P_Ellipse;
   sizex = sx;
   sizey = sy;
   strcpy(colorname,c);
   color = load_color(colorname);
   fill = f;
}


EllipseImpl::EllipseImpl(const EllipseImpl& e) : AnimObjectImpl( e )
{
   sizex = e.sizex;
   sizey = e.sizey;
   strcpy(colorname,e.colorname);
   color = e.color;
   fill = e.fill;
}


EllipseImpl::~EllipseImpl()
{
   Erase();
}


void 
EllipseImpl::GetValues(View* *vi, int *v, double *lx, double *ly, 
                double *sx, double *sy, COLOR c, double *f)
{
   if (vi) *vi=view;
   if (v) *v=visibility;
   if (lx) *lx=locx;
   if (ly) *ly=locy;
   if (sx) *sx=sizex;
   if (sy) *sy=sizey;
   if (c) strcpy(c,colorname);
   if (f) *f=fill;
}


LocPtr
EllipseImpl::Where(PART p)
{
   double	   cx,cy,rx,ry;

   cx = locx;
   cy = locy;
   rx = sizex;
   ry = sizey;
   switch (p)
   {
      case PART_C :
	 return( new Loc(cx,cy) );
      case PART_NW :
	 return( new Loc(cx-rx,cy+ry) );
      case PART_N :
	 return( new Loc(cx,cy+ry) );
      case PART_NE :
	 return( new Loc(cx+rx,cy+ry) );
      case PART_E :
	 return( new Loc(cx+rx,cy) );
      case PART_SE :
	 return( new Loc(cx+rx,cy-ry) );
      case PART_S :
	 return( new Loc(cx,cy-ry) );
      case PART_SW :
	 return( new Loc(cx-rx,cy-ry) );
      case PART_W :
	 return( new Loc(cx-rx,cy) );
   }
   return( new Loc(0.0,0.0) );
}


void
EllipseImpl::BoundBox(double *lx, double *by, double *rx, double *ty)
{
   *lx = locx - sizex;
   *rx = locx + sizex;
   *ty = locy + sizey;
   *by = locy - sizey;
}


void
EllipseImpl::transSpecial(char *atype, double dx, double dy)
{
   if (streql(atype,"FILL"))
      { fill +=  dx;
	if (fill < 0.0)
	   fill = 0.0;
	else if (fill > 1.0)
	   fill = 1.0;
        DamageIt();
      }
   else if (streql(atype,"RESIZE"))
      { DamageIt();
        sizex += dx;
	sizey += dy;
	if (sizex < ZERO)
	   sizex = ZERO;
	if (sizey < ZERO)
	   sizey = ZERO;
        DamageIt();
      }
   else if (streql(atype,"COLOR")) {
      color = get_pathcolor(dx,dy);
      DamageIt();
      }
}

   
void
EllipseImpl::Draw()
{
   FILL_STYLE curfill;

   curfill = get_fillstyle(fill);
   drawer(color,curfill);
}

void
EllipseImpl::Erase()
{
   FILL_STYLE curfill;

   curfill = get_fillstyle(fill);
   if (curfill == POLKA_FILL_OUTLINE)
      drawer(view->GetBgColor(),POLKA_FILL_OUTLINE);
   else
      drawer(view->GetBgColor(),POLKA_FILL_SOLID);
}


void
EllipseImpl::drawer(COLORINDEX col, FILL_STYLE curfill)
{
   int x0,y0,x1,y1;
   FILL_STYLE oldfill;

   if (!visibility)
      return;

   x0 = view->TO_PIX_X(locx);
   y0 = view->TO_PIX_Y(locy);
   x1 = view->SIZE_PIX_X(sizex);
   y1 = view->SIZE_PIX_Y(sizey);

   set_color(col);

   if (curfill == POLKA_FILL_OUTLINE)
      {
//        XDrawArc(_display,view->DrawWindow(),inq_gc(),x0-x1,y0-y1,
//                        x1<<1,y1<<1,0,23040);  // 23040 == 64*360
        XDrawEllipse(view->DrawWindow(),inq_gc(),x0-x1,y0-y1,x1<<1,y1<<1);
      }
   else 
      {
        oldfill = fill_style(curfill);
//        XFillArc(_display,view->DrawWindow(),inq_gc(),x0-x1,y0-y1,
//                               x1<<1,y1<<1,0,23040);
        XFillEllipse(view->DrawWindow(),inq_gc(),x0-x1,y0-y1,x1<<1,y1<<1);
        fill_style(oldfill);
      }
}
