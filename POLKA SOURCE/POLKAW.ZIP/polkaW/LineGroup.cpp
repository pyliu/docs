/***************************************************************/
/*							                                   */
/*	       		LineGroup.cpp		                           */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#include "LineGroup.h"


LineGroup::LineGroup()
{
   linewidth = 0.0;
   linestyle = 1.0;
   arrow = 0;
}


/***************************************************************/
/*							       */
/*   Make - create a row or column of AnimObjects              */
/*      subject to the given parameters.        	       */
/*							       */
/***************************************************************/

int
LineGroup::Make(View *v, Line *o[], int n, 
                double lx, double by, double rx, double ty)
{
   double s,locx,locy,sx,sy;
   int i;

   locx = lx;
   locy = by;
   for (i=0; i<n; i++) {
      if (horiz) {
         if (spacetype == SpacingNone) s = (rx-lx)/(n-1);
         else if (spacetype == SpacingSame) s = (rx-lx) / (n-1);
         else if (spacetype == SpacingAbsolute) s = spacing;

         if (useints)
            sy = (double)(intvals[i]-intmin) / 
                       (double)(intmax-intmin) * (ty-by);
         else if (usedoubles)
            sy = (doublevals[i]-doublemin) / 
                      (doublemax-doublemin) * (ty-by);
         else
            sy = ty-by;

         if (align == AlignBottom)
            o[i] = new Line(v,vis,locx,locy,0.0,sy,color,
                              linewidth,linestyle,arrow);
         else if (align == AlignMiddle)
            o[i] = new Line(v,vis,locx,by+(ty-by)/2.0-sy/2.0,
                             0.0,sy,color,linewidth,
                             linestyle,arrow);
         else if (align == AlignTop)
            o[i] = new Line(v,vis,locx,ty-sy,0.0,sy,color,
                             linewidth,linestyle,arrow);
         else /* bad */
            o[i] = new Line(v,vis,locx,locy,0.0,sy,color,
                              linewidth,linestyle,arrow);

         locx += s;
      }
      else /* vertical */ {
         if (spacetype == SpacingNone) s = (ty-by)/(n-1);
         else if (spacetype == SpacingSame) s = (ty-by) / (n-1);
         else if (spacetype == SpacingAbsolute) s = spacing;

         if (useints)
            sx = (double)(intvals[i]-intmin) / 
                               (double)(intmax-intmin) * (rx-lx);
         else if (usedoubles)
            sx = (doublevals[i]-doublemin) / (doublemax-doublemin) * (rx-lx);
         else
            sx = rx-lx;

         if (align == AlignLeft)
            o[i] = new Line(v,vis,locx,locy,sx,0.0,color,
                             linewidth,linestyle,arrow);
         else if (align == AlignMiddle)
            o[i] = new Line(v,vis,lx+(rx-lx)/2.0-sx/2.0,locy,
                             sx,0.0,color,linewidth,linestyle,arrow);
         else if (align == AlignRight)
            o[i] = new Line(v,vis,rx-sx,locy,sx,0.0,color,
                             linewidth,linestyle,arrow);
         else /* bad */
            o[i] = new Line(v,vis,locx,locy,sx,0.0,color,
                              linewidth,linestyle,arrow);

         locy += s;
      }
   }
   return (1);
}  
