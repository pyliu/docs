/***************************************************************/
/*							                                   */
/*	       		Ellipse.cpp			                           */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#include "Ellipse.h"


Ellipse& 
Ellipse::operator=(const Ellipse& rhs) 
{
  if  (this == &rhs) return *this;
  AnimObject::operator=(rhs);
  return *this;
}
