/***************************************************************/
/*							                                   */
/*	       		constants.cpp			                       */
/*							                                   */
/***************************************************************/
/*       Copyright 1997 Georgia Institute of Technology 
                     -- Roman S. Khramets                      */

#include "constants.h"

const ResizeMode ConstantAspect = 0;
const ResizeMode CoordStretch   = 1;
