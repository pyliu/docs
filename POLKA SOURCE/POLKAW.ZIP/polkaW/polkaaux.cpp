/***************************************************************/
/*							                                   */
/*			     POLKAAUX.CPP		                           */
/*							                                   */
/***************************************************************/
/*       Copyright 1993 Georgia Institute of Technology 
                     -- John T. Stasko                         */

#include "common_includes.h"
#include <string.h>

int
streql(const char* a, const char* b)
{
   if (strcmp(a,b))
      return(0);
   else 
      return(1);
}



int
streqln(const char *a, const char *b, int n)
{
   for (int i=0; i<n; i++) {
       if (*(b+i) != *(a+i))
          return(0);
       else if (*(a+i) == '\0')
          return(1);
   }
   return(1);
}



