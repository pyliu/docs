/***************************************************************/
/*							                                   */
/*	       		Loc1Desc.cpp	                               */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#include "Loc1Desc.h"


Loc1Desc::Loc1Desc()
{
   num = 0;
}


int
Loc1Desc::Make(Loc *l[])
{
   double x,y,dx,dy;
   int i;

   if (num <= 0) return(0);
   if (num == 1)
       { l[0] = new Loc(fx,fy);
         return(1);
     }

   x=fx; y=fy;
   dx = (tx - fx) / (num-1);
   dy = (ty - fy) / (num-1);
   for (i=0; i<num; i++)
       { l[i] = new Loc(x,y);
         x += dx;
         y += dy;
     }
   return(1);
}
