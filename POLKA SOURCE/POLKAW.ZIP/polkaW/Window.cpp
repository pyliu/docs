/***************************************************************/
/*							                                   */
/*	       		Window.cpp			                           */
/*							                                   */
/***************************************************************/
/*       Copyright 1997 Georgia Institute of Technology 
                     -- Roman S. Khramets                      */

#include "Window.h"
#include "Pixmap.h"


__Window::__Window() {
	hWnd   = NULL;
	hdc    = NULL;
}


__Window::~__Window() {
	destroyWindow();
}


void __Window::destroyWindow() {
	if( hWnd ) {
		if( hdc ) {
			ReleaseDC( hWnd, hdc );
			hdc = NULL;
		}
		DestroyWindow( hWnd );
		hWnd   = NULL;
	}
}


HWND __Window::setWnd( HWND aWnd ) {
	HWND  oldWnd;

	// if a window have been associated
	// with Window before
	if( hWnd && hdc ) {
	    ReleaseDC( hWnd, hdc );
	}

	oldWnd = hWnd;
	hWnd   = aWnd;
	hdc    = GetDC( hWnd );

	SetBkMode( hdc, OPAQUE );
	SetPolyFillMode( hdc, WINDING );

	return oldWnd;
}


BOOL __Window::ShowWindow( int nCmdShow ) {
	return ::ShowWindow (hWnd, nCmdShow);
}


BOOL __Window::UpdateWindow() {
	return ::UpdateWindow (hWnd);
}
