/***************************************************************/
/*							                                   */
/*	       		Animator.cpp	                               */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#include "Animator.h"


Animator::Animator()
{
   numviews = 0;
   evts = NULL;
   PolkaInit();
}   


void
Animator::RegisterAlgoEvt(const char *name, const char *ptn)
{
   const char *p;
   ALGOEVT *old;

   if (!name)
      { cout << "ERROR (AlgoEvtRegister): Attempt to define ";
        cout << "algorithm event with empty name" << endl;
        return;
      }
   for (p=ptn; p && *p; p++)
      { 
        if ((*p != 'd') && (*p != 'f') && (*p != 's'))
           {
             cout << "ERROR (AlgoEvtRegister): Illegal parameter type ";
             cout << *p << " passed with event " << name << endl;
             return;
           }
      }

   old = evts;
   evts = new _ALGOEVT;
   evts->next = old;
   evts->name = new char[strlen(name) + 1];
   strcpy(evts->name,name);
   if (ptn)
      { 
        evts->params = new char[strlen(ptn) + 1];
        strcpy(evts->params,ptn);
      }
   else
      evts->params = NULL;
}


int
Animator::SendAlgoEvt(const char *name ...)
{
   ALGOEVT *evt;
   va_list ap;
   char *type;
   int intcount,doublecount,stringcount;
   int retval;

   if (!name)
      { cout << "ERROR (SendAlgoEvt): Attempt to send message ";
        cout << "with empty algorithm event name" << endl;
        return(0);
      }
   for (evt=evts; evt; evt=evt->next)
      if (streql(name,evt->name))
         break;
   if (!evt)
      { cout << "ERROR (SendAlgoEvt): Attempt to send message ";
        cout << "with invalid algorithm event name " << name << endl;
        return(0);
      }
     
   va_start(ap,name);

   intcount = doublecount = stringcount = 0;
   for (type=evt->params;;type++) { 
       if (!type || (*type == '\0'))
          break;
       switch (*type) {
         case 'd':
           if (intcount == MAXPARAMS) {
              cout << "ERROR (SendAlgoEvt):  Too many integer parameters ";
              cout << "to event " << name << endl;
              return(0);
	      }
           AnimInts[intcount++] = va_arg(ap,int);
           break;
         case 'f':
           if (doublecount == MAXPARAMS) {
              cout << "ERROR (SendAlgoEvt):  Too many double parameters ";
              cout << "to event " << name << endl;
              return(0);
	      }
           AnimDoubles[doublecount++] = va_arg(ap,double);
           break;
         case 's':
           if (stringcount == MAXPARAMS) {
              cout << "ERROR (SendAlgoEvt):  Too many string parameters ";
              cout << "to event " << name << endl;
              return(0);
	      }
           AnimStrings[stringcount++] = va_arg(ap,char *);
           break;
         default:
           cout << "ERROR (AlgoEvt): Detected weird parameter type";
           cout << "--Internal error" << endl;
           return(0);
       }
   }

   strcpy(AlgoEvtName,name);
   retval = Controller();
   return(retval);
}         
                 

void
Animator::RegisterView(class BaseView *v)
{
   views[numviews++] = v;
}


void
Animator::RemoveView(class BaseView *v)
{
   int i;

   for (i=0; i<numviews; i++)
       if (views[i] == v) break;
   if (i == numviews)  // it wasn't there for some reason
      return;
   else {
      for (   ; i<numviews-1; i++)
          views[i] = views[i+1];
      numviews--;
      return;
      }
}


int
Animator::Animate(int ti, int len)
{
   int t,i;

   for (t=0; t<len; t++, ti++) {
       BatchMode(1);
       CheckXEvents();
       for (i=0; i<numviews; i++)
           views[i]->AnimateOne(ti);
       if (_delay)
           micro_sleep(_delay);
       BatchMode(0);
       }
   return(ti);
}
