/***************************************************************/
/*							                                   */
/*	       		Drawable.cpp			                       */
/*							                                   */
/***************************************************************/
/*       Copyright 1997 Georgia Institute of Technology 
                     -- Roman S. Khramets                      */

#include <math.h>

#include "Drawable.h"
#include "GC.h"
#include "polka_local.H"

static unsigned int uiminarg1, uiminarg2;
#define UIMIN(a,b) (uiminarg1=(a),uiminarg2=(b),(uiminarg1) < (uiminarg2) ? \
(uiminarg1) : (uiminarg2))

static unsigned int uimaxarg1, uimaxarg2;
#define UIMAX(a,b) (uimaxarg1=(a),uimaxarg2=(b),(uimaxarg1) > (uimaxarg2) ? \
(uimaxarg1) : (uimaxarg2))


// intersection structure
typedef struct {
	unsigned int left;
	unsigned int right;
} I_STRUCT;


// assume that c1_1 < c1_2
// and c2_1 < c2_2
int INTERSECTION( unsigned int c1_1,
				  unsigned int c1_2,
				  unsigned int c2_1,
				  unsigned int c2_2,
				  I_STRUCT *intersection ) {
	if( c1_2 <= c2_1 || c2_2 <= c1_1 ) {
		return 0;
	}

	intersection->left  = UIMAX( c1_1, c2_1 );
	intersection->right = UIMIN( c1_2, c2_2 );

	return 1;
}


int rectIntersection( XRectangle *clipRect,
					  XRectangle *rect,
					  XRectangle *result ) {
	I_STRUCT x_int;
	I_STRUCT y_int;

	if( !INTERSECTION(clipRect->x,
		              clipRect->x + clipRect->width,
					  rect->x,
					  rect->x + rect->width,
					  &x_int) ||
		!INTERSECTION(clipRect->y,
					  clipRect->y + clipRect->height,
					  rect->y,
					  rect->y + rect->height,
					  &y_int) ) {
		return 0;
	}

	result->x      = x_int.left;
	result->y      = y_int.left;
	result->width  = x_int.right - x_int.left;
	result->height = y_int.right - y_int.left;

	return 1;
}


BOOL XCopyArea( Drawable src,  // handle to source device context 
			    Drawable dest, // window to blt to
				GC  gc,        // the graphics context - mainly for cliping
			    int nXSrc,     // x-coordinate of source rectangle�s upper-left corner 
			    int nYSrc,     // y-coordinate of source rectangle�s upper-left corner 
			    int nWidth,    // width of destination rectangle 
			    int nHeight,   // height of destination rectangle 
			    int nXDest,    // x-coordinate of destination rectangle�s upper-left corner 
	            int nYDest     // y-coordinate of destination rectangle�s upper-left corner 
			  ) {
	return dest->XCopyArea( gc,
		                    nXDest,
		                    nYDest,
							nWidth,
							nHeight,
							src,
							nXSrc,
							nXSrc );
}


void XDrawRectangle( Drawable window,
					 GC gc,
					 int nStartX,
					 int nStartY,
					 int nWidth,
					 int nHeight ) {
    window->XDrawRectangle( gc, nStartX, nStartY, nWidth, nHeight );
}


void XFillRectangle( Drawable window,
					 GC gc,
					 int nStartX,
					 int nStartY,
					 int nWidth,
					 int nHeight ) {
    window->XFillRectangle( gc, nStartX, nStartY, nWidth, nHeight );
}


void XDrawLine( Drawable window,
			    GC gc,
			    int nFromX,
				int nFromY,
				int nToX,
				int nToY ) {
	window->XDrawLine( gc, nFromX, nFromY, nToX, nToY );
}


void XDrawLines( Drawable window,
				 GC gc,
				 const XPoint *points,
				 int nPoints,
				 int mode ) {
	window->XDrawLines( gc, points, nPoints, mode );
}


void XFillPolygon( Drawable window,
				   GC gc,
				   const XPoint *points,
				   int nPoints,
				   int shape,
				   int mode ) {
	window->XFillPolygon( gc, points, nPoints, shape, mode );
}


void XDrawEllipse( Drawable window,
				   GC gc,
				   int upperX,
				   int upperY,
				   unsigned int width,
				   unsigned int height ) {
	window->XDrawEllipse( gc, upperX, upperY, width, height );
}


void XFillEllipse( Drawable window,
				   GC gc,
				   int upperX,
				   int upperY,
				   unsigned int width,
				   unsigned int height ) {
	window->XFillEllipse( gc, upperX, upperY, width, height );
}


void XDrawArc( Drawable window,
			   GC gc,
			   int upperX,
			   int upperY,
			   unsigned int width,
			   unsigned int height,
			   int angle1,
			   int angle2 ) {
	window->XDrawArc( gc, upperX, upperY, width, height, angle1, angle2 );
}


void XFillArc( Drawable window,
			   GC gc,
			   int upperX,
			   int upperY,
			   unsigned int width,
			   unsigned int height,
			   int angle1,
			   int angle2 ) {
	window->XFillArc( gc, upperX, upperY, width, height, angle1, angle2 );
}


void XDrawString( Drawable window,
				  GC gc,
				  int x,
				  int y,
				  char *str,
				  int length ) {
	window->XDrawString( gc, x, y, str, length );
}


void XDrawCircle( Drawable window,
				  GC gc,
				  int x,
				  int y,
				  unsigned int radius ) {
	window->XDrawCircle( gc, x, y, radius );
}


void XFillCircle( Drawable window,
				  GC gc,
				  int x,
				  int y,
				  unsigned int radius ) {
	window->XFillCircle( gc, x, y, radius );
}


__Drawable::__Drawable() {
}


__Drawable::~__Drawable() {
}


BOOL __Drawable::XCopyArea( GC  gc,       // graphics context
		                    int nXDest,   // x-coordinate of destination rectangle�s upper-left corner 
							int nYDest,   // y-coordinate of destination rectangle�s upper-left corner 
							int nWidth,   // width of destination rectangle 
							int nHeight,  // height of destination rectangle 
						    Drawable src, // handle to source device context 
						    int nXSrc,    // x-coordinate of source rectangle�s upper-left corner 
						    int nYSrc     // y-coordinate of source rectangle�s upper-left corner 
							) {
	if( gc->nRectangles == 0 ) {
		return BitBlt( hdc,
					   nXDest,
					   nYDest,
					   nWidth,
					   nHeight,
					   src->getDC(),
					   nXSrc,
					   nYSrc,
					   SRCCOPY );
	} else {
		BOOL returnValue;
		XRectangle *curClipRect;
		XRectangle clipRect;
		XRectangle rect;
		XRectangle result;

		rect.x      = nXDest;
		rect.y      = nYDest;
		rect.width  = nWidth;
		rect.height = nHeight;

		for( int i = 0; i < gc->nRectangles; i++ ) {
			curClipRect = &gc->rectangles[i];

			clipRect.x = gc->clip_x_origin + curClipRect->x;
			clipRect.y = gc->clip_y_origin + curClipRect->y;
			clipRect.width  = curClipRect->width + 1;
			clipRect.height = curClipRect->height + 1;

			if( rectIntersection(&clipRect, &rect, &result) ) {
				returnValue = BitBlt( getDC(),
									  result.x,
									  result.y,
									  result.width,
									  result.height,
									  src->getDC(),
									  nXSrc + (result.x - nXDest),
									  nYSrc + (result.y - nYDest),
									  SRCCOPY );
				if( returnValue != TRUE ) {
					return returnValue;
				}
			}
		}
	}

	return TRUE;
}


void __Drawable::copyPolyFillAttributes( GC gc ) {
	HBRUSH hPreviousBrush;
	HBRUSH hBrush;

	SetBkColor( hdc, gc->getBkColor() );
	SetTextColor( hdc, gc->getTextColor() );

	hBrush = (HBRUSH)CreateBrushIndirect( gc->getBrush() );
	hPreviousBrush = (HBRUSH)SelectObject( hdc, hBrush );
	DeleteObject( hPreviousBrush );
}


void __Drawable::XDrawRectangle( GC gc,
								 int nStartX,
								 int nStartY,
								 int nWidth,
								 int nHeight ) {
	HBRUSH hOldBrush;
	copyLineDrawingAttributes( gc );
	hOldBrush = (HBRUSH)SelectObject( hdc, GetStockObject(NULL_BRUSH) );
	Rectangle( hdc, nStartX, nStartY, nStartX + nWidth + 1, nStartY + nHeight + 1 );
	SelectObject( hdc, hOldBrush );
}


void __Drawable::XFillRectangle( GC gc, 
							     int nStartX,
							     int nStartY,
							     int nWidth,
							     int nHeight ) {
	RECT     fillRect;
	HBRUSH   hBrush;

	// structure for the rectangle
	// to be filled
    fillRect.left   = nStartX;
	fillRect.top    = nStartY;
	fillRect.right  = nStartX + nWidth + 1;
    fillRect.bottom = nStartY + nHeight + 1;

	copyPolyFillAttributes(gc);
	hBrush = CreateBrushIndirect( gc->getBrush() );
	FillRect( hdc, &fillRect, hBrush );
	DeleteObject( hBrush );
}


void __Drawable::copyLineDrawingAttributes( GC gc ) {
	EXTLOGPEN  *elpPen;
	LOGBRUSH   *lbPenBrush;
	HPEN       hPreviousPen;
	HPEN       hPen;

	elpPen     = gc->getPen();
	lbPenBrush = gc->getPenBrush();
	hPen = ExtCreatePen( elpPen->elpPenStyle,
		                 elpPen->elpWidth,
						 lbPenBrush,
						 elpPen->elpNumEntries,
						 (elpPen->elpNumEntries == 0 ?
                          NULL : elpPen->elpStyleEntry) );
	hPreviousPen = (HPEN)SelectObject( hdc, hPen );
	DeleteObject( hPreviousPen );

	SetBkColor( hdc, gc->getBkColor() );
}


void __Drawable::XDrawLine( GC gc,
						    int nFromX,
					        int nFromY,
						    int nToX,
						    int nToY ) {
	copyLineDrawingAttributes( gc );
	MoveToEx( hdc, nFromX, nFromY, NULL );
    LineTo( hdc, nToX, nToY );
}


void __Drawable::XDrawLines( GC gc,
							 const XPoint *points,
							 int nPoints,
							 int mode ) {
	copyLineDrawingAttributes( gc );
	if( setUpPath(gc, points, nPoints, mode) ) {
		StrokePath( hdc );
	}
}


void __Drawable::XFillPolygon( GC gc,
				               const XPoint *points,
							   int nPoints,
							   int shape, 
							   int mode ) {
	HPEN hPreviousPen;
	
	copyPolyFillAttributes( gc );
	hPreviousPen = (HPEN)SelectObject( hdc, GetStockObject(NULL_PEN) );
	if( setUpPath(gc, points, nPoints, mode) ) {
		StrokeAndFillPath( hdc );
	}

	DeleteObject( SelectObject(hdc, hPreviousPen) );
}


int __Drawable::setUpPath( GC gc,
						   const XPoint *points,
						   int nPoints,
						   int mode ) {
	if( nPoints ) {
		int i;

		MoveToEx( hdc, points[0].x, points[0].y, NULL );
		BeginPath( hdc );

		switch( mode ) {
		    case CoordModeOrigin:
		        for( i = 1; i < nPoints; i++ ) {
					LineTo( hdc, points[i].x, points[i].y );
				}
		    break;

		    case CoordModePrevious:
				int curX;
				int curY;

				curX = points[0].x;
				curY = points[0].y;
		        for( i = 1; i < nPoints; i++ ) {
					curX += points[i].x;
					curY += points[i].y;
					LineTo( hdc, curX, curY );
				}
			break;
		}

		EndPath( hdc );
		return 1;
	}

	return 0;
}


void __Drawable::XDrawEllipse( GC gc,
							   int upperX,
							   int upperY,
							   unsigned int width,
							   unsigned int height ) {
	HBRUSH hOldBrush;
	copyLineDrawingAttributes( gc );
	hOldBrush = (HBRUSH)SelectObject( hdc, GetStockObject(NULL_BRUSH) );
	Ellipse( hdc, upperX, upperY, upperX + width + 1, upperY + height + 1);
	SelectObject( hdc, hOldBrush );
}


void __Drawable::XFillEllipse( GC gc,
							   int upperX,
							   int upperY,
							   unsigned int width,
							   unsigned int height ) {
	HPEN hPreviousPen;

	copyPolyFillAttributes( gc );
	hPreviousPen = (HPEN)SelectObject( hdc, GetStockObject(NULL_PEN) );
	Ellipse( hdc, upperX, upperY, upperX + width + 1, upperY + height + 1 );
	DeleteObject( SelectObject(hdc, hPreviousPen) );
}


void __Drawable::XDrawArc( GC gc,
						   int upperX,
						   int upperY,
						   unsigned int width,
						   unsigned int height,
						   int angle1,
						   int angle2
						 ) {
	copyLineDrawingAttributes( gc );

    int startX;
	int startY;
	int stopX;
	int stopY;

	calcArc( upperX, upperY,
		     width, height,
			 angle1, angle2,
			 startX, startY, 
			 stopX, stopY );

	HBRUSH hPreviousBrush;
	HBRUSH hBrush;

	hBrush = (HBRUSH)GetStockObject( NULL_BRUSH );
	hPreviousBrush = (HBRUSH)SelectObject( hdc, hBrush );

	Pie( hdc, upperX, upperY, upperX + width + 1, upperY + height + 1, 
		 startX, startY, stopX, stopY );

	hBrush = (HBRUSH)SelectObject( hdc, hPreviousBrush );
	DeleteObject( hBrush );
}


void __Drawable::XFillArc( GC gc,
						   int upperX,
						   int upperY,
						   unsigned int width,
						   unsigned int height,
						   int angle1,
						   int angle2
						 ) {
	HPEN hPreviousPen;

	copyPolyFillAttributes( gc );
	hPreviousPen = (HPEN)SelectObject( hdc, GetStockObject(NULL_PEN) );

    int startX;
	int startY;
	int stopX;
	int stopY;

	calcArc( upperX, upperY,
		     width, height,
			 angle1, angle2,
			 startX, startY, 
			 stopX, stopY );
	Pie( hdc, upperX, upperY, upperX + width + 1, upperY + height + 1, 
		 startX, startY, stopX, stopY );

	DeleteObject( SelectObject(hdc, hPreviousPen) );
}


void __Drawable::calcArc( int upperX,
						  int upperY,
						  unsigned int width,
						  unsigned int height,
						  int angle1,
						  int angle2,
						  int &startX,
						  int &startY,
						  int &stopX,
						  int &stopY ) {
	unsigned int maxDim = (width > height) ? width : height;
	double r;
	double pi = 3.1415926535;
	double pi_2 = 2*pi;
	int centerX;
	int centerY;
	double startAngle;
	double stopAngle;

	r = maxDim;
	startAngle = (((double)angle1)/(360.0*64.0))*pi_2;
	stopAngle  = startAngle + (((double)angle2)/(360.0*64.0))*pi_2;
	startX = r*cos( startAngle );
	startY = r*sin( startAngle );
	stopX = r*cos( stopAngle );
	stopY = r*sin( stopAngle );
	centerX = upperX + width/2;
	centerY = upperY + height/2;

	startX = centerX + startX;
	startY = centerY - startY;
	stopX  = centerX + stopX;
	stopY  = centerY - stopY;
}


void __Drawable::copyTextDrawingAttributes( GC gc ) {
	SetTextColor( hdc, gc->getTextColor() );
	SelectObject( hdc, gc->getFont() );
}


void __Drawable::XDrawString( GC gc, int x, int y, char *str, int length ) {
	int bkMode;
	UINT txAlign;
	
	copyTextDrawingAttributes(gc);
	bkMode = GetBkMode(hdc);
	txAlign = GetTextAlign(hdc);
	SetBkMode(hdc, TRANSPARENT);
	SetTextAlign(hdc, TA_LEFT|TA_BOTTOM);
	TextOut(hdc, x, y, str, length);
	SetBkMode(hdc, bkMode);
	SetTextAlign(hdc, txAlign);
}


void __Drawable::XDrawCircle( GC gc, int x, int y, unsigned int radius ) {
	HBRUSH hOldBrush;
	copyLineDrawingAttributes( gc );
	hOldBrush = (HBRUSH)SelectObject( hdc, GetStockObject(NULL_BRUSH) );
	Ellipse( hdc, x-radius, y-radius, x+radius, y+radius );
	SelectObject( hdc, hOldBrush );
}


void __Drawable::XFillCircle( GC gc, int x, int y, unsigned int radius ) {
	HPEN hOldPen;
	copyPolyFillAttributes( gc );
	hOldPen = (HPEN)SelectObject( hdc, GetStockObject(NULL_PEN) );
	Ellipse( hdc, x-radius, y-radius, x+radius, y+radius );
	SelectObject( hdc, hOldPen );
}
