/***************************************************************/
/*							                                   */
/*	       		AnimObjectImpl.cpp	                           */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#include "AnimObjectImpl.h"
#include "View.h"


AnimObjectImpl::AnimObjectImpl(View *vi, int v, double x, double y)
{
   if (vi->debug)
      printf("DEBUG: AnimObjectImpl::AnimObjectImpl vis=%d  x=%lf y=%lf\n",v,x,y);

   view = vi;
   type = P_Misc;
   visibility = v;
   locx = x;
   locy = y;
}


AnimObjectImpl::AnimObjectImpl(const AnimObjectImpl& a)
{
   view =  a.view;
   type = a.type;
   visibility = a.visibility;
   locx = a.locx;
   locy = a.locy;
}


void
AnimObjectImpl::Trans(char* atype, double dx, double dy)
{
   // This should never get called with a Set AnimObject

   AOPtr aop;

   if (view->debug)
      printf("DEBUG: AnimObjectImpl::Trans  %s (%lf, %lf)\n",atype,dx,dy);

   if (streql(atype,"MOVE"))
      { 
        DamageIt();
        locx += dx;
        locy += dy;
        DamageIt();
      }
   else if (streql(atype,"VIS"))
      { visibility = !visibility;
        DamageIt();
      }
   else if (streql(atype,"RAISE"))
      { for (aop=view->AOHead; aop->object != wrapper; aop=aop->next) ;
        if (!aop) // weird error
           return;
        if (aop == view->AOHead) // do nothing
           return;
        else if (aop == view->AOTail)
           view->AOTail = aop->prev;
        else
           aop->next->prev = aop->prev;
        aop->prev->next = aop->next;
        aop->next = view->AOHead;
        view->AOHead->prev = aop;
        view->AOHead = aop;
        aop->prev = NULL;

        DamageIt();
      }
   else if (streql(atype,"LOWER"))
      { for (aop=view->AOHead; aop->object != wrapper; aop=aop->next) ;
        if (!aop) // weird error
           return;
        if (aop == view->AOTail) // do nothing
           return;
        else if (aop == view->AOHead)
           view->AOHead = aop->next;
        else
           aop->prev->next = aop->next;
        aop->next->prev = aop->prev;
        aop->prev = view->AOTail;
        view->AOTail->next = aop;
        view->AOTail = aop;
        aop->next = NULL;

        DamageIt();
      }
   else if (streql(atype,"ALTER_LL"))
      { 
        view->AlterLLCoord(dx,dy);
        view->RefreshNeeded(1);
      }
   else if (streql(atype,"ALTER_UR"))
      { 
        view->AlterURCoord(dx,dy);
        view->RefreshNeeded(1);
      }
   else
      { transSpecial(atype,dx,dy);
      }
}


void
AnimObjectImpl::DamageIt()
{
   double lx,by,rx,ty;

   BoundBox(&lx,&by,&rx,&ty);         // where this object is now
// printf("Damaging  (%.3lf, %.3lf)   (%.3lf, %.3lf)\n",lx,by,rx,ty);
   view->DamageCheck(lx,by,rx,ty);    // update view's damage region
}


int
AnimObjectImpl::IsPickIn(double xpt, double ypt)
{
   double bblx,bbby,bbrx,bbty;

   BoundBox(&bblx, &bbby, &bbrx, &bbty);

   if ((bblx <= xpt) && (xpt <= bbrx) && (bbby <= ypt) && (ypt <= bbty))
      return(1);
   else
      return(0);
}   
