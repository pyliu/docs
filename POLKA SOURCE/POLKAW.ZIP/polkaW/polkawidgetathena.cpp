/***************************************************************/
/*							                                   */
/*	       		polkawidgetathena.cpp                          */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#include "polka_local.H"
#include "polka_version.H"

#include "View.h"
#include "polka_staticwindow.H"
#include "StaticView.h"

#include "Init.h"

// system dependent
#include <windows.h>

// set of wrappers
#include "ViewWindow.h"


/* Variables and functions for the Control Panel */

const   int           SLIDERSIZE = 5;

// View class default window size
extern RECT viewWndDefRect;
// the application handler
extern HINSTANCE hApp;
// application's display mode (minimized, normal size, etc.)
extern int iAppCmdShow;
// control panel window size
extern RECT mainWndRect;

        int           _color_screen;
        int           _delay = 0;
static  int           _started = 0;
static  int           _controlsOn = 1;
static  int           _debugging = 0;
static  int           _paused;
static  int           _stepjusthit;

//
int     _createControlPanel = 0;


int getPaused() {
    return _paused;
}


static void controlPanel();

void speedCB(void *param);
void pauseCB(void *param);
void stepCB(void *param);
void quitCB(void *param);


/* Functions for View windows */

void debugCB( Widget w );
void refreshCB( Widget w );
void closeCB( void *param );
void panlCB( Widget w );
void panrCB( Widget w );
void pandCB( Widget w );
void panuCB( Widget w );
void zoominCB( Widget w );
void zoomoutCB( Widget w );

/* Functions for StaticView windows */

//static void staticdebugCB(Widget, XtPointer, XtPointer);
//static void staticrefreshEH(Widget, XtPointer, XEvent *, Boolean *);
//static void staticrefreshCB(Widget, XtPointer, XtPointer);
//static void staticcloseCB(Widget, XtPointer, XtPointer);

static void staticdebugCB(/*Widget, XtPointer, XtPointer*/);
static void staticrefreshEH(/*Widget, XtPointer, XEvent *, Boolean **/);
static void staticrefreshCB(/*Widget, XtPointer, XtPointer*/);
static void staticcloseCB(/*Widget, XtPointer, XtPointer*/);

/* Functions that the driver application calling Polka must define */


APP_CALLBACK AppRunPauseCB = NULL;
APP_CALLBACK AppStepCB = NULL;
APP_CALLBACK AppDelayCB = NULL;
APP_CALLBACK AppCloseCB = NULL;
APP_CALLBACK AppQuitCB = NULL;



/**************************************************************/
/* PolkaInitialize  - Called by outside program that already  */
/*    has opened and set up the X display.                    */
/*							      */
/* RETURNS:  None.					      */
/**************************************************************/

void
PolkaInitialize()
{
}


/**************************************************************/
/* PolkaDisableControls  - Calling this routine will          */
/*    inactivate the buttons on the Polka control panel (not  */
/*    the speed bar though).  This will make it such that     */
/*    Polka will not do the pausing and stepping.	      */
/*							      */
/* RETURNS:  None.					      */
/**************************************************************/

void
PolkaDisableControls()
{
   _controlsOn = 0;
}



/**************************************************************/
/* PolkaSetCallbacks  - Called by outside program so it will  */
/*    get called when control panel buttons are hit.          */
/*							      */
/* RETURNS:  None.					      */
/**************************************************************/

void
PolkaSetCallbacks(APP_CALLBACK rp, APP_CALLBACK st, APP_CALLBACK del,
   APP_CALLBACK clo, APP_CALLBACK qui)
{
	AppRunPauseCB = rp;
	AppStepCB = st;
	AppDelayCB = del;
	AppCloseCB = clo;
	AppQuitCB = qui;
}


/**************************************************************/
/* PolkaInit - Get X-specific info (appcontext, display)      */
/*    for use by other routines.  Create applicationShell.    */
/*							      */
/* RETURNS:  None.					      */
/**************************************************************/

void
PolkaInit()
{
   if (_started) return;

   _paused = 1;
   _stepjusthit = 0;

    // Fix later to check if we actually have a color screen
    _color_screen = 1;
    initGC();

    controlPanel();
	_started = 1;
}



/**************************************************************/
/* PolkaReset - Used to restart an animation.  It resets the  */
/*    control panel to the start-up values.                   */
/*							      */
/* RETURNS:  None.					      */
/**************************************************************/

void
PolkaReset()
{
	extern HWND hControlPanel;
   _paused = 1;
   _stepjusthit = 0;
   _delay = 0;
	SendMessage(hControlPanel, WM_COMMAND, RESET_COMMAND, 0);
}


/**************************************************************/
/* PolkaResume -- Programmatically resume the animation       */
/*							                                  */
/* RETURNS:  None.					                          */
/**************************************************************/
void
PolkaResume()
{
	extern HWND hControlPanel;
	SendMessage(hControlPanel, WM_COMMAND, RESUME_COMMAND, 0);
}


/**************************************************************/
/* PolkaPause -- Programmatically force a pause		          */
/*							                                  */
/* RETURNS:  None.					                          */
/**************************************************************/
void
PolkaPause()
{
/*
   Arg args[1];
   XmString newLabel;

   if (!_paused) {
      _paused = 1;
      newLabel = XmStringCreate("Run", XmSTRING_DEFAULT_CHARSET);
      XtSetArg(args[0], XmNlabelString, newLabel);
      XtSetValues(Runbut, args, 1);
      XmStringFree(newLabel);
      }
   CheckXEvents();
*/
	extern HWND hControlPanel;
	SendMessage(hControlPanel, WM_COMMAND, PAUSE_COMMAND, 0);
}



/**************************************************************/
/* PolkaSpeed -- Programmatically set the animation speed.    */
/*	It's an int between 0 (slow) and 100 (fast).	      */
/* RETURNS:  None.					      */
/**************************************************************/
void
PolkaSpeed(int spd)
{
   // Receives 0 (slowest) -> 100 (fastest) so we need to invert since
   //    we do delays.
/*
   XmScrollBarSetValues(Speedbar, 100-spd, SLIDERSIZE, 1, 10, True);
   _delay = 2000 * (100-spd);
*/
	extern HWND hControlPanel;
	SendMessage(hControlPanel, WM_HSCROLL, (spd << 16)|SB_THUMBPOSITION, 0);
}



/**************************************************************/
/* controlPanel - Generates widget tree for Polka control     */
/*	panel (run/pause, step, speed control, quit).	      */
/*							      */
/* RETURNS:  None.					      */
/**************************************************************/

void
controlPanel()
{
	_createControlPanel = 1;
}



/**************************************************************/
/* CheckXEvents -- Handle all pending X events.	Also does     */
/*	"smarts" for pausing and stepping.		      */
/*                                                            */
/* RETURNS:  None.					      */
/**************************************************************/

void
CheckXEvents()
{
   MSG  msg;
   BOOL result;

   if( _controlsOn ) {
	   while( (result = PeekMessage (&msg, NULL, 0, 0, PM_REMOVE)) ||
		      (_paused && !_stepjusthit) ) {
		   if( result ) {
			   TranslateMessage (&msg) ;
		       DispatchMessage (&msg) ;
		   }
	   }
       _stepjusthit = 0;
   } else {  // controls have been disabled
	   while( PeekMessage (&msg, NULL, 0, 0, PM_REMOVE) ) {
	       TranslateMessage (&msg) ;
		   DispatchMessage (&msg) ;
	   }
   }
}


/**************************************************************/
/* BatchMode - FLush out X graphics.                          */
/*							      */
/* RETURNS:  None.					      */
/**************************************************************/
void
BatchMode(int fg)
{
   static int batch_level = 0;

   if (fg)
      ++batch_level;
   else if (batch_level > 0) {
      --batch_level;
      if (batch_level == 0) {
	  }
   }
}




/***************************************************************/
/* micro_sleep - used to busy wait and slow down the animation.*/
/*	   This is the most machine specific code in the       */
/*         package and may not compile/work on your machine.   */
/*							       */
/* RETURNS:  None.					       */
/***************************************************************/

void 
micro_sleep(int usec)
{
	Sleep(usec);
}


/***************************************************************/
/* speedCB -- Adjust the delay setting according               */
/*	       to the scrollbar position.		       */
/*							       */
/* RETURNS:  None.					       */
/***************************************************************/

void
speedCB(void *param)  /* param is 0.0 - 1.0 */
{
   _delay = (int)(100.0 * (1.0 - *((float *)param)));
}



/**************************************************************/
/* pauseCB -- Pause/unpause animation and change	      */
/*		     button label to reflect current state.   */
/*							      */
/* RETURNS:  None.					      */
/**************************************************************/
void
pauseCB(void *param)
{
   if (_paused) {
      _paused = 0;
      }
   else
      _paused = 1;
}



/**************************************************************/
/* stepCB -- Step one animation frame			      */
/*							      */
/* RETURNS:  None.					      */
/**************************************************************/

void
stepCB(void *param) {
   if( !_paused ) {
      _paused = 1;
   }

   _stepjusthit = 1;
}



/**************************************************************/
/* quitCB - shut everything down			      */
/*							      */
/* RETURNS:  None.					      */
/**************************************************************/

void
quitCB(void *param)
{
   exit(0);
}











/*---------------------------------------------------------------------------*/
/*                              POLKA Widgets                                */
/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                             topshell                                      */
/*                                |                                          */
/*                               form                                        */
/*                       /--------+-----------------------\------------\     */
/*                     easel                          botform                */
/*                                                       |                   */
/*                            /--------------------------+-----\             */
/*                        botleftrowcol                    botrightrowcol    */
/*                           |                                 |             */
/*   /-----+----+----+-----+-----\	      /----------+-----+---\         */
/* lbut  rbut  dbut ubut inbut  outbut	   debugbut  refreshbut closebut     */
/*	                                                		     */
/*	                                            		 	     */
/*---------------------------------------------------------------------------*/

/**************************************************************/
/* setupWindow -- Create, init (hardcoded), place, &          */
/*		  realize all widgets for animation windows.  */
/*							      */
/* RETURNS:  None.					      */
/**************************************************************/

void
View::setupWindow(const char *title) {
	// create an animation window with
	// the drawing area and lotsa buttons
	RECT rcView;
	rcView = viewWndDefRect;

	if( pixX && pixY ) {
		rcView.right = pixX;
		rcView.bottom = pixY;
	}

	topshell = new ViewWindow( title,
		                       WS_OVERLAPPEDWINDOW,
							   &rcView,
							   NULL,
							   hApp,
							   this );
	// show the newly created
	// animation window
	topshell->ShowWindow( iAppCmdShow );
    topshell->UpdateWindow();
	easel = ((ViewWindow *)topshell)->getDrawingArea();
}


/**************************************************************/
/* refreshCB -- (callback function) Redraw all images         */
/*           onscreen.                                        */
/*							      */
/* RETURNS:  None.					      */
/**************************************************************/
void
refreshCB( Widget w )
{
	View *t = ((ViewWindow *)w)->getView();
    if (t->DrawWindow()) {
       t->Refresh();
	}
}



/**************************************************************/
/* closeCB -- close this view				      */
/*							      */
/* RETURNS:  None.					      */
/**************************************************************/
void
closeCB( void *param )
{
   View *v = ((ViewWindow *)param)->getView();
   v->UnMap();
}



/**************************************************************/
/* resizeEH -- Resize widgets.				      */
/*							      */
/* RETURNS:  None.					      */
/**************************************************************/
void
resizeEH( Widget w ) {
	View *t = ((ViewWindow *)w)->getView();

	if( t->DrawWindow() ) {
        t->prepareAnim( XtWindow(t->easel) );
        t->fixPad();
        t->Refresh();
	}
}



/**************************************************************/
/* changeDebug_callback -- Change debug mode.    	      */
/*			   				      */
/*							      */
/* RETURNS:  None.					      */
/**************************************************************/
void
debugCB( Widget w )
{

   View *v = ((ViewWindow *)w)->getView();
   int d;

   d = v->GetDebug();
   v->SetDebug( d ? 0 : 1);
}





/**************************************************************/
/* panning and zooming callbacks.		    	      */
/*							      */
/* RETURNS:  None.					      */
/**************************************************************/

void
panlCB( Widget w )
{
	View *v = ((ViewWindow *)w)->getView();
    double lx,by,rx,ty,change,panfactor = 0.2;

    v->GetCoord(lx,by,rx,ty);
    change = (rx-lx) * panfactor;
    v->SetCoord(lx-change, by, rx-change, ty);
}


void
panrCB( Widget w )
{
   View *v = ((ViewWindow *)w)->getView();
   double lx,by,rx,ty,change,panfactor = 0.2;

   v->GetCoord(lx,by,rx,ty);
   change = (rx-lx) * panfactor;
   v->SetCoord(lx+change, by, rx+change, ty);
}


void
pandCB( Widget w )
{
   View *v = ((ViewWindow *)w)->getView();
   double lx,by,rx,ty,change,panfactor = 0.2;

   v->GetCoord(lx,by,rx,ty);
   change = (ty-by) * panfactor;
   v->SetCoord(lx, by-change, rx, ty-change);
}


void
panuCB( Widget w )
{
   View *v = ((ViewWindow *)w)->getView();
   double lx,by,rx,ty,change,panfactor = 0.2;

   v->GetCoord(lx,by,rx,ty);
   change = (ty-by) * panfactor;
   v->SetCoord(lx, by+change, rx, ty+change);
}



void
zoominCB( Widget w )
{
   View *v = ((ViewWindow *)w)->getView();
   double lx,by,rx,ty,changex,changey,zoomfactor = 0.8;

   v->GetCoord(lx,by,rx,ty);
   changey = ((ty-by) * (1.0-zoomfactor)) / 2.0;
   changex = ((rx-lx) * (1.0-zoomfactor)) / 2.0;
   v->SetCoord(lx+changex, by+changey, rx-changex, ty-changey);
}




void
zoomoutCB( Widget w )
{
   View *v = ((ViewWindow *)w)->getView();
   double lx,by,rx,ty,changex,changey,zoomfactor = 0.8;

   v->GetCoord(lx,by,rx,ty);
   changey = ((ty-by) * (1.0/zoomfactor -1.0)) / 2.0;
   changex = ((rx-lx) * (1.0/zoomfactor -1.0)) / 2.0;
   v->SetCoord(lx-changex, by-changey, rx+changex, ty+changey);
}





/**** Window managers don't seem to let me do this **************/
/*
void 
View::SetDimension(int wid, int hei)
{ 
   Arg          wargs[3];
   Dimension    bw;

   if ((wid<=0) || (hei<=0))
      return;

   if (window) { // Avoid resize when widget initially displayed 
                 // -- *before* offscreen pixmap has been created
      XFreePixmap(_display, window);

      XtSetArg(wargs[0], XtNwidth, wid);
      XtSetArg(wargs[1], XtNheight, hei);
      XtSetValues(easel, wargs, 2);

      XFlush(_display);
      window = XCreatePixmap(_display, DefaultRootWindow(_display), 
                             (unsigned int)wid, (unsigned int)hei,
                             DefaultDepth(_display, DefaultScreen(_display)));
      fixPad();
      Refresh();
      }

   pixX = wid;
   pixY = hei;
}
*/








/*---------------------------------------------------------------------------*/
/*                              POLKA Widgets                                */
/*                                StaticView                                 */
/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                             topshell                                      */
/*                                |                                          */
/*                               form                                        */
/*                       /--------+-----------------------\------------\     */
/*                     easel                          botform                */
/*                                                       |                   */
/*                            /--------------------------+-----\             */
/*                        botleftrowcol                    botrightrowcol    */
/*                           |                                 |             */
/*   /-----+----+----+-----+-----\	      /----------+-----+---\         */
/* lbut  rbut  dbut ubut inbut  outbut	   debugbut  refreshbut closebut     */
/*	                                                		     */
/*	                                            		 	     */
/*---------------------------------------------------------------------------*/

/**************************************************************/
/* setupStaticWindow -- Create, init (hardcoded), place, &    */
/*		  realize all widgets for animation windows.  */
/*							      */
/* RETURNS:  None.					      */
/**************************************************************/
void
StaticView::setupStaticWindow(const char *title)
{
}





/**************************************************************/
/* staticrefreshCB -- (callback function) Redraw all images   */
/*           onscreen.                                        */
/*							      */
/* RETURNS:  None.					      */
/**************************************************************/
void
staticrefreshCB(/*Widget, XtPointer thisone, XtPointer xtp*/)
{
//   StaticView *t = (StaticView *)thisone;
//
//                  // Avoid refresh when widget initially displayed 
//                  // -- *before* offscreen pixmap has been created
//   if (t->DrawWindow()) {
//      t->Refresh();
//      }
}



/**************************************************************/
/* staticrefreshEH -- (event handler) Redraw all images       */
/*           onscreen.                                        */
/*							      */
/* RETURNS:  None.					      */
/**************************************************************/
void
staticrefreshEH(/*Widget, XtPointer thisone, XEvent *xev, Boolean **/)
{
//   XExposeEvent *expev;
//   StaticView *t = (StaticView *)thisone;
//
//                  // Avoid refresh when widget initially displayed 
//                  // -- *before* offscreen pixmap has been created
//   if (t->DrawWindow()) {
//      expev = (XExposeEvent *)xev;
//      if (expev->count == 0)  
//      t->Refresh();
//      }
}



/**************************************************************/
/* closeCB -- close this view				      */
/*							      */
/* RETURNS:  None.					      */
/**************************************************************/
void
staticcloseCB(/*Widget, XtPointer p, XtPointer*/)
{
//   StaticView *v = (StaticView *)p;
//   v->UnMap();
}



/**************************************************************/
/* resize -- Resize widgets.				      */
/*							      */
/* RETURNS:  None.					      */
/**************************************************************/
void
staticresizeEH(/*Widget w, XtPointer thisone, XEvent *, Boolean **/)
{
//   StaticView *t = (StaticView *)thisone;
//
//                  // Avoid resize when widget initially displayed 
//                  // -- *before* offscreen pixmap has been created
//   if (t->DrawWindow()) { 
//      t->prepareAnim(XtWindow(w));
//      t->Refresh();
//      }
}



/**************************************************************/
/* changeDebug_callback -- Change debug mode.    	      */
/*			   				      */
/*							      */
/* RETURNS:  None.					      */
/**************************************************************/
void
staticdebugCB(/*Widget, XtPointer client_data, XtPointer*/)
{
//   StaticView *v;
//   int d;
//
//   v = (StaticView *)client_data;
//   d = v->GetDebug();
//   v->SetDebug( d ? 0 : 1);
}