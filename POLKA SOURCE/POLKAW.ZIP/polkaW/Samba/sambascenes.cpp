// Sambascenes.cpp
//************************************************************************
// This is the scenes file for the POLKA animator. This file contains all*
// of the animation scenes for each of the animator commands. Each scene *
// is invoked from the corresponding Interpreter member function.        *
//************************************************************************

//#include <stream.h>
//#include <strings.h>
#include <iostream.h>
#include <string.h>
#include "polka.H"
#include "samba.H"


//************************************************************************
// Pull in all of the global variables.                                  *
//************************************************************************
extern int number_of_views;
extern VTable ViewTable;
extern char sambaView[SLEN];
extern int number_of_views;
extern AVrecs activeviews[24];

//***********************************************************************
// Begin the scenes.                                                    *
//***********************************************************************
int 
InterpAnimView::bgScene(char *thecolor)
{

  InterpAnimView *activeView;

  activeView = ViewTable.Retrieverecord(sambaView);
  
  activeView->SetBgColor(thecolor);
  return 1;
}


int 
InterpAnimView::coordsScene(double nlx, double nby, double nrx, double nty)
{
  InterpAnimView *activeView;

  activeView = ViewTable.Retrieverecord(sambaView);

  activeView->SetCoord(nlx, nby, nrx, nty);
  return 0;
}

int 
InterpAnimView::delayScene(int frames)
{
  return frames;
}

int
InterpAnimView::lineScene(char ident[], double plx, double ply, double sx, 
			  double sy, double widthval, char *color)
{
  char *ptr;
  AnimObject *line;
  InterpAnimView *activeView;

  activeView = ViewTable.Retrieverecord(sambaView);
  
  line = new Line(activeView, 1, plx, ply, sx, sy, color, 
		       widthval);

  line->Originate(time);

  ptr = "line";

  line->StoreData(ptr);

  // Add the new object to the hash table. 
  VItems.Addrecord(ident, line);

  return 1;
    
}

int
InterpAnimView::arrowScene(char ident[], double plx, double ply, double sx, 
			  double sy, double widthval, char *color)
{
  char *ptr;
  AnimObject *arrow;
  InterpAnimView *activeView;

  activeView = ViewTable.Retrieverecord(sambaView);
  
  arrow = new Line(activeView, 1, plx, ply, sx, sy, color, 
		       widthval, 1.0, 1);

  arrow->Originate(time);

  ptr = "line";

  arrow->StoreData(ptr);

  // Add the new object to the hash table. 
  VItems.Addrecord(ident, arrow);

  return 1;
    
}

int
InterpAnimView::rectangleScene(char ident[], double rlx, double rly, double sx, 
			       double sy, double fillval, char *color)
{
  char *ptr;
  AnimObject *rect;
  InterpAnimView *activeView;

  activeView = ViewTable.Retrieverecord(sambaView);
  
  rect = new Rectangle(activeView, 1, rlx, rly, sx, sy, color, 
			    fillval);
  rect->Originate(time);

  ptr = "rect";

  rect->StoreData(ptr);

  // Add the new object to the hash table. 
  VItems.Addrecord(ident, rect);

  return 1;
}

int 
InterpAnimView::circleScene(char ident[], double clx, double cly, double radius, 
			double fillval, char *color)
{
  char *ptr;
  AnimObject *circle;
  InterpAnimView *activeView;

  activeView = ViewTable.Retrieverecord(sambaView);


  circle = new Circle(activeView, 1, clx, cly, radius, color,
			 fillval);

  circle->Originate(time);

  ptr = "circ";

  circle->StoreData(ptr);

  // Add the new object to the hash table. 
  VItems.Addrecord(ident, circle);
  
  return 1;
}

int
InterpAnimView::triangleScene(char ident[], double tlx, double tly, double vx0, 
			      double vy0, double vx1, double vy1, 
			      char *color, double fillval)
{
  double vx[2], vy[2];
  char *ptr;
  AnimObject *triangle;
  InterpAnimView *activeView;

  activeView = ViewTable.Retrieverecord(sambaView);

  vx[0] = vx0;
  vx[1] = vx1;
  vy[0] = vy0;
  vy[1] = vy1;


  triangle = new Polygon(activeView, 1, tlx, tly, 3, vx, vy, color, 
			  fillval);

  triangle->Originate(time);

  ptr = "tria";

  triangle->StoreData(ptr);

  // Add the new object to the hash table. 
  VItems.Addrecord(ident, triangle);

  return 1;
}


int
InterpAnimView::polygonScene(char ident[], double plx, double ply, int numsides, 
			     double vx[7], double vy[7], char *color, 
			     double fillval)
{
  char *ptr;
  AnimObject *polygon;
  InterpAnimView *activeView;

  activeView = ViewTable.Retrieverecord(sambaView);
  
  polygon = new Polygon(activeView, 1, plx, ply, numsides, vx, vy, 
			  color, fillval);

  polygon->Originate(time);

  ptr = "poly";

  polygon->StoreData(ptr);

  // Add the new object to the hash table. 
  VItems.Addrecord(ident, polygon);  

  return 1;
}

int 
InterpAnimView::textScene(char ident[], double tlx, double tly, char *color, 
		      char *str, int cen)
{
  char *ptr;
  AnimObject *text;
  InterpAnimView *activeView;

  activeView = ViewTable.Retrieverecord(sambaView);
  

  text = new Text(activeView, 1, tlx, tly, color, "variable", str,
		       cen);
  text->Originate(time);

  if (cen)
    ptr = "ctxt";
  else
    ptr = "ltxt";

  text->StoreData(ptr);

  // Add the new object to the hash table. 
  VItems.Addrecord(ident, text);  

  return 1;
}

int 
InterpAnimView::bigtextScene(char ident[], double tlx, double tly, char *color, 
			     char *str, int cen)
{
  char *ptr;
  AnimObject *bigtext;
  InterpAnimView *activeView;

  activeView = ViewTable.Retrieverecord(sambaView);

  bigtext = new Text(activeView, 1, tlx, tly, color, "12x24", 
		     str, cen);
  bigtext->Originate(time);

  if (cen)
    ptr = "ctxt";
  else
    ptr = "ltxt";

  bigtext->StoreData(ptr);

  // Add the new object to the hash table. 
  VItems.Addrecord(ident, bigtext);  

  return 1;
  
}

int
InterpAnimView::flextextScene(char ident[], double tlx, double tly, char *color, 
			  char *fname, char *str, int cen)
{
  char *ptr;
  AnimObject *flextext;
  InterpAnimView *activeView;

  activeView = ViewTable.Retrieverecord(sambaView);
  

  flextext = new Text(activeView, 1, tlx, tly, color, fname, str, cen);
  flextext->Originate(time);

  if (cen)
    ptr = "ctxt";
  else
    ptr = "ltxt";

  flextext->StoreData(ptr);

  // Add the new object to the hash table. 
  VItems.Addrecord(ident, flextext);  

  return 1;
}


int
InterpAnimView::setScene(char ident[], int numAO, char targetids[SLEN][SLEN])
{
  int count;
  AnimObject *objs[512];
  AnimObject *set, *temp;
  char *ptr;
  InterpAnimView *activeView;

  activeView = ViewTable.Retrieverecord(sambaView);

  for(count=0; count<numAO; count++)
    {
      if (temp=VItems.Retrieverecord(targetids[count])) {
	objs[count] = temp;
      }
      else {
	cerr << "Attempted to add nonexistent object to set.  (Ignoring)." 
	     << endl;
	numAO--;
      }
    }

  set = new Set(activeView, numAO, objs);
  set->Originate(time);

  ptr = "set";
  
  set->StoreData(ptr);

  // Add the new object to the hash table. 
  VItems.Addrecord(ident, set);  


  return 1;
}


int 
InterpAnimView::deleteScene(char ident[])
{
  AnimObject *AO;

  if (AO = VItems.Retrieverecord(ident)) {
    AO->Delete(time);
    // Register the timer callback right here... 
    RegisterTimerCallback(time+1, deltimerCB, AO);
    
    VItems.Removerecord(ident);
    return 2;
  }
  else {
    cerr << "Warning:  Tried to DELETE nonexistant id. (Ignoring)" << endl;
    return 0;
  }
}

int 
InterpAnimView::moveScene(char ident[], double tox, double toy)
{
  Loc *original, *dest;
  int len;
  char *whatisit;
  AnimObject *AO;

  if (AO = VItems.Retrieverecord(ident)) {

    whatisit = (char *)AO->RetrieveData();

    if ((!strcmp(whatisit, "rect")) || (!strcmp(whatisit, "ltxt")))
      original = AO->Where(PART_SW);
    else
      original = AO->Where(PART_C);
  
    dest = new Loc(tox, toy);
      
    Action Movem("MOVE", original, dest, STRAIGHT);

    len = AO->Program(time, &Movem);
  
    return len;
  }
  else {
    cerr << "Warning:  Tried to MOVE nonexistant id.  (Ignoring)" << endl;
    return 0;
  }
}

int 
InterpAnimView::moverelativeScene(char ident[], double tox, double toy)
{
  Loc *original, *dest;
  int len;
  char *whatisit;
  AnimObject *AO;

  if (AO = VItems.Retrieverecord(ident))  {
      whatisit = (char *)AO->RetrieveData();

      if ((!strcmp(whatisit, "rect")) || (!strcmp(whatisit, "ltxt")))
	original = AO->Where(PART_SW);
      else
	original = AO->Where(PART_C);

      dest = new Loc(original->XCoord() + tox, original->YCoord() + toy);

      Action Movem("MOVE", original, dest, STRAIGHT);

      len = AO->Program(time, &Movem);

      return len;
  }
  else {
      cerr << "Warning:  Tried to MOVERELATIVE nonexistant id.  (Ignoring)" 
	<< endl;
      return 0;
  }
}

int 
InterpAnimView::movetoScene(char ident1[], char ident2[])
{
  Loc *original, *dest;
  int len;
  char *whatisit1, *whatisit2;
  AnimObject *AO1, *AO2;


  if ((AO1 = VItems.Retrieverecord(ident1)) && 
      (AO2 = VItems.Retrieverecord(ident2)))  {
      whatisit1 = (char *)AO1->RetrieveData();
      
      if ((!strcmp(whatisit1, "rect")) || (!strcmp(whatisit1, "ltxt")))
	original = AO1->Where(PART_SW);
      else
	original = AO1->Where(PART_C);
      
      whatisit2 = (char *)AO2->RetrieveData();
      
      if ((!strcmp(whatisit2, "rect")) || (!strcmp(whatisit2, "ltxt")))
	dest = AO2->Where(PART_SW);
      else
	dest = AO2->Where(PART_C);

      Action Movem("MOVE", original, dest, STRAIGHT);

      len = AO1->Program(time, &Movem);
      
      return len;
  }
  else  {
      cerr << "Warning:  Tried to MOVETO nonexistant id.  (Ignoring)" << endl;
      return 0;
  }
}

int 
InterpAnimView::jumpScene(char ident[], double jlx, double jly)
{
  Loc *original, *dest;
  int len;
  char *whatisit;
  AnimObject *AO;

  if (AO = VItems.Retrieverecord(ident))  {
      whatisit = (char *)AO->RetrieveData();

      if ((!strcmp(whatisit, "rect")) || (!strcmp(whatisit, "ltxt")))
	original = AO->Where(PART_SW);
      else
	original = AO->Where(PART_C);
      
      dest = new Loc(jlx, jly);

      Action Movem("MOVE", original, dest, 1);

      len = AO->Program(time, &Movem);

      return len;
  }
  else  {
      cerr << "Warning:  Tried to JUMP nonexistant id.  (Ignoring)" << endl;
      return 0;
  }
}


int 
InterpAnimView::jumprelativeScene(char ident[], double jtx, double jty)
{
  Loc *original, *dest;
  int len;
  char *whatisit;
  AnimObject *AO;

  if (AO = VItems.Retrieverecord(ident))  {
      whatisit = (char *)AO->RetrieveData();

      if ((!strcmp(whatisit, "rect")) || (!strcmp(whatisit, "ltxt")))
	original = AO->Where(PART_SW);
      else
	original = AO->Where(PART_C);


      dest = new Loc(original->XCoord() + jtx, original->YCoord() + jty);

      Action Movem("MOVE", original, dest, 1);

      len = AO->Program(time, &Movem);

      return len;
  }
  else  {
      cerr << "Warning:  Tried to JUMPRELATIVE nonexistant id.  (Ignoring)" 
	<< endl;
      return 0;
  }

}

int
InterpAnimView::jumptoScene(char ident1[], char ident2[])
{
  Loc *original, *dest;
  int len;
  char *whatisit1, *whatisit2;
  AnimObject *AO1, *AO2;

  if ((AO1=VItems.Retrieverecord(ident1)) && 
      (AO2=VItems.Retrieverecord(ident2)))  {
      whatisit1 = (char *)AO1->RetrieveData();

      if ((!strcmp(whatisit1, "rect")) || (!strcmp(whatisit1, "ltxt")))
	original = AO1->Where(PART_SW);
      else
	original = AO1->Where(PART_C);

      whatisit2 = (char *)AO2->RetrieveData();
      
      if ((!strcmp(whatisit2, "rect")) || (!strcmp(whatisit2, "ltxt")))
	dest = AO2->Where(PART_SW);
      else
	dest = AO2->Where(PART_C);

      Action Movem("MOVE", original, dest, 1);

      len = AO1->Program(time, &Movem);

      return len;
  }
  else  {
      cerr << "Warning:  Tried to JUMPTO nonexistant id.  (Ignoring)" << endl;
      return 0;
  }
}

int
InterpAnimView::colorScene(char ident[], char *colorname)
{
  int len;
  AnimObject *AO;

  if (AO=VItems.Retrieverecord(ident))  {
      Action Changeit("COLOR", colorname);

      len =  AO->Program(time, &Changeit);
  
      return len;
  }
  else  {
      cerr << "Warning:  Tried to change COLOR for nonexistant id.  (Ignoring)"
	<< endl;
      return 0;
  }

}

int
InterpAnimView::alterScene(char ident[], char *newstring)
{
  int len;
  AnimObject *AO;

  if (AO=VItems.Retrieverecord(ident))  {
      Action Changeit("ALTER", newstring);

      len =  AO->Program(time, &Changeit);
  
      return len;
  }
  else  {
      cerr << "Warning:  Tried to ALTER string for nonexistant id.  (Ignoring)"
	<< endl;
      return 0;
  }

}

int
InterpAnimView::fillScene(char ident[], double fillval)
{
  int len;
  AnimObject *AO;
  double x=0.0, currfill, newfill;
  char *whatisit;

  if (AO=VItems.Retrieverecord(ident))  {
    // Put in the code to extract the fill values for offset calculation.
    whatisit = (char *)AO->RetrieveData();

    if ((!strcmp(whatisit, "rect"))) {
      ((Rectangle *)AO)->GetValues(NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
				   &currfill);
    }
    else  if ((!strcmp(whatisit, "circ"))) {
      ((Circle *)AO)->GetValues(NULL, NULL, NULL, NULL, NULL, NULL, &currfill);
    }
    else if ((!strcmp(whatisit, "tria"))) {
      ((Polygon *)AO)->GetValues(NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
				 NULL, &currfill);
    }      
    else if ((!strcmp(whatisit, "poly"))) {
      ((Polygon *)AO)->GetValues(NULL, NULL, NULL, NULL, NULL, NULL, NULL,
				 NULL, &currfill);
    }
    else {   // some kind of object not affected
      return(0);
    }

    newfill = fillval - currfill;
      
    Action Changeit("FILL", 1, &newfill, &x); 
    len = AO->Program(time, &Changeit);
    
    return len;
  }
  else  {
      cerr << "Warning:  Tried to change FILL for nonexistant id.  (Ignoring)" 
	<< endl;
      return 0;
  }
}

int 
InterpAnimView::visScene(char ident[])
{
  int len;
  AnimObject *AO;

  if (AO=VItems.Retrieverecord(ident))  {
      Action Changeit("VIS",1);

      len = AO->Program(time, &Changeit);

      return len;
  }
  else  {
      cerr << "Warning:  Tried to change VIS for nonexistant id.  (Ignoring)" 
	<< endl;
      return 0;
  }
}

int 
InterpAnimView::raiseScene(char ident[])
{
  int len;
  AnimObject *AO;

  if (AO = VItems.Retrieverecord(ident)) {
    Action Changeit("RAISE", 1);
    len = AO->Program(time, &Changeit);
    return len;
  }
  else {
    cerr << "Warning:  Tried to RAISE a nonexistant id  (Ignoring)" << endl;
    return 0;
  }
    
}

int 
InterpAnimView::lowerScene(char ident[])
{
  int len;
  AnimObject *AO;

  if (AO=VItems.Retrieverecord(ident))  {
      Action Changeit("LOWER", 1);

      len = AO->Program(time, &Changeit);

      return len;
  }
  else  {
      cerr << "Warning:  Tried to LOWER nonexistant id.  (Ignoring)" << endl;
      return 0;
  }

}

int 
InterpAnimView::exchangeposScene(char ident1[], char ident2[])
{

  Loc *item1, *item2;
  int len;
  char *whatisit1, *whatisit2;
  AnimObject *AO1, *AO2;

  if ((AO1=VItems.Retrieverecord(ident1)) && 
      (AO2=VItems.Retrieverecord(ident2)))  {
      whatisit1 = (char *)AO1->RetrieveData();

      if ((!strcmp(whatisit1, "rect")) || (!strcmp(whatisit1, "ltxt")))
	item1 = AO1->Where(PART_SW);
      else
	item1 = AO1->Where(PART_C);

      whatisit2 = (char *)AO2->RetrieveData();
      
      if ((!strcmp(whatisit2, "rect")) || (!strcmp(whatisit2, "ltxt")))
	item2 = AO2->Where(PART_SW);
      else
	item2 = AO2->Where(PART_C);

      Action Move1("MOVE", item1, item2, STRAIGHT);

      Action Move2("MOVE", item2, item1, STRAIGHT);

      AO1->Program(time, &Move1);
      len = AO2->Program(time, &Move2);
      
      return len;
  }
  else  {
      cerr << "Warning:  Tried to EXCHANGE nonexistant id.  (Ignoring)" 
	<< endl;
      return 0;
  }

}

int 
InterpAnimView::switchposScene(char ident1[],char ident2[])
{

  Loc *item1, *item2;
  int len;
  char *whatisit1, *whatisit2;
  AnimObject *AO1, *AO2;


  if ((AO1=VItems.Retrieverecord(ident1)) 
      && (AO2=VItems.Retrieverecord(ident2)))  {
      whatisit1 = (char *)AO1->RetrieveData();

      if ((!strcmp(whatisit1, "rect")) || (!strcmp(whatisit1, "ltxt")))
	item1 = AO1->Where(PART_SW);
      else
	item1 = AO1->Where(PART_C);

      whatisit2 = (char *)AO2->RetrieveData();

      if ((!strcmp(whatisit2, "rect")) || (!strcmp(whatisit2, "ltxt")))
	item2 = AO2->Where(PART_SW);
      else
	item2 = AO2->Where(PART_C);

      Action Move1("MOVE", item1, item2, 1);

      Action Move2("MOVE", item2, item1, 1);

      AO1->Program(time, &Move1);
      len = AO2->Program(time, &Move2);

      return len;
  }
  else  {
      cerr << "Warning:  Tried to SWITCHPOS nonexistant id.  (Ignoring)" 
	<< endl;
      return 0;
  }
}  

int 
InterpAnimView::swapidScene(char ident1[], char ident2[])
{
  RECORD_PTR rec1, rec2;
  AnimObject *r1, *r2;

  if ((rec1=VItems.record_exists(ident1)) && 
      (rec2=VItems.record_exists(ident2)))  {

    r1 = rec1->record;
    r2 = rec2->record;

    VItems.Removerecord(ident1);
    VItems.Removerecord(ident2);

    VItems.Addrecord(ident1, r2);
    VItems.Addrecord(ident2, r1);

    return 0;
  }
  else  {
      cerr << "Warning:  Tried to SWAPID nonexistant id.  (Ignoring)" << endl;
      return 0;
  }
}


int
InterpAnimView::changelinewidthScene(char ident[], double width)
{
  double x=0.0, oldwidthval, widthval;
  int len;
  AnimObject *AO;


  if (AO=VItems.Retrieverecord(ident))  {
    ((Line *)AO)->GetValues(NULL, NULL, NULL, NULL, NULL, NULL,
    			    NULL, &oldwidthval, NULL, NULL);
    // Calculate the delta for the width from old to new.
    widthval = width - oldwidthval;

    Action Changeit("FILL", 1, &widthval, &x);

    len = AO->Program(time, &Changeit);
    
    return len;
  }
  else  {
    cerr << "Warning:  Tried to change WIDTH for nonexistant id.  (Ignoring)" 
	 << endl;
    return 0;
  }
}

void
InterpAnimView::addtime(int amount)
{
  time += amount;
} 

int 
InterpAnimView::reporttime()
{
  return time;
}

void 
deltimerCB(View *v, int frametime, void *data)
{
  // This routine reclaims the storage of an AnimObject after a 'delete'
  // command. The callback ensures that the storage will not be reclaimed
  // until after the delete command has been animated. 

  AnimObject *AO;

  AO = (AnimObject *)data;
  
  delete AO;
}
