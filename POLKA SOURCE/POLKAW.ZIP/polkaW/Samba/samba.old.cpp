//  Samba.C  
//  7/24/95
//  8/07/95
//  
// This is the animator for the POLKA animation system. The program takes
// input from stdin, usually in the form of an ascii text program trace. 
// The animator will respond to the animator commands by producing a 
// corresponding animation event. 


#include <string.h>
#include <iostream.h>
// added
#include <fstream.h>
// end added
//#include <strings.h>
//#include <stream.h>
#include <stdlib.h>
#include "polka.H"
#include "samba.H"

double getFill(char *);
double getWidth(char *);

int parseText(char *);
int parseFlexText(char *);
int parseAlter(char *);
char *nextString(char*, char*);

//*************************************************************** 
// Global Variables                                             *
//*************************************************************** 

VTable ViewTable;     // View hash table to store all available views. 
struct AVrecs activeviews[24]; // List of active view pointers.
int number_of_views;  // The number of active views.
char sambaView[SLEN]; // Holds the name of the current active view.
int debugon=1;        // Are debugging messages on or off? 

// *************************************************************** 
//  Control Panel callback status variables.                     *  
// *************************************************************** 
int started = 0;   // Has the Start button been pressed?
int paused = 1;    // Has the pause button been hit? Starts out paused.
int stepjusthit = 0; // Was Step just hit?
int viewdeffound = 0; // A viewdef line was found...process all of them.


int
Interpreter::parseLine(char *str)
{
  // This routine reads each line of the input commands, and 
  // responds accordingly.
  char cmd[50];
  int length;


  if (sscanf(str, "%s", cmd) <= 0)
    return 0;

  if(str[0] == '%')
    return 0;

  if (!strcmp(cmd, "view"))
    length = view(str);
  
  else if (!strcmp(cmd, "viewdef"))
    length = createview(str);

  else if (!strcmp(cmd, "{"))
    length = set_concurrent();
  
  else if (!strcmp(cmd, "}"))
    length = set_sequential();

  else if (!strcmp(cmd, "line"))
    length = line(str);

  else if (!strcmp(cmd, "pointline"))
    length = pointline(str);

  else if (!strcmp(cmd, "rectangle"))
    length = rectangle(str);

  else if (!strcmp(cmd, "circle"))
    length = circle(str);

  else if (!strcmp(cmd, "triangle"))
    length = triangle(str);

  else if (!strcmp(cmd, "polygon"))
    length = polygon(str);
 
  else if (!strcmp(cmd, "text"))
    length = text(str);
  
  else if (!strcmp(cmd, "bigtext"))
    length = bigtext(str);

  else if (!strcmp(cmd, "flextext"))
    length = flextext(str);

  else if (!strcmp(cmd, "set"))
    length = buildset(str);
 
  else if (!strcmp(cmd, "delete"))
    length = deleteAO(str);
 
  else if (!strcmp(cmd, "move"))
    length = move(str);
  
  else if (!strcmp(cmd, "moverelative"))
    length = moverelative(str);
 
  else if (!strcmp(cmd, "moveto"))
    length = moveto(str);
 
  else if (!strcmp(cmd, "jump"))
    length = jump(str);
 
  else if (!strcmp(cmd, "jumprelative"))
    length = jumprelative(str);
  
  else if (!strcmp(cmd, "jumpto"))
    length = jumpto(str);
 
  else if (!strcmp(cmd, "color"))
    length = color(str);

  else if (!strcmp(cmd, "alter"))
    length = alter(str);

  else if (!strcmp(cmd, "fill"))
    length = fill(str);
 
  else if (!strcmp(cmd, "vis"))
    length = vis(str);
 
  else if (!strcmp(cmd, "raise"))
    length = raise(str);
 
  else if (!strcmp(cmd, "lower"))
    length = lower(str);
 
  else if (!strcmp(cmd, "exchangepos"))
    length = exchangepos(str);
 
  else if (!strcmp(cmd, "switchpos"))
    length = switchpos(str);
 
  else if (!strcmp(cmd, "swapid"))
    length = swapid(str);
 
  else if (!strcmp(cmd, "bg"))
    length = bg(str);
 
  else if (!strcmp(cmd, "coords"))
    length = coords(str);
 
  else if (!strcmp(cmd, "delay"))
    length = delay(str);
  
  else if (!strcmp(cmd, "comment"))
    length = comment(str);

  else if (!strcmp(cmd, "width"))
    length = changelinewidth(str);

  else if (!strcmp(cmd, "quit"))
    exit(0);

  else {
    cerr << "Invalid command ->" << cmd << "<- found, ignoring." << endl;
    length = 0;
  }

  return length;

}
 
int 
Interpreter::view(char *str)
{
  // This routine will change the active view to the argument.
  char cmd[SLEN], ident[SLEN];
  int i, found=0;

  sscanf(str, "%s %s", cmd, ident);

  for(i=0; i<number_of_views; i++)
    {
      if(!strcmp(ident, activeviews[i].name)) {
	found = 1;
      }
    }
  if (found) {
    strcpy(sambaView, ident);
  }
  else {
    cerr << "Invalid view argument ->" << ident << "<- (Ignoring)." 
	 << endl;
  }
  return 0;
}


int
Interpreter::createview(char *str)
{
  // This routine will create a view with the given parameters from
  // the viewdef command, or use the defaults if no parameters given.
  // The view identifier is required, however.
  char cmd[SLEN], ident[SLEN], xsize[SLEN], ysize[SLEN];
  int numargs;
  InterpAnimView *newView;


  viewdeffound = 1;

  numargs = sscanf(str, "%s %s %s %s", cmd, ident, xsize, ysize);

  newView = new InterpAnimView();
  
  if (numargs == 4) {
    newView->Create(ident, CoordStretch, atoi(xsize), atoi(ysize));
  }
  else {
    newView->Create(ident);
  }

  ViewTable.Addrecord(ident, newView);

  strcpy(activeviews[number_of_views].name, ident);
  activeviews[number_of_views].ptr = newView;

  number_of_views++;

  // Make the newly created view the currently active view.
  strcpy(sambaView, ident);

  return 1;
}

int 
Interpreter::isconcurrent()
{
  // Is the Interpreter programming events concurrently?
  return concurrent;
}


int
Interpreter::set_concurrent()
{
  // Set the Interpreter to concurrent event programming.
  concurrent = 1;
  return 0;
}

int
Interpreter::set_sequential()
{
  // Set the Interpreter back to sequential programming mode.
  concurrent = 0;
  return 0;
}

int
Interpreter::bg(char *str)
{
  // Set the background color for a view.
  char cmd[SLEN], thecolor[SLEN];
  int time1;
  InterpAnimView *activeView;

  sscanf(str, "%s %s", cmd, thecolor);

  activeView = ViewTable.Retrieverecord(sambaView);

  time1 = activeView->bgScene(thecolor);
  return time1;

}

int
Interpreter::coords(char *str)
{
  // Set the coordinate system for a view.
  char cmd[SLEN];
  double lx, by, rx, ty;
  int time1;
  InterpAnimView *activeView;

  sscanf(str, "%s %lf %lf %lf %lf", cmd, &lx, &by, &rx, &ty);

  activeView = ViewTable.Retrieverecord(sambaView);
  
  if ((lx >= rx) || (by >= ty)) {
    cerr << "Invalid coords (" << lx << "," << by << ") (" << rx << "," 
      << ty << ") passed to coords command (Ignoring)" << endl;
    return 0;
  }

  time1 = activeView->coordsScene(lx, by, rx, ty);
  return time1;

}


int
Interpreter::delay(char *str)
{
  // Put a delay in the animation for as many frames as specified.
  int frames, time1;
  char cmd[SLEN];
  InterpAnimView *activeView;
  
  sscanf(str, "%s %d", cmd, &frames);

  activeView = ViewTable.Retrieverecord(sambaView);
  
  time1 = activeView->delayScene(frames);
  
  return time1;
}


int
Interpreter::line(char *str)
{
  // Draw a line on the view.
  char cmd[SLEN], color[SLEN], width[SLEN], ident[SLEN];
  int time1;
  double lx, ly, sx, sy, widthval;
  InterpAnimView *activeView;


  sscanf(str, "%s %s %lf %lf %lf %lf %s %s", cmd, ident, &lx, &ly, &sx, &sy, 
	 color, width);

  activeView = ViewTable.Retrieverecord(sambaView);

  widthval = getWidth(width);
  if (widthval == -1.0) {
    cerr << "Invalid width argument ->" << width << "<- given to line command."
      << "(Ignoring)" << endl;
    return 0;
  }

  time1 = activeView->lineScene(ident, lx, ly, sx, sy, widthval, color); 
  return time1;
}

int 
Interpreter::pointline(char *str)
{
  // Draw a line on the view. Here, the line is specified by two points, 
  // rather than one point and two sizes. 
  char cmd[SLEN], color[SLEN], width[SLEN], ident[SLEN];
  int time1;
  double lx, ly, sx, sy, widthval;
  InterpAnimView *activeView;


  sscanf(str, "%s %s %lf %lf %lf %lf %s %s", cmd, ident, &lx, &ly, &sx, &sy, 
	 color, width);

  activeView = ViewTable.Retrieverecord(sambaView);

  widthval = getWidth(width);
  if (widthval == -1.0) {
    cerr << "Invalid width argument ->" << width << "<- given to line command."
      << "(Ignoring)" << endl;
    return 0;
  }

  time1 = activeView->lineScene(ident, lx, ly, (sx-lx), (sy-ly), 
				widthval, color); 
  return time1;

}


int
Interpreter::rectangle(char *str)
{
  // Draw a rectangle on the view.
  char cmd[SLEN], color[SLEN], fill[SLEN], ident[SLEN];
  int time1;
  double lx, ly, sx, sy, fillval;
  InterpAnimView *activeView;

  sscanf(str, "%s %s %lf %lf %lf %lf %s %s", cmd, ident, &lx, &ly, &sx, &sy, 
	 color, fill);


  activeView = ViewTable.Retrieverecord(sambaView);
    
  fillval = getFill(fill);

  if (fillval == -1.0) {
    cerr << "Invalid fill argument ->" << fill << "<- given to rectangle "
      << "command. (Ignoring)" << endl;
    return 0;
  }
  time1 = activeView->rectangleScene(ident, lx, ly, sx, sy, fillval, 
					     color);
					       
  return time1;
}
  

int
Interpreter::circle(char *str)
{
  // Draw a circle on the view.
  char cmd[SLEN], color[SLEN], fill[SLEN], ident[SLEN];
  int time1;
  double lx, ly, rad, fillval;
  InterpAnimView *activeView;

  sscanf(str, "%s %s %lf %lf %lf %s %s", cmd, ident, &lx, &ly, &rad, color, 
	 fill);

  activeView = ViewTable.Retrieverecord(sambaView);
  
  fillval = getFill(fill);

  if (fillval == -1.0) {
    cerr << "Invalid fill argument ->" << fill << "<- given to circle "
      << "command. (Ignoring)" << endl;
    return 0;
  }

  time1 = activeView->circleScene(ident, lx, ly, rad, fillval, color);
  return time1;
}




int
Interpreter::triangle(char *str)
{
  // Draw a triangle on the view.
  char cmd[SLEN], color[SLEN], fill[SLEN], ident[SLEN];
  int time1;
  double lx, ly, vx[2], vy[2], fillval;
  InterpAnimView *activeView;


  sscanf(str, "%s %s %lf %lf %lf %lf %lf %lf %s %s", cmd, ident, &lx, &ly,
	 &vx[0], &vy[0], &vx[1], &vy[1], color, fill);

  vx[0] = vx[0]-lx;         // make them relative
  vy[0] = vy[0]-ly;      
  vx[1] = vx[1]-lx;
  vy[1] = vy[1]-ly;


  activeView = ViewTable.Retrieverecord(sambaView);

  fillval = getFill(fill);

  if (fillval == -1.0) {
      cerr << "Invalid fill argument ->" << fill << "<- given to triangle "
	<< "command. (Ignoring)" << endl;
      return 0;
  }

  time1 = activeView->triangleScene(ident, lx, ly, vx[0], vy[0], vx[1],
					    vy[1], color, fillval);
					      
  return time1;

}  


int 
Interpreter::polygon(char *str)
{
  // Draw a polygon on the view. All coordinates are absolute in the 
  // polygon command, not relative. 
  char cmd[SLEN], sides[SLEN], color[SLEN], fill[SLEN], ident[SLEN];
  double lx=0; 
  double ly=0; 
  double fillval, vx[7], vy[7];
  int numsides, time, numargs, count;
  InterpAnimView *activeView;

  numargs = sscanf(str, "%s %s %s %s %s %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf" ,cmd, ident, sides, color, fill, &lx, &ly, 
	 &vx[0], &vy[0], &vx[1], &vy[1], &vx[2], &vy[2], &vx[3], &vy[3], 
         &vx[4], &vy[4], &vx[5], &vy[5], &vx[6], &vy[6]);

  numargs = numargs - 7;

  numsides = atoi(sides);

  fillval = getFill(fill);

  
  activeView = ViewTable.Retrieverecord(sambaView);

  if (fillval == -1.0) {
      cerr << "Invalid fill argument ->" << fill << "<- given to polygon "
	<< "command. (Ignoring)" << endl;
      return 0;
  }

  for (count=0; count<(numsides-1); count++)
    {
      // Make coords relative.
      vx[count] = vx[count] - lx;
      vy[count] = vy[count] - ly;
    }


  time = activeView->polygonScene(ident, lx, ly, numsides, vx, vy, 
					  color, fillval);
  return time;
}  

int
Interpreter::text(char *str)
{
  // Put a text string on the view.
  char cmd[SLEN], color[SLEN], ident[SLEN];
  int cen, textindx, time1;
  double lx, ly;
  InterpAnimView *activeView;

  sscanf(str, "%s %s %lf %lf %d %s", cmd, ident, &lx, &ly, &cen, color);

  textindx = parseText(str);

  activeView = ViewTable.Retrieverecord(sambaView);
  
  if (textindx == -1)
    return 0;
 
  time1 = activeView->textScene(ident, lx, ly, color, str+textindx, cen);

  return time1;

}


int
Interpreter::bigtext(char *str)
{
  // Put a string of text on the view in a large font.
  char cmd[SLEN], color[SLEN], ident[SLEN];
  int cen, textindx, time1;
  double lx, ly;
  InterpAnimView *activeView;

  sscanf(str, "%s %s %lf %lf %d %s", cmd, ident, &lx, &ly, &cen, color);

  textindx = parseText(str);
  if (textindx == -1) 
    return 0;

  activeView = ViewTable.Retrieverecord(sambaView);

  time1 = activeView->bigtextScene(ident, lx, ly, color, str+textindx, 
				   cen);
  return time1;
}


int
Interpreter::flextext(char *str)
{
  // Put a string of text on the view in a user-specified font.
  char cmd[SLEN], color[SLEN], fname[SLEN], ident[SLEN];
  int cen, textindx, time1;
  double lx, ly;
  InterpAnimView *activeView;

  sscanf(str, "%s %s %lf %lf %d %s %s", cmd, ident, &lx, &ly, &cen, color, 
	 fname);

  textindx = parseFlexText(str);
  if(textindx == -1) 
    return 0;
  
  activeView = ViewTable.Retrieverecord(sambaView);

  time1 = activeView->flextextScene(ident, lx, ly, color, fname, str+textindx,
				    cen);
  return time1;
}



int 
Interpreter::buildset(char *str)
{
  // Build a set out of a group of AnimObjects. 
  char cmd[SLEN], ident[SLEN], target[SLEN][SLEN], num[SLEN];
  char *ptr;
  int numAO, count, time;
  InterpAnimView *activeView;

  ptr = nextString(str, cmd);
  ptr = nextString(ptr, ident);
  ptr = nextString(ptr, num);
  numAO = atoi(num);
  for (count=0; count<numAO; count++)
     {
       ptr = nextString(ptr, target[count]);
       if (ptr==NULL) {
          cerr << "Improper set command.  Skipping." << endl;
          cerr << "   " << str << endl;
          return 0;
          }
     }
  activeView = ViewTable.Retrieverecord(sambaView);
  
  time = activeView->setScene(ident, numAO, target);

  return time;
}


int
Interpreter::deleteAO(char *str)
{
  // Delete an AnimObject from a view.
  char cmd[SLEN], ident[SLEN];
  int time1;
  InterpAnimView *activeView;
  
  sscanf(str, "%s %s", cmd, ident);
  
  activeView = ViewTable.Retrieverecord(sambaView);

  time1 = activeView->deleteScene(ident);
  
  return time1;
}


int
Interpreter::move(char *str)
{
  // Move an AnimObject to the coordinates specified.
  char cmd[SLEN], ident[SLEN];
  double tx, ty;
  int time1, numargs;
  InterpAnimView *activeView;

  numargs = sscanf(str, "%s %s %lf %lf", cmd, ident, &tx, &ty);

  if (numargs != 4) {
      cerr << "Invalid number of arguments given to the move "
	<< "command. (Ignoring)" << endl;
      return 0;
  }

  activeView = ViewTable.Retrieverecord(sambaView);

  time1 = activeView->moveScene(ident, tx, ty);

  return time1;
}


int
Interpreter::moverelative(char *str)
{
  // Move an AnimObject by x and y offset.
  char cmd[SLEN], ident[SLEN];
  double tx, ty;
  int time1;
  InterpAnimView *activeView;

  sscanf(str, "%s %s %lf %lf", cmd, ident, &tx, &ty);

  activeView = ViewTable.Retrieverecord(sambaView);

  time1 = activeView->moverelativeScene(ident, tx, ty);

  return time1;
}


int
Interpreter::moveto(char *str)
{
  // Move an AnimObject to the postion of another AnimObject.
  char cmd[SLEN], ident1[SLEN], ident2[SLEN];
  int time1;
  InterpAnimView *activeView;

  sscanf(str, "%s %s %s", cmd, ident1, ident2);

  activeView = ViewTable.Retrieverecord(sambaView);

  time1 = activeView->movetoScene(ident1, ident2);

  return time1;
}


int
Interpreter::jump(char *str)
{
  // Move an AnimObject to a coordinate with no intermediate steps. 
  char cmd[SLEN], ident[SLEN];
  double tx, ty;
  int time1;
  InterpAnimView *activeView;

  sscanf(str, "%s %s %lf %lf", cmd, ident, &tx, &ty);
  
  activeView = ViewTable.Retrieverecord(sambaView);

  time1 = activeView->jumpScene(ident, tx, ty);

  return time1;
}


int
Interpreter::jumprelative(char *str)
{
  // Move an AnimObject by an x and y offset without intermediate steps.
  char cmd[SLEN], ident[SLEN];
  double tx, ty;
  int time1;
  InterpAnimView *activeView;

  sscanf(str, "%s %s %lf %lf", cmd, ident, &tx, &ty);

  activeView = ViewTable.Retrieverecord(sambaView);

  time1 = activeView->jumprelativeScene(ident, tx, ty);

  return time1;
}


int
Interpreter::jumpto(char *str)
{
  // Move an AnimObject to the location of another with no intermediate
  // steps.
  char cmd[SLEN], ident1[SLEN], ident2[SLEN];
  int time1;
  InterpAnimView *activeView;
  
  sscanf(str, "%s %s %s", cmd, ident1, ident2);

  activeView = ViewTable.Retrieverecord(sambaView);

  time1 = activeView->jumptoScene(ident1, ident2);
 
  return time1;
}


int
Interpreter::color(char *str)
{
  // Change an AnimObject's color.
  char cmd[SLEN], colname[SLEN], ident[SLEN];
  int time1;
  InterpAnimView *activeView;

  sscanf(str, "%s %s %s", cmd, ident, colname);

  activeView = ViewTable.Retrieverecord(sambaView);

  time1 = activeView->colorScene(ident, colname);
  
  return time1;
}


int
Interpreter::alter(char *str)
{
  // Change an AnimObject's text string.
  char cmd[SLEN], ident[SLEN];
  int textindx,time1;
  InterpAnimView *activeView;

  sscanf(str, "%s %s", cmd, ident);

  textindx = parseAlter(str);

  if (textindx == -1)
    return 0;
 
  activeView = ViewTable.Retrieverecord(sambaView);
  
  time1 = activeView->alterScene(ident, str+textindx);
  
  return time1;
}


int
Interpreter::fill(char *str)
{
  // Change an AnimObject's fill style.
  char cmd[SLEN], fill[SLEN], ident[SLEN];
  int time1;
  double fillval;
  InterpAnimView *activeView;

  sscanf(str, "%s %s %s", cmd, ident, fill);

  fillval = getFill(fill);

  if(fillval == -1) {
      cerr << "Invalid fill argument ->" << fill << "<- given to fill "
	<< "command. (Ignoring)" << endl;
      return 0; 
  }

  activeView = ViewTable.Retrieverecord(sambaView);

  time1 = activeView->fillScene(ident, fillval);

  return time1;
}


int
Interpreter::vis(char *str)
{
  // Change an AnimObject's visibility.
  char cmd[SLEN], ident[SLEN];
  int time1;
  InterpAnimView *activeView;

  sscanf(str, "%s %s", cmd, ident);

  activeView = ViewTable.Retrieverecord(sambaView);

  time1 = activeView->visScene(ident);

  return time1;
}


int
Interpreter::raise(char *str)
{
  // Raise an AnimObject towards the front of a view.
  char cmd[SLEN], ident[SLEN];
  int time1;
  InterpAnimView *activeView;

  sscanf(str, "%s %s", cmd, ident);

  activeView = ViewTable.Retrieverecord(sambaView);

  time1 = activeView->raiseScene(ident);

  return time1;
}


int 
Interpreter::lower(char *str)
{
  // Lower an AnimObject towards the back of a view.
  char cmd[SLEN], ident[SLEN];
  int time1;
  InterpAnimView *activeView;

  sscanf(str, "%s %s", cmd, ident);

  activeView = ViewTable.Retrieverecord(sambaView);

  time1 = activeView->lowerScene(ident);

  return time1;
}


int 
Interpreter::exchangepos(char *str)
{
  // Exchange the positions of two AnimObjects.
  char cmd[SLEN], ident1[SLEN], ident2[SLEN];
  int time1;
  InterpAnimView *activeView;

  sscanf(str, "%s %s %s", cmd, ident1, ident2);

  activeView = ViewTable.Retrieverecord(sambaView);

  time1 = activeView->exchangeposScene(ident1, ident2);

  return time1;
}


int
Interpreter::switchpos(char *str)
{
  // Exchange the positions of two AnimObjects with no intermediate
  // steps.
  char cmd[SLEN], ident1[SLEN], ident2[SLEN];
  int time1;
  InterpAnimView *activeView;
  
  sscanf(str, "%s %s %s", cmd, ident1, ident2);

  activeView = ViewTable.Retrieverecord(sambaView);

  time1 = activeView->switchposScene(ident1, ident2);

  return time1;

}


int
Interpreter::swapid(char *str)
{
  // Exchange the identifiers of two AnimObjects.
  char cmd[SLEN], ident1[SLEN], ident2[SLEN];
  int time1;
  InterpAnimView *activeView;
  
  sscanf(str, "%s %s %s", cmd, ident1, ident2);

  activeView = ViewTable.Retrieverecord(sambaView);

  time1 = activeView->swapidScene(ident1, ident2);

  return time1;
}


int
Interpreter::comment(char *str)
{
  // Process a comment... just dump it to cout.
  printf("%s\n", str+7);
//  cout << str+7 << endl;

  return 0;
}


int
Interpreter::changelinewidth(char *str)
{
  // Change the width value for a line.
  char cmd[SLEN], ident[SLEN], newwidth[SLEN];
  int time;
  double widthval;
  InterpAnimView *activeView;
  

  sscanf(str, "%s %s %s", cmd, ident, newwidth);

  widthval = getWidth(newwidth);

  if (widthval == -1.0) {
    printf("Invalid width argument ->%c<- given to line command. (Ignoring)\n", newwidth);
//    cout << "Invalid width argument ->" << newwidth << "<- given to line" 
//      <<" command. (Ignoring)" << endl;
    return 0;
  }

  activeView = ViewTable.Retrieverecord(sambaView);
  
  time = activeView->changelinewidthScene(ident, widthval);

  return time;
}

double
fixY(double y, InterpAnimView *v)
{
  double lx, by, rx, ty;
 
  v->GetCoord(lx, by, rx, ty);

  return (by-y+ty);
}


int 
parseText(char *str)
{
  // Find the start of the string argument of a text command.
  int x = 0; 
  int y = 0;

  while (*(str+x) == ' ') x++;   // get past start spaces
  while (*(str+x) != ' ') x++;   // get past 'text' command
  for (y=1; y<=5; y++) {       // get past other params
      while (*(str+x) == ' ') x++;
      while ((*(str+x) != ' ')  && (*(str+x) != '\0')) x++;
  }
  if (*(str+x) == '\0') {
      cerr << "Error:   No string argument to text, bigtext, or flextext"
	<< " command" << endl;
      return(-1);
  }
  while (*(str+x) == ' ') x++;
  if (*(str+x) == '\0') {
      cerr << "Error:   No string argument to text, bigtext, or flextext"
	<< "command" << endl;
      return(-1);
  }
  return(x);
}

int 
parseFlexText(char *str)
{
  // Find the start of the string argument of a flextext command.
  int x = 0;
  int j = 0;

  while (*(str+x) == ' ') x++;   // get past start spaces
  while (*(str+x) != ' ') x++;   // get past 'text' command
  for (j=1; j<=6; j++) {       // get past other params
      while (*(str+x) == ' ') x++;
      while ((*(str+x) != ' ')  && (*(str+x) != '\0')) x++;
  }
  if (*(str+x) == '\0') {
      cerr << "Error:   No string argument to text, bigtext, or flextext"
	<< " command" << endl;
      return(-1);
  }
  while (*(str+x) == ' ') x++;
  if (*(str+x) == '\0') {
      cerr << "Error:   No string argument to text, bigtext, or flextext"
	<< "command" << endl;
      return(-1);
  }
  return(x);
}    


int 
parseAlter(char *str)
{
  // Find the start of the string argument of an alter command.
  int x = 0; 
  int y = 0;

  while (*(str+x) == ' ') x++;   // get past start spaces
  while (*(str+x) != ' ') x++;   // get past 'alter' command
  while (*(str+x) == ' ') x++;   // get past spaces
  while ((*(str+x) != ' ')  && (*(str+x) != '\0')) x++; // get past id
  if (*(str+x) == '\0') {
      cerr << "Error:   No string argument to alter command" << endl;
      return(-1);
  }
  while (*(str+x) == ' ') x++;
  if (*(str+x) == '\0') {
      cerr << "Error:   No string argument to alter command" << endl;
      return(-1);
  }
  return(x);
}



char *
nextString(char *str, char *token)
{
  while ((*str==' ') || (*str=='\t'))
    str++;
  if (*str == '\0')
    return NULL;
  while ((*str != ' ')  && (*str != '\0')) {
     *token = *str;
     str++;
     token++;
     }
  *token = '\0';
  return str;
}
  


double 
getFill(char *fill)
{
  // Convert the fill value strings to actual values.
  if (!strcmp(fill, "outline"))
    return 0.0;
  else if (!strcmp(fill, "half"))
    return 0.5;
  else if (!strcmp(fill, "solid"))
    return 1.0;
  else
    return -1.0;
}


double
getWidth(char *width)
{
  // Convert the width value strings to actual values.
  if (!strcmp(width, "thin"))
    return 0.0;
  else if (!strcmp(width, "medthick"))
    return 0.5;
  else if (!strcmp(width, "thick")) 
    return 1.0;
  else
    return -1.0;
}

Interpreter MyInterpreter;


void Run(void *param/*Widget, XtPointer, XtPointer*/)
{
  // Callback for the Start button.
  started = 1;
  
  if (paused) {
      paused = 0;
  }
  else {
    paused = 1;
  }

}

void Step(void *param/*Widget, XtPointer, XtPointer*/)
{
  // Callback for the Step button.
  if (!paused)
    {
      paused = 1;
    }

  started = 1;
  stepjusthit = 1;
}

void Delay(void *param/*Widget, XtPointer, XtPointer*/)
{
  // Callback for the delay slider...we don't need to do anything
  // about it here.
	extern void speedCB(void *param);
	speedCB(param);
}

void Close(void *param/*Widget, XtPointer, XtPointer*/)
{
  extern void closeCB( void *param );
  // Callback for the Close button.
  closeCB(param);
  printf("**Close view**\n");
//  cout << "**Close view**" << endl;
}

void Quit(void *param/*Widget, XtPointer, XtPointer*/)
{
  // Callback for the Quit button.
  printf("**Quit**\n");
//  cout << "**Quit**" << endl;
  exit(0);
}
  
int
main (int argc, char *argv[])
{
  // Here is the main routine.
  char str[256], check[SLEN];
  int animtime = 0;
  int thetime = 0;
  int temptime = 0;
  int count;
  int retval;
  int restartMode = 0;
  int in_viewdef_section = 1;
  int skippedviewdefs = 0;
  InterpAnimView *activeView;
  ifstream inFile;
  istream *inp;

  if (argc == 1) {
	  char dummy;
	  printf("Usage: samba [-O] <inputfile>\n");
	  scanf("%c", &dummy);
//        cout << "Usage: samba [-O] [<inputfile>]" << endl;
	  exit(0);
  } else if (argc == 2) {
     if (!strcmp(argv[1], "-O")) {
        printf("Debugging and warning messages off.\n");
//        cout << "Debugging and warning messages off." << endl;
        debugon = 0; 
     }
     else {
        inFile.open(argv[1], ios::in);
        if (!inFile) {
           printf("Unable to open file %s for input.\n", argv[1]);
//           cerr << "Unable to open file " << argv[1] << " for input.\n";
           exit(-1);
           }
        inp = &inFile;
        restartMode = 1;
     }
  }
  else if (argc == 3) {
     if (!strcmp(argv[1], "-O")) {
        printf("Debugging and warning messages off.\n");
//        cout << "Debugging and warning messages off." << endl;
        debugon = 0;
      
        // The second parameter has to be the input file.
        inFile.open(argv[2], ios::in);
        if (!inFile) {
           printf("Unable to open file %s for input.\n", argv[2]);
//           cerr << "Unable to open file " << argv[2] << " for input.\n";
           exit(-1);
           }
        inp = &inFile;
        restartMode = 1;
     }
     else {
		 char dummy;
		 printf("Usage: samba [-O] <inputfile>\n");
		 scanf("%c", &dummy);
//        cout << "Usage: samba [-O] [<inputfile>]" << endl;
         exit(0);
     }
  }

  PolkaDisableControls();
  PolkaSetCallbacks(Run, Step, Delay, Close, Quit);
  PolkaInit();

  printf("Samba is ready for animator commands.\n");
//  cout << "Samba is ready for animator commands." << endl;

  // Initialize all of the active view strings.
  for (count=0; count<24; count++)
    {
      strcpy(activeviews[count].name, "\0");
      activeviews[count].ptr = NULL;
    }

  // If we are still in the 'viewdef' section, then keep reading.
  while (in_viewdef_section ) {
      inp->getline(str, 256);
      retval = sscanf(str, "%s", check);

      if ((retval == 0) || (retval == -1)) continue;  // throw away blank lines

      // If we got a command that was NOT a viewdef, then jump out of this 
      // loop, otherwise, let parseline process the command.
      if ((!strcmp(check, "viewdef")) || (!strcmp(check, "%"))) {
         MyInterpreter.parseLine(str);
      }
      else {
         in_viewdef_section = 0;
      }

  } // while...

  // If no viewdefs were found, then Samba will create the default view,
  // called Samba.
  if (!viewdeffound) {
     activeView = new InterpAnimView();
     activeView->Create("Samba");
     ViewTable.Addrecord("Samba", activeView);

     strcpy(sambaView, "Samba");

     strcpy(activeviews[0].name, "Samba");
     activeviews[0].ptr = activeView;
     number_of_views++;
  }


  printf("Press START or STEP on the control panel to begin.\n");
//  cout << "Press START or STEP on the control panel to begin." << endl;

  // Begin the repeating loop for the restart mode, only once for stdin.
  do {

     activeView = ViewTable.Retrieverecord(sambaView);

     // Spin here while the user has not pressed the Start button.
     while (!started)
        {
          activeView->CheckInput();
        }

     // Parse the last line read in when the viewdef loop terminated.
     MyInterpreter.parseLine(str);

     stepjusthit = 0;

     // Start processing the trace file... 
     while (inp->getline(str, 256))
       {
	// Busy wait if the animation has been paused or stepped...
	while ((paused) && (!stepjusthit))
	  {
	    activeView->CheckInput();
	  }
 
	// Here we check to see if concurrency is active. If it is, then
	// Program() all of the events, and only animate after the block
	// ends.
	if (MyInterpreter.isconcurrent()) {
	   while (MyInterpreter.isconcurrent()) {
              temptime = MyInterpreter.parseLine(str);
	    
              if (temptime > animtime) {
                 animtime = temptime;
              }
	    
	      if (MyInterpreter.isconcurrent()) {
                 inp->getline(str,256);
              }

	   } // while
	} // if isconcurrent
	else {  // not concurrent
	  animtime = MyInterpreter.parseLine(str);
	}

	for ( ; animtime>0; animtime--) 
	  {
	    for (int count=0; count <number_of_views; count++)
	      {
		thetime = activeviews[count].ptr->reporttime();
		activeviews[count].ptr->Animate(thetime, 1);
		activeviews[count].ptr->addtime(1);
	      } // for(int count=0;...)
	  } // for( ;animtime;...)
    
	stepjusthit = 0;
     }  // while still getting input


     if (restartMode) {
        // Reset all of the state variables, and clean out the programmed 
        // events for the views.

        // Close the file, and reopen it for another run.
        inFile.close();
    
        // Reset the state variables.
        started = 0;
        paused = 1;
        animtime = 0;
        thetime = 0;
        temptime = 0;
      
        // Reset the interface
        PolkaReset();

        printf("Press START or STEP on the control panel to restart.\n");
//        cout << "Press START or STEP on the control panel to restart." << endl;

        // Wait til the Start gets pressed
        while (!started && !stepjusthit) 
	  {
	    activeView->CheckInput();
	  }

        for (count = 0; count <number_of_views; count++)
        {
	  // Purge the AnimObjects stored with each view.
	  activeviews[count].ptr->VItems.purgeItems();
          // Blank out the view
          activeviews[count].ptr->Restart();
	}

        // Re-open input
        inFile.open(argv[1], ios::in);
        inp = &inFile;

        // Skip all of the viewdef commands, so that they don't get 
        // repeated.      
        while (!skippedviewdefs) {
           inp->getline(str, 256);
           retval = sscanf(str, "%s", check);
           if ((retval == 0) || (retval == -1)) continue;   // skip blank lines
           if ((!strcmp(check, "viewdef")) || (!strcmp(check, "%"))) {
              skippedviewdefs = 0;
           }
           else {
              skippedviewdefs = 1;
           }
        }

        skippedviewdefs = 0;
     } // if (restartMode)
    
  } while (restartMode);

  while (1)
    {
      activeView->CheckInput();
    }
      
}
