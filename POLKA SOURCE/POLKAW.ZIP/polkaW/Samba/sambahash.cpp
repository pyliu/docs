//************************************************************************
//   Hashing routines for Samba.                                         * 
//************************************************************************
// 8/26/95   IWC - Initial implementation.                               * 
// 8/29/95   IWC - Added hashing for Views.                              * 
//************************************************************************


//#include <stream.h>
//#include <strings.h>
#include <iostream.h>
#include <string.h>
#include "polka.H"
#include "samba.H"

extern int number_of_views;
extern int debugon;
extern char sambaView[SLEN];
extern char activeviewids[SLEN][SLEN];

AOTable::AOTable(void)
{
  int i;

  for (i=0; i<PRIME; ++i)
    {
      bucket[i] = NULL;
    }
}

AOTable::~AOTable(void)
{
  int i;
  RECORD_PTR rptr;

  for (i=0; i<PRIME; ++i)
    {
      if(bucket[i]) {
	while (bucket[i])
	  {
	    rptr = bucket[i];
	    bucket[i]=bucket[i]->next;
	    delete rptr;
	  }
      }
    }
}

void
AOTable::purgeItems()
{
  int i;
  RECORD_PTR rptr;

  for (i=0; i<PRIME; ++i)
    {
      if(bucket[i]) {
	while (bucket[i])
	  {
	    rptr = bucket[i];
	    bucket[i]=bucket[i]->next;
	    delete rptr;
	  }
      }
    }
}	    

void
AOTable::Addrecord(char ident[], AnimObject *AOPtr)
{
  int hash_val;
  RECORD_PTR rptr;
  

  // Apply the hashing function to the name to get the hash index.
  hash_val = hash_string(ident);
  

  // Is there as record already in this slot?
  if (!(rptr = record_exists(ident))) {
    rptr = new Record;
    rptr->next = bucket[hash_val];
    bucket[hash_val] = rptr;
    
    rptr->record = AOPtr;
    strcpy(rptr->name, ident);
    
  }
  else {
    if (debugon) {
    cerr << "Tried to add duplicate record." << endl;
    }
  }
  
}


AnimObject *
AOTable::Retrieverecord(char name[])
{
  RECORD_PTR rptr;

  // Is there a record already in this slot?
  if (!(rptr = record_exists(name))) {
    if(debugon) {
      cerr << "No record found for " << name << "." << endl;
    }
    return(NULL);
  }

  return (rptr->record);
}


int
AOTable::Removerecord(char name[])
{
  int hash_val;
  RECORD_PTR rptr, old;
  
  
  hash_val = hash_string(name);

  for (rptr = bucket[hash_val]; rptr; rptr=rptr->next)
    {
      if (same_record(rptr, name)) {
	if (rptr == bucket[hash_val]) {
	  bucket[hash_val] = rptr->next;
	  delete rptr;
	}
	else {
	  old->next = rptr->next;
	  delete rptr;
	}
      
	return (1);
      }
      old = rptr;
    }
  return(0);
}

RECORD_PTR
AOTable::record_exists(char name[])
{
  RECORD_PTR rptr;
  int hash_val;
  
  hash_val = hash_string(name);
  
  for (rptr=bucket[hash_val]; rptr; rptr=rptr->next)
    {
      if (same_record(rptr, name)) {
	break;
      }
    }
  return rptr;
  
}
  
int
AOTable::same_record(RECORD_PTR rptr, char name[])
{
  if (!strcmp(rptr->name, name)) {
    return 1;
  }
  else {
    return 0;
  }
}

int 
AOTable::hash_string(char name[])
{
  // This routine is the hash function. It simply adds up all
  // of the characters in the given string as if they were integers, 
  // and then returns the result, moded by the prime number of buckets 
  // in the hash table.

  int val;
  char *ptr;

  for (val=0, ptr=name; *ptr; ++ptr)
    val += (int)*ptr;
  return( val % PRIME );
}

// *********************************************************************
// Here are very similar routines, but this version will use a record  *
// struct designed to hold views. This could be done with template for *
// record type, but this method is quick, dirty, and works...          *
// *********************************************************************

VTable::VTable(void)
{
  int j;
  
  for (j=0; j<VIEWPRIME; ++j)
    {
      bucket[j] = NULL;
    }
}

VTable::~VTable(void)
{
  int i;
  VRECORD_PTR rptr;


  for (i=0; i<VIEWPRIME; ++i)
    {
      if(bucket[i]) {
	while (bucket[i])
	  {
	    rptr = bucket[i];
	    bucket[i]=bucket[i]->next;
	    delete rptr;
	  }
      }
    }
}


void
VTable::Addrecord(char ident[], InterpAnimView *VPtr)
{
  int hash_val;
  VRECORD_PTR rptr;


  // Apply the hashing function to the name to get the hash index.
  hash_val = hash_string(ident);
  

  // Is there as record already in this slot?
  if (!(rptr = record_exists(ident))) {
    rptr = new VRecord;
    rptr->next = bucket[hash_val];
    bucket[hash_val] = rptr;

    rptr->record = VPtr;
    strcpy(rptr->name, ident);

  } 
  else {
    if(debugon) {
      cerr << "Tried to add duplicate record." << endl;
    }
  }
  
}


InterpAnimView *
VTable::Retrieverecord(char name[])
{
  VRECORD_PTR rptr;

  // Is there a record already in this slot?
  if (!(rptr = record_exists(name))) {
    if(debugon) {
      cerr << "No record found for " << name << "." << endl;
    }
    return(NULL);
  }

  return (rptr->record);
}


int
VTable::Removerecord(char name[])
{
  int hash_val;
  VRECORD_PTR rptr, old;

  
  hash_val = hash_string(name);

  for (rptr = bucket[hash_val]; rptr; rptr=rptr->next)
    {
      if (same_record(rptr, name)) {
	if (rptr == bucket[hash_val]) {
	  bucket[hash_val] = rptr->next;
	  delete rptr;
	}
	else {
	  old->next = rptr->next;
	  delete rptr;
	}
      
      return (1);
      }
      old = rptr;
    }
  return(0);
}
  
VRECORD_PTR
VTable::record_exists(char name[])
{
  VRECORD_PTR rptr;
  int hash_val;
  
  hash_val = hash_string(name);

  for (rptr=bucket[hash_val]; rptr; rptr=rptr->next)
    {
      if (same_record(rptr, name)) {
	break;
      }
    }
  return rptr;
  
}
  
int
VTable::same_record(VRECORD_PTR rptr, char name[])
{
  if (!strcmp(rptr->name, name)) {
    return 1;
  }
  else {
    return 0;
  }
}

int 
VTable::hash_string(char name[])
{
  // This routine is the hash function. It simply adds up all
  // of the characters in the given string as if they were integers, 
  // and then returns the result, moded by the prime number of buckets 
  // in the hash table.
  int val;
  char *ptr;

  for (val=0, ptr=name; *ptr; ++ptr)
    val += (int) *ptr;
  return( val % VIEWPRIME );
}




