#define PRIME 503
#define VIEWPRIME 23
#define SLEN 128

//********************************************************************
// AnimObject record structure for the AnimObject hash table.        *
//********************************************************************
typedef struct Record {
  int key;
  char name[100];
  AnimObject *record;
  Record *next;
} *RECORD_PTR; 

//********************************************************************
// The AnimObject hash table class definiton.                        *
//********************************************************************
class AOTable {
public:
  void Addrecord(char *, AnimObject *);
  AnimObject *Retrieverecord(char *);
  int Removerecord(char *);
  RECORD_PTR record_exists(char *);
  int same_record(RECORD_PTR, char *);
  int hash_string(char *);
  void purgeItems();
  AOTable();
  ~AOTable();
private:
  RECORD_PTR bucket[PRIME];
};


//********************************************************************
// The view subclass that defines all of the Samba/POLKA operations. *
//********************************************************************
class InterpAnimView : public View {
public:
  int bgScene(char *);
  int coordsScene(double, double, double, double);
  int delayScene(int);
  int lineScene(char *, double, double, double, double, double, char *);
  int arrowScene(char *, double, double, double, double, double, char *);
  int rectangleScene(char *, double, double, double, double, double, char *);
  int circleScene(char *, double, double, double, double, char *);
  int triangleScene(char *, double, double, double, double, double, double,
		    char *, double);
  int polygonScene(char *, double, double, int, double *, double *, char *, 
		   double);
  int textScene(char *, double, double, char *, char *, int);
  int bigtextScene(char *, double, double, char *, char *, int);
  int flextextScene(char *, double, double, char *, char *, char *, int);
  int setScene(char *, int, char [SLEN][SLEN]);
  int deleteScene(char *);
  int moveScene(char *, double, double);
  int moverelativeScene(char *, double, double);
  int movetoScene(char *, char *);
  int jumpScene(char *, double, double);
  int jumprelativeScene(char *, double, double);
  int jumptoScene(char *, char *);
  int colorScene(char *, char *);
  int alterScene(char *, char *);
  int fillScene(char *, double);
  int visScene(char *);
  int raiseScene(char *);
  int lowerScene(char *);
  int exchangeposScene(char *, char *);
  int switchposScene(char *, char *);
  int swapidScene(char *, char *);
  int changelinewidthScene(char *, double);
  // comment needs no scene!
  void addtime(int);
  int reporttime();
  InterpAnimView() {
    time = 0;
  }
  AOTable VItems;
private:
  int time;
};


//********************************************************************
// View record definition for the view hash table.                   *
//********************************************************************
typedef struct VRecord {
  int key;
  char name[100];
  InterpAnimView *record;
  VRecord *next;
} *VRECORD_PTR;


//********************************************************************
// The View hash table class definition.                             *
//********************************************************************
class VTable {
public:
  VTable(void);
  ~VTable();
  void Addrecord(char *, InterpAnimView *);
  InterpAnimView *Retrieverecord(char *);
  int Removerecord(char *);
  VRECORD_PTR record_exists(char *);
  int same_record(VRECORD_PTR, char *);
  int hash_string(char *);
private:
  VRECORD_PTR bucket[VIEWPRIME];
};


//********************************************************************
// Declarations of all callbacks.                                    *
//********************************************************************
void deltimerCB(View *, int, void *);

//void Run(Widget, XtPointer, XtPointer);
//void Step(Widget, XtPointer, XtPointer);
//void Delay(Widget, XtPointer, XtPointer);
//void Close(Widget, XtPointer, XtPointer);
//void Quit(Widget, XtPointer, XtPointer);

void Run(void *param);
void Step(void *param);
void Delay(void *param);
void Close(void *param);
void Quit(void *param);


//********************************************************************
// The Interpreter class definition.                                 *
//********************************************************************
class Interpreter {
public:
  int isconcurrent();
  int parseLine(char *);
  int view(char *);
  int createview(char *);
  int set_concurrent();
  int set_sequential();
  int bg(char *);
  int coords(char *);
  int pause(char *);
  int show(char *);
  int hide(char *);
  int delay(char *);
  int speed(char *);
  int line(char *);
  int pointline(char *);
  int arrow(char *);
  int pointarrow(char *);
  int rectangle(char *);
  int circle(char *);
  int triangle(char *);
  int polygon(char *);
  int text(char *);
  int flextext(char *);
  int bigtext(char *);
  int buildset(char *);
  int deleteAO(char *);
  int move(char *);
  int moverelative(char *);
  int moveto(char *);
  int jump(char *);
  int jumprelative(char *);
  int jumpto(char *);
  int color(char *);
  int alter(char *);
  int fill(char *);
  int vis(char *);
  int raise(char *);
  int lower(char *);
  int exchangepos(char *);
  int switchpos(char *);
  int swapid(char *);
  int comment(char *);
  int changelinewidth(char *);
  Interpreter() {
    concurrent = 0;
  }
private:
  int concurrent;
};
  
struct AVrecs {
  InterpAnimView *ptr;
  char name[SLEN];
};

double fixY(double, InterpAnimView *);
