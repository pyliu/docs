/***************************************************************/
/*							                                   */
/*	       		DrawingAreaProc.cpp                            */
/*							                                   */
/***************************************************************/
/*       Copyright 1997 Georgia Institute of Technology 
                     -- Roman S. Khramets                      */

#include <windows.h>
#include "picking.h"
#include "ViewWindow.h"
#include "View.h"


LRESULT CALLBACK DrawingAreaProc (HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam) {
	 HWND hParent;
	 ViewWindow *theViewWindow;

     switch (iMsg) {
          case WM_CREATE :
               return 0 ;

		  case WM_ERASEBKGND:
		       return 0;

		  case WM_LBUTTONDOWN:
		  case WM_LBUTTONDBLCLK:
		  case WM_RBUTTONDOWN:
		  case WM_RBUTTONDBLCLK:
		  case WM_MBUTTONDOWN:
		  case WM_MBUTTONDBLCLK:
			   hParent = GetParent(hwnd);
			   theViewWindow = (ViewWindow *)GetWindowLong(hParent,
				   GWL_USERDATA);
			   SelectPoint(theViewWindow->getView(),
				   LOWORD(lParam), HIWORD(lParam));
			   break;
	 }

     return DefWindowProc (hwnd, iMsg, wParam, lParam) ;
}
