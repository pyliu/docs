/***************************************************************/
/*							                                   */
/*	       		Circle.cpp			                           */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#include "Circle.h"


Circle& 
Circle::operator=(const Circle& rhs) 
{
  if  (this == &rhs) return *this;
  AnimObject::operator=(rhs);
  return *this;
}
