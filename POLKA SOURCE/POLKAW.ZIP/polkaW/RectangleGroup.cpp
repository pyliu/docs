/***************************************************************/
/*							                                   */
/*	       		RectangleGroup.cpp		                       */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#include "RectangleGroup.h"


RectangleGroup::RectangleGroup()
{
   fill = 0.0;
}


int
RectangleGroup::Make(View *v, Rectangle *o[], int n, 
                        double lx, double by, double rx, double ty)
{
   double s,locx,locy,sx,sy;
   int i;

   locx = lx;
   locy = by;
   for (i=0; i<n; i++) {
      if (horiz) {
         if (spacetype == SpacingNone) s = 0.0;
         else if (spacetype == SpacingSame) s = (rx-lx) / (2.0 * n - 1.0);
         else if (spacetype == SpacingAbsolute) s = spacing;

         sx = ((rx-lx)-(s*(n-1))) / (double)n;

         if (useints)
            sy = (double)(intvals[i]-intmin) / 
                     (double)(intmax-intmin) * (ty-by);
         else if (usedoubles)
            sy = (doublevals[i]-doublemin) / 
                      (doublemax-doublemin) * (ty-by);
         else
            sy = ty-by;

         if (align == AlignBottom)
            o[i] = new Rectangle(v,vis,locx,locy,sx,sy,color,fill);
         else if (align == AlignMiddle)
            o[i] = new Rectangle(v,vis,locx,by+(ty-by)/2.0-sy/2.0,
                             sx,sy,color,fill);
         else if (align == AlignTop)
            o[i] = new Rectangle(v,vis,locx,ty-sy,sx,sy,color,fill);
         else /* bad */
            o[i] = new Rectangle(v,vis,locx,locy,sx,sy,color,fill);

         locx += sx + s;
      }
      else /* vertical */ {
         if (spacetype == SpacingNone) s = 0.0;
         else if (spacetype == SpacingSame) s = (ty-by) / (2.0 * n - 1.0);
         else if (spacetype == SpacingAbsolute) s = spacing;

         sy = ((ty-by)-(s*(n-1))) / (double)n;

         if (useints)
            sx = (double)(intvals[i]-intmin) / 
                       (double)(intmax-intmin) * (rx-lx);
         else if (usedoubles)
            sx = (doublevals[i]-doublemin) / 
                      (doublemax-doublemin) * (rx-lx);
         else
            sx = rx-lx;

         if (align == AlignLeft)
            o[i] = new Rectangle(v,vis,locx,locy,sx,sy,color,fill);
         else if (align == AlignMiddle)
            o[i] = new Rectangle(v,vis,lx+(rx-lx)/2.0-sx/2.0,locy,
                             sx,sy,color,fill);
         else if (align == AlignRight)
            o[i] = new Rectangle(v,vis,rx-sx,locy,sx,sy,color,fill);
         else /* bad */
            o[i] = new Rectangle(v,vis,locx,locy,sx,sy,color,fill);

         locy += sy + s;
      }
   }
   return (1);
}  
