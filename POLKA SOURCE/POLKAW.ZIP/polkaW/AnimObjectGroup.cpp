/***************************************************************/
/*							                                   */
/*	       		AnimObjectGroup.cpp                            */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#include <string.h>
#include "AnimObjectGroup.h"

AnimObjectGroup::AnimObjectGroup()
{
   horiz = 1;
   align = AlignBottom;
   spacetype = SpacingSame;
   useints = 0;
   usedoubles = 0;
   vis = 1;
   strcpy(color,"black");
}
