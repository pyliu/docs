/***************************************************************/
/*							                                   */
/*	       		Pie.cpp			                               */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#include "Pie.h"


Pie& 
Pie::operator=(const Pie& rhs) 
{
  if  (this == &rhs) return *this;
  AnimObject::operator=(rhs);
  return *this;
}
