/***************************************************************/
/*							                                   */
/*	       		Spline.cpp			                           */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#include "Spline.h"


Spline& 
Spline::operator=(const Spline& rhs) 
{
   if  (this == &rhs) return *this;
   AnimObject::operator=(rhs);
   return *this;
}
