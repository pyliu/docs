/***************************************************************/
/*							                                   */
/*	       		Loc2Desc.cpp			                       */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#include "Loc2Desc.h"


Loc2Desc::Loc2Desc()
{
   rows = cols = 0;
}


int
Loc2Desc::Make(Loc *l[])
{
   double x,y,dx,dy;
   int i,r,c;

   if (rows <= 0) return(0);
   if (cols <= 0) return(0);

   y=lly;
   dx = (cols==1 ? 0.0 : (urx - llx) / (cols - 1));
   dy = (rows==1 ? 0.0 : (ury - lly) / (rows - 1));
   for (i=0,r=0; r<rows; r++) { 
     for (c=0,x=llx; c<cols; c++) { 
         l[i] = new Loc(x,y);
         i++;
         x += dx;
     }
     y += dy;
   }
   return(1);
}
