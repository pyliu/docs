/***************************************************************/
/*							                                   */
/*	       		GC.cpp			                               */
/*							                                   */
/***************************************************************/
/*       Copyright 1997 Georgia Institute of Technology 
                     -- Roman S. Khramets                      */

#include "GC.h"
#include <string.h>


GC XCreateGC( unsigned long valueMask, // mask for setting only certain fields of *values
	          XGCValues *values        // values
			) {
	return new __GC();
}


int XSetClipRectangles( GC gc,                  // graphics context
						int clip_x_origin,      // (x,y) origin for
						int clip_y_origin,      // clipping
						XRectangle *rectangles, // a set of clipping rectangles
						int n,                  // number of clipping rectangles
						int ordering            // sorting order
					  ) {
	return gc->XSetClipRectangles( clip_x_origin,
							       clip_y_origin,
							       rectangles,
							       n,
							       ordering
						         );
}


int XSetClipMask( GC gc,      // graphics context
			      Pixmap mask // the clipping mask - not supported!!!
				  ) {
	return gc->XSetClipMask( mask );
}


void XSetBackground( GC gc,
				     Pixel bkColor ) {
	gc->XSetBackground( bkColor );
}


void XSetForeground( GC gc, Pixel fgColor ) {
	gc->XSetForeground( fgColor );
}


void XSetLineAttributes( GC    gc,
						 DWORD line_width,
						 DWORD line_style,
						 DWORD cap_style,
						 DWORD join_style ) {
	gc->XSetLineAttributes( line_width,
						    line_style,
						    cap_style,
						    join_style );
}


void XSetFont( GC gc, 
			   Font fontid ) {
	gc->XSetFont(fontid);
}


__GC::__GC() {
	assignDefaults();
}

__GC::~__GC() {
}


int __GC::XSetClipRectangles( int aClip_x_origin,      // (x,y) origin for
						      int aClip_y_origin,      // clipping
						      XRectangle *aRectangles, // a set of clipping rectangles
						      int n,                   // number of clipping rectangles
						      int ordering             // sorting order
							) {
	if( n > MAX_CLIPPING_RECTANGLES ) {
		printf( "Exceeded the max number of clipping rectangles allowed\n" );
		exit( -1 );
	}

	clip_x_origin = aClip_x_origin;
	clip_y_origin = aClip_y_origin;
	nRectangles   = n;

	for( int i = 0; i < n; i++ ) {
		memcpy( (void *)&rectangles[i],
			    (void *)&aRectangles[i],
				sizeof(XRectangle) );
	}

	return 1;
}


int __GC::XSetClipMask( Pixmap mask // the clipping mask - not supported!!!
					  ) {
	if( mask == None ) {
		// clear any clipping set by the previous
		// calls; should be change in an honest-to-goodness
		// implementation of the X interface functions
		nRectangles = 0;
		return 1;
	}

	return 0;
}


void __GC::XSetForeground( Pixel fgColor ) {
	lbPenBrush.lbColor = fgColor;
	elpPen.elpColor    = fgColor;
	lbBrush.lbColor    = fgColor;
	textColor          = fgColor;
}


void __GC::XSetLineAttributes( DWORD line_width,
						       DWORD line_style,
						       DWORD cap_style,
							   DWORD join_style ) {
	elpPen.elpWidth    = line_width;
    elpPen.elpPenStyle = PS_GEOMETRIC | line_style | cap_style | join_style;
}


void __GC::assignDefaults() {
	background = WhitePixel();
	textColor  = BlackPixel();

	lbPenBrush.lbStyle      = BS_SOLID;
	lbPenBrush.lbColor      = BlackPixel();
	lbPenBrush.lbHatch      = 0;
    elpPen.elpPenStyle      = PS_GEOMETRIC | PS_SOLID | PS_ENDCAP_FLAT | PS_JOIN_ROUND;
    elpPen.elpWidth         = 0;
    elpPen.elpBrushStyle    = lbPenBrush.lbStyle;
    elpPen.elpColor         = lbPenBrush.lbColor;
    elpPen.elpHatch         = lbPenBrush.lbHatch;
    elpPen.elpNumEntries    = 0;
    elpPen.elpStyleEntry[1] = 0;

	lbBrush.lbStyle = BS_SOLID;
	lbBrush.lbColor = WhitePixel();
	lbBrush.lbHatch = 0;

	hFont = (HFONT)GetStockObject(SYSTEM_FONT);
}


void __GC::XSetFont( Font fontid ) {
	hFont = (HFONT)fontid;
}
