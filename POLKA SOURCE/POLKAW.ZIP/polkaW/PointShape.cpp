/***************************************************************/
/*							                                   */
/*	       		PointShape.cpp			                       */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#include "polka_staticwindow.H"
#include "StaticView.h"


PointShape::PointShape(int px, int py, const char *col)
{
   x = px;
   y = py;
   color = load_color(col);
}


void
PointShape::draw(/*Window win, int winheight, StaticView *sv*/)
{
   set_color(color);
//   XDrawPoint(_display,win,inq_gc(),x,winheight-y);
//   sv->AccumClip(x,y,x+1,y+1);
}
