/***************************************************************/
/*							                                   */
/*	       		View.cpp			                           */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#include <windows.h>

#include "View.h"

#include "Widget.h"
#include "Window.h"
#include "ViewWindow.h"
#include "DrawingArea.h"
#include "Pixmap.h"
#include "GC.h"
#include "fill.h"

int askingForInput = 0;
int gotPoint = 0;
int xPoint, yPoint;


View::View()
{
   debug = 0;
   mapped = 1;
   created = 0;
   redrawall = 1;
   resizeMode = CoordStretch;
   time = 0;
   pixX = 0;
   pixY = 0;
   olx = lx = 0.0;
   orx = rx = 1.0;
   oty = ty = 1.0;
   oby = by = 0.0;
   dx = dy = 1.0;
   timerCallbacks = NULL;
   inTimerCallback = 0;
   window   = NULL;   /* need it this way to start (no resize) */
   topshell = NULL;
   easel    = NULL;
   destwin  = NULL;
}


View::~View()
{
   AOPtr walker,curr;
   TimerCBNode *tcb,*tcbold;

   if (!created) return;

   walker = AOTail;
   while (walker) {
      curr = walker;
      walker = walker->prev;
      delete(curr->object);    // This implicitly deletes curr too
   }
   walker = PendingTail;
   while (walker) {
      curr = walker;
      walker = walker->prev;
      delete(curr->object);    // This implicitly deletes curr too
   }
   tcb = timerCallbacks;
   while (tcb) {
      tcbold = tcb;
      tcb = tcb->next;
      delete(tcbold);
   }

   XFreePixmap(window);
   if( topshell ) {
       delete topshell;
       topshell = NULL;
   }
}


int
View::Create(const char *title, ResizeMode rm, int wid, int hei)
{
   Window w;
   AOPtr walker,curr;
   TimerCBNode *tcb,*tcbold;

   PolkaInit();   // just to be safe

   pixX = wid;	 // If these are 0 here, they will be overriden
   pixY = hei;	 // in setupWindow

   if (!created) {
      setupWindow(title);  // sets up X window and Xt widgets
   }

   /* Do default values */
   resizeMode = rm;
   redrawall = 1;
   bgcolor = WHITE;
   numobjects = 0;
   motionblur = 0;
   if (created) {        // need to remove old stuff
      walker = AOTail;
      while (walker) {
         curr = walker;
         walker = walker->prev;
         delete(curr);
      }
      walker = PendingTail;
      while (walker) {
         curr = walker;
         walker = walker->prev;
         delete(curr);
      }
      tcb = timerCallbacks;
      while (tcb) {
         tcbold = tcb;
         tcb = tcb->next;
         delete(tcbold);
      }
    }
   AOHead = AOTail = NULL;
   PendingHead = PendingTail = NULL;
   UpdateHead = UpdateTail = NULL;
   timerCallbacks = NULL;

   if (!created) {
      w = XtWindow(easel);
      prepareAnim(w);  /* sets destwin & window member variables */
      time = 0;   // need to reset
   }

   aspectx = (double)pixX / dx;
   aspecty = (double)pixY / dy;

   fixPad();   // calculates boxpad 

// Doesn't seem like these are needed ??
   animNextFrame();

   created = 1;
   return(1);
}


void
View::Restart()
{
   AOPtr walker,curr;
   TimerCBNode *tcb,*tcbold;

   if (!created)
      return;

   /* Do default values */
   redrawall = 1;
   bgcolor = WHITE;
   mapped = 1;
   numobjects = 0;
   motionblur = 0;
   debug = 0;
   inTimerCallback = 0;
   lx = 0.0;
   rx = 1.0;
   by = 0.0;
   ty = 1.0;
   dx = dy = 1.0;

   aspectx = (double)pixX / dx;
   aspecty = (double)pixY / dy;

   fixPad();   // calculates boxpad 
      
   walker = AOTail;
   while (walker) {
      curr = walker;
      walker = walker->prev;
      delete(curr);
   }
   walker = PendingTail;
   while (walker) {
      curr = walker;
      walker = walker->prev;
      delete(curr);
   }
   tcb = timerCallbacks;
   while (tcb) {
      tcbold = tcb;
      tcb = tcb->next;
      delete(tcbold);
   }

   AOHead = AOTail = NULL;
   PendingHead = PendingTail = NULL;
   UpdateHead = UpdateTail = NULL;
   timerCallbacks = NULL;

   clear();
   Refresh();
   time = 0;   // need to reset
}


void
View::Map()
{
   if (mapped) return;
   if (created)
      //XtPopup(topshell, XtGrabNone);
	  ShowWindow(topshell->getWnd(), SW_RESTORE);
   mapped = 1;
}


void
View::UnMap()
{
   if (!mapped) return;
   if (created)
      //XtPopdown(topshell);
	  ShowWindow(topshell->getWnd(), SW_HIDE);
// added by Roman Khramets
//   created = 0;
// end added by Roman Khramets
   mapped = 0;
}


int
View::CheckInput()
{ 
   CheckXEvents(); 
   return(0);
}


void
View::SetBgColor(const char *col)
{
   COLORINDEX newcol;

   newcol = load_color(col);
   if (newcol != bgcolor) {
      bgcolor = newcol;
      if (created)      // just to be safe
         Refresh();
   }
}


void 
View::SetCoord(double slx, double sby, double srx, double sty)
{ 
   lx = slx; 
   rx = srx; 
   ty = sty; 
   by = sby; 
   dx = rx-lx; 
   dy = ty-by; 
   aspectx = (double)pixX / dx;
   aspecty = (double)pixY / dy;
   fixPad(); 
   if (created)
	   Refresh(); 
}


// These two routines are only used by the ALTER Actions
void 
View::AlterLLCoord(double dlx, double dby)
{  
   lx += dlx; 
   by += dby; 
   dx = rx-lx; 
   dy = ty-by; 
   fixPad(); 
}

   
void
View::AlterURCoord(double drx, double dty)
{ 
   rx += drx; 
   ty += dty; 
   dx = rx-lx; 
   dy = ty-by; 
   fixPad(); 
}


void
View::RegisterTimerCallback(int ti, TIMER_CALLBACK tcb, void *d)
{
   TimerCBPtr ptr,newone,old;

   newone = new TimerCBNode;
   newone->time = ti;
   newone->callbackFct = tcb;
   newone->data = d;
   newone->next = NULL;

   ptr = timerCallbacks;
   if (!ptr || (ptr->time >= ti)) { // should be first one in list
      newone->next = timerCallbacks;
      timerCallbacks = newone;
      }
   else {     // embedded in list
      while (ptr && (ptr->time < ti)) {
         old = ptr;
         ptr = ptr->next;
         }
      old->next = newone;
      newone->next = ptr;
      }
}


void
View::Refresh()
{
   clear();
   damlx = lx;
   damrx = rx;
   damby = by;
   damty = ty;
   drawAll();
   animNextFrame();
}
   

void
View::clear()
{
   if (debug)
      printf("DEBUG: View::clear()\n");

   int oldcolor = set_color(bgcolor);
   /* Must remove clip_rectangle set by animation loop damage routines */
   XSetFillStyle(inq_gc(), FillSolid);
   XSetClipMask(inq_gc(), None);

   XFillRectangle(window, inq_gc(), 0, 0, pixX, pixY );
   set_color(oldcolor);
}


void
View::AddUpdateObject(AOPtr aoptr)
{
   aoptr->upnext = UpdateHead;
   aoptr->upprev = NULL;
   if (!UpdateHead) {
      UpdateHead = aoptr;
      UpdateTail = aoptr;
   }
   else 
      UpdateHead->upprev = aoptr;
   UpdateHead = aoptr;
}


void
View::RemoveUpdateObject(AOPtr aoptr)
{
   if (aoptr != UpdateHead)
      aoptr->upprev->upnext = aoptr->upnext;
   else
      UpdateHead = aoptr->upnext;

   if (aoptr != UpdateTail)
      aoptr->upnext->upprev = aoptr->upprev;
   else
      UpdateTail = aoptr->upprev;
}


void
View::originateAnimObjects(int frame)
{
   AOPtr aop,old;

   for (aop=PendingHead; aop; ) 
      if (aop->object->OriginateTime() <= frame) {
         // remove from Pending list
         if (aop == PendingHead)
            PendingHead = aop->next;
         else
            aop->prev->next = aop->next;
         if (aop == PendingTail)
            PendingTail = aop->prev;
         else
            aop->next->prev = aop->prev;
         old = aop;
         aop = aop->next;

         // add to originated list
         if (!AOHead)
            AOTail = old;
         else
            AOHead->prev = old;
         old->next = AOHead;
         old->prev = NULL;
         AOHead = old;

         old->object->SetOriginated(1);
         old->object->DamageIt();

         AddUpdateObject(old);
         }
      else
        aop = aop->next;
}


void
View::updateAll(int frame)
{
   AOPtr head,walker,curr;

   if (debug)
      printf("DEBUG: View::UpdateAll %d\n",frame);

   needrefresh = 0;  // must reset this so subsequent Actions can set it

   head = UpdateHead;      // Have to be careful here.  Delete ops and
   walker = UpdateTail;    // Raise and Lower actions reorder the AO List.
   curr = NULL;
   while (curr != head) {
      curr = walker;
      walker = walker->upprev;
      updatingObject = curr->object;   // used to short-circuit attachments
      curr->object->Update(frame);
      }
}


void
View::drawAll()
{
   AOPtr aop;
   double damagelx,damagerx,damageby,damagety;

   if (debug)
      printf("DEBUG: View::checkDrawAll\n");

   if (window) {
      damagelx = damlx-boxpad;
      damagerx = damrx+boxpad;
      damageby = damby-boxpad;
      damagety = damty+boxpad;
      for (aop=AOTail; aop; aop=aop->prev) 
          if (aop->object->Intercepts(damagelx,damageby,damagerx,damagety))
             aop->object->Draw();
   }
}


void
View::drawAllUpdaters()
{
   AOPtr aop;
   double damagelx,damagerx,damageby,damagety;

   if (debug)
      printf("DEBUG: View::checkDrawAll\n");

   if (window) {
      damagelx = damlx-boxpad;
      damagerx = damrx+boxpad;
      damageby = damby-boxpad;
      damagety = damty+boxpad;
      // speed redraw mode, only changed objects get redrawn
      for (aop=UpdateTail; aop; aop=aop->upprev)
          if (aop->object->Intercepts(damagelx,damageby,damagerx,damagety))
             aop->object->Draw();
   }
}


int
View::Animate(int start, int frames)
{
   int t,cliplx,clipby,cliprx,clipty;
   XRectangle xrect;
   TimerCBPtr oldtcb;

   
   if (debug)
      printf("DEBUG: View::Animate start=%d for %d frames\n",start,frames);

   if (inTimerCallback) { // Animate not allowed to be called in this case
      POLKA_complain("View::Animate",
          "Not allowed to be called from inside a timer callback function");
      return(start);
      }

   if (!mapped)
      return(Simulate(start, frames));

   BatchMode(1);
   for (t=0; t<frames; t++, start++)
       { CheckXEvents();

         damlx = rx; damrx = lx;    // init damaged area
         damby = ty; damty = by;

         originateAnimObjects(start);
         updateAll(start);     // make changes for this frame

         if (needrefresh) { // ALTER_LL or ALTER_UR Action causes this
            clear();
            damlx = lx;
            damrx = rx;
            damby = by;
            damty = ty;
            drawAll();
            }
            // The padding below handles vertical lines where damaged
            // rx equals to damaged lx
         else if (damrx+0.00001 > damlx) {     // somebody did something

            cliplx = TO_PIX_X(damlx) - 1;
            cliprx = TO_PIX_X(damrx) + 1;
            clipby = TO_PIX_Y(damby) + 1;
            clipty = TO_PIX_Y(damty) - 1;
            if (cliplx < 0) cliplx=0;
            if (clipty < 0) clipty=0;
            if (cliprx > pixX) cliprx=pixX;
            if (clipby > pixY) clipby=pixY;

            xrect.x = cliplx;   // pad these guys to be safe
            xrect.y = clipty;
            xrect.width = cliprx-cliplx+1;
            xrect.height = clipby-clipty+1;
            XSetClipRectangles(inq_gc(),0,0,&xrect,1,YXBanded);

            if (redrawall) {
               if (!motionblur) {  // useful for window dumps
                   int oldcolor = set_color(bgcolor);  // wipe out old
                   XSetFillStyle( inq_gc(), FillSolid );
				   XFillRectangle( window, inq_gc(), cliplx, clipty, 
								   cliprx - cliplx + 1, clipby - clipty + 1 );
                   set_color(oldcolor);
               }
         
               drawAll();  // redraw new (offscreen & only if in damage area)
               }
            else
               drawAllUpdaters();   // only redraw updaters
            }
         else {               // Nothing happened in this frame
            xrect.x = 0;      // so make a small clip area
            xrect.y = 0;
            xrect.width = 100;
            xrect.height = 100;
            XSetClipRectangles(inq_gc(),0,0,&xrect,1,YXBanded);
            }
 
		 animNextFrame();          // blt onscreen

         if (_delay)
            micro_sleep(_delay);

         while (timerCallbacks && (timerCallbacks->time <= start)) {
            inTimerCallback = 1;
            (*(timerCallbacks->callbackFct))(this, start, 
                              timerCallbacks->data);
            inTimerCallback = 0;
            oldtcb = timerCallbacks;
            timerCallbacks = timerCallbacks->next;
            delete oldtcb;
            }
       }
   BatchMode(0);

   return(start);
}


int
View::Simulate(int start, int frames)
{
   int t;
   TimerCBPtr oldtcb;

   
   if (debug)
      printf("DEBUG: View::Simulate start=%d for %d frames\n",start,frames);

   if (inTimerCallback) { // Simulate not allowed to be called in this case
      POLKA_complain("View::Simulate",
          "Not allowed to be called from inside a timer callback function");
      return(start);
      }

   for (t=0; t<frames; t++, start++)
       { 
         originateAnimObjects(start);
         updateAll(start);     // make changes for this frame

         while (timerCallbacks && (timerCallbacks->time <= start)) {
            inTimerCallback = 1;
            (*(timerCallbacks->callbackFct))(this, start, 
                              timerCallbacks->data);
            inTimerCallback = 0;
            oldtcb = timerCallbacks;
            timerCallbacks = timerCallbacks->next;
            delete oldtcb;
            }
       }

   CheckXEvents();
   return(start);
}



/* animate1 is like Animate except no checking input or pausing.  It's
   used by the Animator's Animate routine to have a number of views
   going at once.                                                   */

int
View::AnimateOne(int start)
{
   int cliplx,clipby,cliprx,clipty;
   XRectangle xrect;
   TimerCBPtr oldtcb;

   
   if (debug)
      printf("DEBUG: View::animate1 start=%d\n",start);

   if (inTimerCallback) { // Animate not allowed to be called in this case
      POLKA_complain("View::AnimateOne",
          "Not allowed to be called from inside a timer callback function");
      return(start);
      }

   if (!mapped)
      return(Simulate(start, 1));

   damlx = rx; damrx = lx;    // init damaged area
   damby = ty; damty = by;

   originateAnimObjects(start);
   updateAll(start);     // make changes for this frame


   if (needrefresh) { // ALTER_LL or ALTER_UR Action causes this
      clear();
      damlx = lx;
      damrx = rx;
      damby = by;
      damty = ty;
      drawAll();
      }
     // The padding below handles vertical lines where damaged
     // rx equals to damaged lx
   else if (damrx+0.00001 > damlx) {     // somebody did something
      cliplx = TO_PIX_X(damlx) - 1;
      cliprx = TO_PIX_X(damrx) + 1;
      clipby = TO_PIX_Y(damby) + 1;
      clipty = TO_PIX_Y(damty) - 1;
      if (cliplx < 0) cliplx=0;
      if (clipty < 0) clipty=0;
      if (cliprx > pixX) cliprx=pixX;
      if (clipby > pixY) clipby=pixY;

      xrect.x = cliplx;   // pad these guys to be safe
      xrect.y = clipty;
      xrect.width = cliprx-cliplx+1;
      xrect.height = clipby-clipty+1;
	  XSetClipRectangles(inq_gc(),0,0,&xrect,1,YXBanded);

       if (redrawall) {
          int oldcolor = set_color(bgcolor);   // wipe out old
		  XSetFillStyle( inq_gc(), FillSolid );
		  XFillRectangle( window, inq_gc(), cliplx, clipty, 
			  cliprx - cliplx + 1, clipby - clipty + 1 );
		  set_color(oldcolor);

          drawAll();  // redraw new (offscreen & only if in damage area)
          }
       else
         drawAllUpdaters();  // only draw updaters
      }
   else {               // Nothing happened in this frame
      xrect.x = 0;      // so make a small clip area
      xrect.y = 0;
      xrect.width = 100;
      xrect.height = 100;
	  XSetClipRectangles(inq_gc(),0,0,&xrect,1,YXBanded);
      }

   animNextFrame();          // blt onscreen

   while (timerCallbacks && (timerCallbacks->time <= start)) {
      inTimerCallback = 1;
      (*(timerCallbacks->callbackFct))(this, start,
                              timerCallbacks->data);
      inTimerCallback = 0;
      oldtcb = timerCallbacks;
      timerCallbacks = timerCallbacks->next;
      delete oldtcb;
      }

   return(start+1);
}


int
View::PickCoord(double& x, double& y)
{
	MSG msg;

    askingForInput = 1;

    while (!gotPoint) {
		if( PeekMessage (&msg, NULL, 0, 0, PM_REMOVE) ) {
			TranslateMessage (&msg) ;
			DispatchMessage (&msg) ;
		}
	}
	
	x = TO_REAL_X(xPoint);
	y = TO_REAL_Y(yPoint);

	gotPoint = 0;
	askingForInput = 0;

	return 1;
}



int
View::PickAnimObject(AnimObject* &ao)
{
	MSG msg;
	double xpt, ypt;
	AOPtr  list;

	askingForInput = 1;

    /* Wait for button press event handler to change "getMouse" */
	while (!gotPoint) {
		if( PeekMessage (&msg, NULL, 0, 0, PM_REMOVE) ) {
			TranslateMessage (&msg) ;
			DispatchMessage (&msg) ;
		}
    }

	xpt = TO_REAL_X(xPoint);
	ypt = TO_REAL_Y(yPoint);

	ao = NULL;
	for( list = AOHead; list; list = list->next )  {
		if( list->object->IsPickIn(xpt,ypt) ) {
			ao = list->object;
			break;
		}
	}

	gotPoint = 0;
	askingForInput = 0;

	return( (ao ? 1 : 0));
}


AnimObject *
View::ObjectAt(double xpt, double ypt)
{
   AOPtr  list;
   AnimObject *ao;

   ao = NULL;
   for (list=AOHead; list; list=list->next) 
      if (list->object->IsPickIn(xpt,ypt)) {
         ao = list->object;
         break;
      }
   return( ao );
}


void SelectPoint(View *xtp, int x, int y) {
   double xpt, ypt;
   AnimObject *ao;
   AOPtr  list;
   View *v = xtp;

   if (askingForInput) { // user has explicitly requested a pick
      xPoint = x;
      yPoint = y;
      gotPoint = 1;
      }
   else {   // random pick, so check for object callback
      xpt = v->TO_REAL_X(x);
      ypt = v->TO_REAL_Y(y);

      ao = NULL;
      for (list=v->AOHead; list; list=list->next) {
         if (list->object->IsPickIn(xpt,ypt)) {
            ao = list->object;
            if (ao->callbackFct) {
               ao->callbackFct(ao, ao->callbackData, xpt, ypt); 
               break;
               }
            }
         }
      }
}


//************************************************************
// Fast code for when AnimObjects are added, but they never 
//  overlap, and no Actions are ever performed
//************************************************************


void
View::fastOriginate(int frame)
{
   AOPtr aop,old;

   for (aop=PendingHead; aop; ) 
      if (aop->object->OriginateTime() <= frame) {
         // remove from Pending list
         if (aop == PendingHead)
            PendingHead = aop->next;
         else
            aop->prev->next = aop->next;
         if (aop == PendingTail)
            PendingTail = aop->prev;
         else
            aop->next->prev = aop->prev;
         old = aop;
         aop = aop->next;

         // add to originated list
         if (!AOHead)
            AOTail = old;
         else
            AOHead->prev = old;
         old->next = AOHead;
         old->prev = NULL;
         AOHead = old;
         }
      else
        aop = aop->next;   // Note, do not set Originated = 1 here
}


void
View::fastDraw()
{
   AOPtr aop;

   if (debug)
      printf("DEBUG: View::fastDraw\n");

   if (window)   // while objs not Originated, draw them
      for (aop=AOHead; aop && !(aop->object->Originated()); aop=aop->next)
         {
           aop->object->Draw();
           aop->object->SetOriginated(1);
         }
}


int
View::FastAnimate(int start, int frames)
{
   int t;
   TimerCBPtr oldtcb;

   
   if (debug)
      printf("DEBUG: View::FastAnimate start=%d for %d frames\n",start,frames);

   if (inTimerCallback) { // Animate not allowed to be called in this case
      POLKA_complain("View::Animate",
          "Not allowed to be called from inside a timer callback function");
      return(start);
      }

   BatchMode(1);
   for (t=0; t<frames; t++, start++)
       { CheckXEvents();

         fastOriginate(start);
         // no updates, because no Actions ever used

         fastDraw();  // redraw offscreen only if in damage area

         animNextFrame();          // blt onscreen
         if (_delay)
            micro_sleep(_delay);

         while (timerCallbacks && (timerCallbacks->time <= start)) {
            inTimerCallback = 1;
            (*(timerCallbacks->callbackFct))(this, start, 
                              timerCallbacks->data);
            inTimerCallback = 0;
            oldtcb = timerCallbacks;
            timerCallbacks = timerCallbacks->next;
            delete oldtcb;
            }
       }
   BatchMode(0);

   return(start);
}


/******************************************************************/
/* View::prepareAnim - Create Pixmaps to hold animation frame(s). */
/*		       Whenever the frame dimensions are changed  */
/*		       (eg. by resizing the window) call this     */
/*		       function to create new Pixmaps and update  */
/*		       View information.			  */
/*								  */
/******************************************************************/
void
View::prepareAnim( Window wind )
{
   RECT clientRect;
   int w;
   int h;

   if (debug)
     printf("DEBUG: View::prepareAnim\n");

   destwin = wind;

   if( window ) {
	   XFreePixmap(window);	/* Resizing old frame? */
	   window = NULL;
   }

   // get the window's dimensions
   GetClientRect( destwin->getWnd(), &clientRect );
   w = clientRect.right;
   h = clientRect.bottom;

   if( w && h ) {
	   pixX = w;	/* Update global data */
	   pixY = h;
   }

   if ((created) &&                      // don't do this at start-up
       (resizeMode == ConstantAspect)) {
      rx = lx + (pixX / aspectx);
      ty = by + (pixY / aspecty);
      dx = rx-lx; 
      dy = ty-by; 
   }

   XSetClipMask( inq_gc(), None );
   window = XCreatePixmap( destwin, w, h );

   /* Pixmaps always start in an unknown state...clear it */

   COLORINDEX old = set_color(WHITE);
   XSetFillStyle( inq_gc(), FillSolid );
   XFillRectangle( window, inq_gc(), 0, 0, w, h );
   set_color(old);
}



/*******************************************************************/
/* View::animNextFrame -- Display next animation frame by	   */
/*			    PixBlting offscreen Pixmap to onscreen */
/*			    window.				   */
/*								   */
/*******************************************************************/
void
View::animNextFrame()
{
   if (debug)
      printf("DEBUG: View::animNextFrame\n");

   if( !mapped )
	   return;

   XCopyArea( window, destwin, inq_gc(), 0, 0, pixX, pixY, 0, 0 );
}
