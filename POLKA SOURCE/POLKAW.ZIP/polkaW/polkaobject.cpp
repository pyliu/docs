/***************************************************************/
/*							                                   */
/*			     POLKAOBJECT.CPP		                       */
/*							                                   */
/***************************************************************/
/*       Copyright 1993 Georgia Institute of Technology 
                     -- John T. Stasko                         */

#include "polka_local.H"


COLORINDEX
get_pathcolor(double dx, double)
{
   COLOR_MAPPER *cl;

   for (cl = _color_list; cl; cl=cl->next)
       if (ABS(dx - cl->pathval) < .0001) // roughly equal
          return(cl->colornum);
   return(BLACK);      
}


char *
get_pathstring(double dx, double)
{
   COLOR_MAPPER *cl;

   for (cl = _string_list; cl; cl=cl->next)
       if (ABS(dx - cl->pathval) < .0001) // roughly equal
          return(cl->name);
   return("UNKNOWN");      
}


/***************************************************************/
/*							       */
/*   get_color - given a string of a POLKA_COLOR, return its   */
/*	integer value.					       */
/*							       */
/***************************************************************/

COLORINDEX
get_color(COLOR str)
{
   if (strcmp("WHITE",str) == 0)
      return( WHITE );
   else if (strcmp("BLACK",str) == 0)
      return( BLACK );
   else if (strcmp("RED",str) == 0)
      return( RED );
   else if (strcmp("ORANGE",str) == 0)
      return( ORANGE );
   else if (strcmp("YELLOW",str) == 0)
      return( YELLOW );
   else if (strcmp("GREEN",str) == 0)
      return( GREEN );
   else if (strcmp("BLUE",str) == 0)
      return( BLUE );
   else if (strcmp("MAROON",str) == 0)
      return( MAROON );
   else
      return( BLACK );
}


/***************************************************************/
/*							       */
/*   get_fillstyle - given a fill value between 0.0 and 1.0    */
/*	return the POLKA fill style it corresponds to.	       */
/*							       */
/***************************************************************/

FILL_STYLE
get_fillstyle(double val)
{
//  return (val >= 0.0 && val <= 1.0 ? irint(val * 40.0) : 40); /* 40 fill */
							      /* styles */

      return ((val >= 0.0) && (val <= 1.0) ? int(val * 40.0 + 0.5) : 40);
}


/***************************************************************/
/*							       */
/*   get_linestyle - given a width and a style, return an      */
/*	LINE_STYLE. 	         			       */
/*							       */
/***************************************************************/

LINE_STYLE
get_linestyle(double width,double style)
{
   if (width > 0.666667)
      { if (style < 0.333333)
	   return(THICKER_DOTTED);
	else if (style < 0.666667)
	   return(THICKER_DASHED);
	else
	   return(THICKER);
      }
   else if (width > 0.333333)
      { if (style < 0.333333)
	   return(THICK_DOTTED);
	else if (style < 0.666667)
	   return(THICK_DASHED);
	else
	   return(THICK);
      }
   else
      { if (style < 0.333333)
	   return(DOTTED);
	else if (style < 0.666667)
	   return(DASHED);
	else
	   return(SOLID);
      }
}


/*  #########################################################  */
/*   compute_arrow_off - figure out what the offsets should    */
/*	be for the points of an arrow.			       */
/*	I haven't got a clue how this works, but it just does. */
/*	Many thanks to Eric Golin for code.		       */
/*  #########################################################  */

#define   ARC_HEAD_LENGTH   ((double)0.025)
#define   ARC_HEAD_ANGLE    MYPI/2.5

void
compute_arrow_off(double dx,double dy,double *adx1,double *ady1,
                  double *adx2,double *ady2)
{
   double arclen,len,theta,alpha,beta;

   if ((dx == 0.0) && (dy == 0.0))
      { *adx1 = *adx2 = *ady1 = *ady2 = 0.0;
	return;
      }

   arclen = ARC_HEAD_LENGTH;
   len = sqrt((dx*dx) + (dy*dy));
   if (len < arclen)
      arclen = len;

   theta = atan2(dx,dy);
   alpha = -(theta + ARC_HEAD_ANGLE);
   beta = MYPI - (theta - ARC_HEAD_ANGLE);
   *adx1 = arclen * cos(alpha);
   *ady1 = arclen * sin(alpha);   /* minus, because +y goes up */
   *adx2 = arclen * cos(beta);
   *ady2 = arclen * sin(beta);
}


/*  #########################################################  */
/*   arrow_poly_direction - determine what direction to        */
/*	point the arrowheads on a polyline.  Tricky because    */
/*	offsets at the two endpoints may be 0,0.  We want the  */
/*	last non-negative pair. 			       */
/*  #########################################################  */

void
arrow_poly_direction(int num,double vertx[7],double verty[7],
                 double *fx,double *fy,double *bx,double *by)
{
   double    tempx[8],tempy[8];
   int	     i;

   for (i=1; i<num; ++i)   /* need a starting position too */
      { tempx[i] = vertx[i-1];
	tempy[i] = verty[i-1];
      }
   tempx[0] = tempy[0] = 0.0;

   for (i=num-1; i>=1; --i)
      { *fx = tempx[i] - tempx[i-1];
	*fy = tempy[i] - tempy[i-1];
	if ((*fx != 0.0) || (*fy != 0.0))
	   break;
      }

   for (i=1; i<num; ++i)
      { *bx = tempx[i-1] - tempx[i];
	*by = tempy[i-1] - tempy[i];
	if ((*bx != 0.0) || (*by != 0.0))
	   break;
      }
}
