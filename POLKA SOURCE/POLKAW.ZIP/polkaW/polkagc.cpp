/***************************************************************/
/*							                                   */
/*	       		polkagc.cpp			                           */
/*							                                   */
/***************************************************************/
/*       Copyright 1993, 1997 Georgia Institute of Technology 
                     -- John T. Stasko, Roman S. Khramets      */

#include <string.h>
#include <ctype.h>

#include "polka_local.H"
#include "polka_gc.H"
#include "GC.h"
#include "fill.h"

#include "color_names.cpp"
#include "color_values.cpp"

#define MAXSYSTEMCOLORS   (sizeof(_systemColors)/sizeof(COLORREF))
#define MAXCOLORS         256
#define NUMDEFAULTCOLORS  8

#define MAX_COLOR_NAME_LENGTH   100

//-----------------------

static char *_colorName[MAXCOLORS];
static Pixel _colors[MAXCOLORS];

//----------------------- removed from polka_gc.H ---------------------
static char  *_defaultName[NUMDEFAULTCOLORS] = {
		"white", "yellow", "green",  "blue",
		"orange", "red",   "maroon", "black" };

static GC_FONT _font[MAXFONTS] = { 0 };

//
// since user-defined line dashing patterns are not
// supported by Windows 95 (they are supported by Windows NT),
// we have to define the array of line styles in a different
// way; for the lines thicker than 1 pixel, dashed and dotted styles
// are not supported by Windows 95 either, but are specified anyway
// in a desperate hope that the polka user runs it under Windows NT;
// dash patterns are ignored
//
// support for user defined patterns or, at the very least
// of the thick dotted and dashed lines, is to be added
// (maybe) in later versions of polka for Windows
//
static GC_LINE _lineStyles[MAXLINESTYLES] = {
		  {0, PS_SOLID, {4,4}}, // SOLID
		  {0, PS_DASH,  {8,8}}, // DASHED 
		  {0, PS_DOT,   {2,2}}, // DOTTED
		  {2, PS_SOLID, {4,4}}, // THICK
		  {2, PS_DASH,  {8,8}}, // THICK_DASHED
		  {2, PS_DOT,   {2,2}}, // THICK_DOTTED
		  {4, PS_SOLID, {4,4}}, // THICKER
		  {4, PS_DASH,  {8,8}}, // THICKER_DASHED
		  {4, PS_DOT,   {2,2}}  // THICKER_DOTTED
};

static LOGBRUSH *_fillPixmap[MAXFILLS];
static GC  _gc;

static int _curFill, _curLS, _curColor, _curFont;
static int _numColorsAvail, _numFillsAvail, _numFontsAvail;

static WORD _fillStyles[][8] = {
	{ ~0x00, ~0x00, ~0x00, ~0x00, 
            ~0x00, ~0x00, ~0x00, ~0x00},
    {~0x01, ~0x00, ~0x00, ~0x00, 
            ~0x10, ~0x00, ~0x00, ~0x00},
    {~0x01, ~0x00, ~0x00, ~0x00, 
            ~0x11, ~0x00, ~0x00, ~0x00},
    {~0x11, ~0x00, ~0x04, ~0x00, 
            ~0x11, ~0x00, ~0x00, ~0x00},
    {~0x11, ~0x00, ~0x04, ~0x00, 
            ~0x11, ~0x00, ~0x40, ~0x00},
    {~0x11, ~0x00, ~0x44, ~0x00, 
            ~0x11, ~0x00, ~0x44, ~0x00},
    {~0x11, ~0x00, ~0x45, ~0x00, 
            ~0x11, ~0x00, ~0x54, ~0x00},
    {~0x11, ~0x00, ~0x45, ~0x00, 
            ~0x11, ~0x00, ~0x55, ~0x00},
    {~0x15, ~0x00, ~0x55, ~0x00, 
            ~0x11, ~0x00, ~0x55, ~0x00},
    {~0x15, ~0x00, ~0x55, ~0x00, 
            ~0x51, ~0x00, ~0x55, ~0x00},
    {~0x55, ~0x00, ~0x55, ~0x00, 
            ~0x55, ~0x00, ~0x55, ~0x00},
    {~0x55, ~0x02, ~0x55, ~0x00, 
            ~0x55, ~0x20, ~0x55, ~0x00},
    {~0x55, ~0x02, ~0x55, ~0x00, 
            ~0x55, ~0x22, ~0x55, ~0x00},
    {~0x55, ~0x22, ~0x55, ~0x08, 
            ~0x55, ~0x22, ~0x55, ~0x00},
    {~0x55, ~0x22, ~0x55, ~0x08, 
            ~0x55, ~0x22, ~0x55, ~0x80},
    {~0x55, ~0x22, ~0x55, ~0x88, 
            ~0x55, ~0x22, ~0x55, ~0x88},
    {~0x55, ~0x22, ~0x55, ~0x8a, 
            ~0x55, ~0x22, ~0x55, ~0xa8},
    {~0x55, ~0x22, ~0x55, ~0x8a, 
            ~0x55, ~0x22, ~0x55, ~0xaa},
    {~0x55, ~0x2a, ~0x55, ~0xaa, 
            ~0x55, ~0x22, ~0x55, ~0xaa},
    {~0x55, ~0x2a, ~0x55, ~0xaa, 
            ~0x55, ~0xa2, ~0x55, ~0xaa},
    {~0x55, ~0xaa, ~0x55, ~0xaa, 
            ~0x55, ~0xaa, ~0x55, ~0xaa},
    {~0x55, ~0xab, ~0x55, ~0xaa, 
            ~0x55, ~0xba, ~0x55, ~0xaa},
    {~0x55, ~0xab, ~0x55, ~0xaa, 
            ~0x55, ~0xbb, ~0x55, ~0xaa},
    {~0x55, ~0xbb, ~0x55, ~0xae, 
            ~0x55, ~0xbb, ~0x55, ~0xaa},
    {~0x55, ~0xbb, ~0x55, ~0xae, 
            ~0x55, ~0xbb, ~0x55, ~0xea},
    {~0x55, ~0xbb, ~0x55, ~0xee, 
            ~0x55, ~0xbb, ~0x55, ~0xee},
    {~0x55, ~0xbb, ~0x55, ~0xef, 
            ~0x55, ~0xbb, ~0x55, ~0xee},
    {~0x55, ~0xbb, ~0x55, ~0xef, 
            ~0x55, ~0xbb, ~0x55, ~0xff},
    {~0x55, ~0xbf, ~0x55, ~0xff, 
            ~0x55, ~0xbb, ~0x55, ~0xff},
    {~0x55, ~0xbf, ~0x55, ~0xff, 
            ~0x55, ~0xfb, ~0x55, ~0xff},
    {~0x55, ~0xff, ~0x55, ~0xff, 
            ~0x55, ~0xff, ~0x55, ~0xff},
    {~0x57, ~0xff, ~0x55, ~0xff, 
            ~0x75, ~0xff, ~0x55, ~0xff},
    {~0x57, ~0xff, ~0x55, ~0xff, 
            ~0x77, ~0xff, ~0x55, ~0xff},
    {~0x77, ~0xff, ~0x5d, ~0xff, 
            ~0x77, ~0xff, ~0x55, ~0xff},
    {~0x77, ~0xff, ~0x5d, ~0xff, 
            ~0x77, ~0xff, ~0xd5, ~0xff},
    {~0x77, ~0xff, ~0xdd, ~0xff, 
            ~0x77, ~0xff, ~0xdd, ~0xff},
    {~0x77, ~0xff, ~0xdf, ~0xff, 
            ~0x77, ~0xff, ~0xfd, ~0xff},
    {~0x77, ~0xff, ~0xdf, ~0xff, 
            ~0x77, ~0xff, ~0xff, ~0xff},
    {~0x7f, ~0xff, ~0xff, ~0xff, 
            ~0x77, ~0xff, ~0xff, ~0xff},
    {~0x7f, ~0xff, ~0xff, ~0xff, 
            ~0xf7, ~0xff, ~0xff, ~0xff},
    {~0xff, ~0xff, ~0xff, ~0xff,
            ~0xff, ~0xff, ~0xff, ~0xff}
};

//---------------------------------------------------------------------

LOGBRUSH *XCreateBitmapFromData( const WORD *data,
							     unsigned int width,
							     unsigned int height ) {
	LOGBRUSH *brushInfo;
	HBITMAP   hBitmap;
	
	if( (hBitmap = CreateBitmap(width, height, 1, 1, (LPVOID)data)) == NULL ) {
		return NULL;
	}

	if( (brushInfo = new LOGBRUSH()) == NULL ) {
		DeleteObject( hBitmap );
		return NULL;
	}

	brushInfo->lbStyle = BS_PATTERN8X8;
	brushInfo->lbHatch = (LONG)hBitmap;
	return brushInfo;
}


void XSetFillStyle( GC gc, UINT lbStyle ) {
	gc->lbBrush.lbStyle = lbStyle;
}


void XSetStipple( GC gc, LOGBRUSH *brushInfo ) {
	gc->lbBrush.lbHatch = brushInfo->lbHatch;
}

//---------------------------------------------------------------------

static int already_loaded(const char *);

GC
inq_gc()
{
  return _gc;
}


int 
inq_font() 
{
   return _curFont;
}


int 
inq_color() 
{
   return _curColor;
}


void
SetBackground(COLORINDEX c)
{
    XSetBackground(_gc, GetXColor(c));
}


int hexNum( unsigned char c, unsigned char *cc ) {
	static unsigned char hexDigits[] = { 10, 11, 12, 13, 14, 15 };

	if( c >= '0' && c <= '9' ) {
		*cc = c - '0';
		return 1;
	} else if( c >= 'A' && c <= 'F' ) {
		*cc = hexDigits[c - 'A'];
		return 1;
	} else if( c >= 'a' && c <= 'f' ) {
		*cc = hexDigits[c - 'a'];
		return 1;
	}

	return 0;
}


int colorComponent( const char *name, unsigned char *cc ) {
	unsigned char c1 = 0;
	unsigned char c2 = 0;

	if( !hexNum(*name, &c1) ) return 0;
	if( !hexNum(*(name + 1), &c2) ) return 0;

	*cc = (c1 << 4) | c2;
	return 1;
}


int XParseColor( const char *name, XColor *color ) {
	int i;
    char nameUpper[MAX_COLOR_NAME_LENGTH];
    char _sysColorNameUpper[MAX_COLOR_NAME_LENGTH];

    strncpy(nameUpper, name, MAX_COLOR_NAME_LENGTH);
    _strupr(nameUpper);

	for( i = 0; i < MAXSYSTEMCOLORS; i++ ) {
	    strncpy(_sysColorNameUpper, _systemColorName[i],
			MAX_COLOR_NAME_LENGTH);
		_strupr(_sysColorNameUpper);
		if( streql(nameUpper, _sysColorNameUpper) ) break;
	}

	if( i < MAXSYSTEMCOLORS ) {
		*color = _systemColors[i];
		return 1;
	}

	if( *name == '#' && strlen(name) == 7 ) {
		char *end_ptr;
		unsigned char r;
		unsigned char g;
		unsigned char b;

		name = name + 1;

		if( !colorComponent(name, &r) ) return 0;
		name = name + 2;
		if( !colorComponent(name, &g) ) return 0;
		name = name + 2;
		if( !colorComponent(name, &b) ) return 0;

		*color = RGB(r, g, b);
		return 1;
	}

	return 0;
}


COLORINDEX
load_color(const char *name) {
   XColor color;
   int in_it;
 
   if (!name) return _curColor;
   in_it = already_loaded(name);
   if (in_it != -1) return in_it;
 
   if (_color_screen) {
      if (XParseColor(name,&color)) {
         _colors[_numColorsAvail] = color;
         return _numColorsAvail++;
         }
      else {
         POLKA_complain("load_color: color not available", name);
         free(_colorName[_numColorsAvail]);
         return BLACK;
         }
      }
   else {
      return _numColorsAvail++;
      }
}


Pixel GetXColor( COLORINDEX color ) {
   if( color < 0 || color >= _numColorsAvail ) {
       POLKA_complain("GetXColor", "undefined color");
       return _colors[WHITE];
   }

   if( _color_screen ) {
       return( _colors[color] );
   } else {
       return (color == WHITE) ? WhitePixel() : BlackPixel();
   }
}



int
already_loaded(const char *c)
{
   int i;
   char cUpper[MAX_COLOR_NAME_LENGTH];
   char _colorNameUpper[MAX_COLOR_NAME_LENGTH];

   strncpy(cUpper, c, MAX_COLOR_NAME_LENGTH);
   _strupr(cUpper);

   for (i=0; (i<=_numColorsAvail-1) && (i<MAXCOLORS); ++i) {
	  strncpy(_colorNameUpper, _colorName[i], MAX_COLOR_NAME_LENGTH);
      if (streql(cUpper, _strupr(_colorNameUpper)))
         return(i);
   }

   if (i==MAXCOLORS) {
      POLKA_complain("already_loaded","Max number of colors used.  Loading black");
      return (BLACK);
   }

   _colorName[_numColorsAvail] = (char *) malloc(strlen(c) + 1);
   strcpy(_colorName[_numColorsAvail],c);

   return(-1);
}


COLORINDEX
set_color(COLORINDEX color)
   {
   int old = _curColor;
   Pixel fg;

   if (color == _curColor) return _curColor;
   if (color < 0 || color >= _numColorsAvail) {
      POLKA_complain("set_color", "undefined color");
      return _curColor;
      }

   if (_color_screen) {
      fg = _colors[color];
      }
   else {
      fg = (color == WHITE ? WhitePixel() : BlackPixel());
      if (color == WHITE || color == BLACK) {
         XSetFillStyle(_gc, FillSolid);
	  } else  /* 8 distinct fills */
         fill_style((int)(color*5.7 + 0.5));
      }

      XSetForeground(_gc, fg);
      return (old != UNINITIALIZED ? old : _curColor);
}



LINE_STYLE 
line_style(LINE_STYLE style)
   {
   int old = _curLS;
   
   if (style < 0 || style > MAXLINESTYLES) {
      POLKA_complain("line_style", "undefined line style");
      return _curLS;
      }
   if (style == _curLS) return _curLS;
   _curLS = style;

   if (style == SOLID) {
      XSetLineAttributes( _gc, 0, LineSolid, CapButt, JoinMiter );
   } else {
      XSetLineAttributes( _gc, _lineStyles[style].width,
   		                  _lineStyles[style].line_style, CapButt, JoinMiter );
   }

   return old;
}



FILL_STYLE 
fill_style(FILL_STYLE fill)
   {
   int old = _curFill;

   if (fill < 0 || fill >= _numFillsAvail) {
      POLKA_complain("fill_style", "undefined fill style\n\n");
      return _curFill;
      }
   if (fill == _curFill) return _curFill;
   _curFill = fill;

   /* For mono screens, colors are represented by fillstyles  */
   /*    so any change to fillstyle must alert the color      */
   /*    routine that the current "color" is NOT what it used */
   /*    to be.  Force TANGO_color() to reload the color.     */

   if (!_color_screen) _curColor = UNINITIALIZED;

   /* Update the GC with the new fill style */

   if (_fillPixmap[fill] != None) {
      XSetFillStyle(_gc, FillOpaqueStippled);
      XSetStipple(_gc, _fillPixmap[fill]);
      }
   else /* Problem getting particular fill Pixmap */
      XSetFillStyle(_gc, FillSolid);
   
   return old;
   }


/*
 * Font syntax:
 *      fontname ::= L(L|WS)*['|'(WS)*N(WS)*'|'[S|SS|SSS|SSSS]]
 *      L  ::= 'a'|'b'|...|'z'|'A'|'B'|...|'Z'|'0'|'1'|...|'9'
 *      WS ::= ' '
 *      S  ::= 'I'|'B'|'U'|'S'
 *      N  ::= D('0'|D)*
 *      D  ::= '1'|'2'|...|'9'
 *
 *      L  - literal
 *      N  - number
 *      WS - whitespace
 *      S  - style ('I'talic, 'B'old, 'U'derline and/or 'S'trikeOut)
 *      D  - digit
*/
int 
load_font(const char *fontname)
   {
   XFontStruct *xfs;
   int newfont = DEFAULTFONTNUM;
   int i,found;

   if (!fontname) return newfont;
   if (_numFontsAvail >= MAXFONTS) {
      POLKA_complain("load_font","max number of fonts already used");
      return newfont;
      }
   
   /* Make sure we don't reload an already-used font */

   for (found = i = 0; !found && i < _numFontsAvail; i += !found)
      found = !strcmp(_font[i].name, fontname);
   if (found) return i;

   /* Font hasn't been loaded yet, load it */
   xfs = new XFontStruct;
   _font[_numFontsAvail].name = new char[strlen(fontname) + 1];

   if( strlen(fontname) ) {
	   char ch;
	   char *pCh1;
	   char *pCh2;
	   char faceName[LF_FACESIZE];
	   LONG lfHeight;

	   xfs->lfHeight         = 0; // use default height
	   xfs->lfWeight         = FW_NORMAL;
	   xfs->lfItalic         = FALSE;
	   xfs->lfUnderline      = FALSE;
	   xfs->lfStrikeOut      = FALSE;

	   if( (pCh1 = strchr(fontname, '|')) ) {
		   ch = *pCh1;
		   *pCh1 = '\0';
		   strncpy(xfs->lfFaceName, fontname, LF_FACESIZE);
		   *pCh1 = ch;
		   pCh1++;

		   if( (pCh2 = strchr(pCh1, '|')) ) {
			   for( pCh2++; *pCh2; pCh2++ ) {
				   switch( *pCh2 ) {
					   case 'I':
						   xfs->lfItalic = TRUE;
						   break;
					   case 'B':
						   xfs->lfWeight = FW_BOLD;
						   break;
					   case 'U':
						   xfs->lfUnderline = TRUE;
						   break;
					   case 'S':
						   xfs->lfStrikeOut = TRUE;
						   break;
					   default:
						   POLKA_complain("load_font","font syntax error: invalid font style\n");
						   break;
				   }
			   }
		   }

		   if( sscanf(pCh1, "%ld", &lfHeight) ) {
			   xfs->lfHeight = -lfHeight;
		   } else {
			   POLKA_complain("load_font","font syntax error: invalid font height specification\n");
		   }
	   }

	   xfs->lfWidth          = 0; // choose a "closest match" value
	   xfs->lfEscapement     = 0;
	   xfs->lfOrientation    = 0;
	   xfs->lfCharSet        = DEFAULT_CHARSET;
	   xfs->lfOutPrecision   = OUT_TT_PRECIS;
	   xfs->lfClipPrecision  = CLIP_DEFAULT_PRECIS;
	   xfs->lfQuality        = PROOF_QUALITY;
	   xfs->lfPitchAndFamily = DEFAULT_PITCH | FF_DONTCARE;

	   if( (_font[_numFontsAvail].hFont = CreateFontIndirect(xfs)) == NULL ) {
		   POLKA_complain("load_font","font not available");
		   delete xfs;
		   delete _font[_numFontsAvail].name;
		   return newfont;
	   }
   } else {
	   _font[_numFontsAvail].hFont = (HFONT)GetStockObject(SYSTEM_FONT);
	   GetObject((HGDIOBJ)_font[_numFontsAvail].hFont,
		   sizeof(XFontStruct), xfs);
   }

   strcpy(_font[_numFontsAvail].name, fontname);
   _font[_numFontsAvail].xfs = xfs;
   newfont = _numFontsAvail++;

   return newfont;
}


struct XCharStruct {
	short           lbearing;
	short           rbearing;
	short           width;
	short           ascent;
	short           descent;
	unsigned short  attributes;
};


#define NUMLETTERS  256

void XTextExtents(HFONT hFont, const char *str, int n, short *dir, short *asc, short *des, XCharStruct *overall) {
	HDC hdc;
	HFONT hOldFont;
	INT widths[NUMLETTERS];
	int i;
	short width;
	TEXTMETRIC tm;
	RECT rect;
	// the application handler
	extern HINSTANCE hApp;

	HWND hWnd = CreateWindow("DrawingArea", "", 0,
		0, 0, 200, 200, NULL, NULL, hApp, NULL);
	hdc = GetDC(hWnd);
	hOldFont = (HFONT)SelectObject(hdc, hFont);
	GetTextMetrics(hdc, &tm);

	// get widths for all the characters of the font we
	// have just selected into hdc
	GetCharWidth(hdc, (UINT)0, (UINT)255, widths);

	for( i = 0, width = 0; i < n; i++ ) {
		width += widths[(UINT)(str[i])];
	}

	overall->lbearing   = 0;
	overall->rbearing   = width;
	overall->width      = width;
	overall->ascent     = tm.tmDescent;
	overall->descent    = tm.tmAscent;
	overall->attributes = 0;

	*dir = 0;
	*asc = overall->ascent;
	*des = overall->descent;

	SelectObject(hdc, hOldFont);
	ReleaseDC(hWnd, hdc);
	DestroyWindow(hWnd);
}


void text_info(Font fontid, const char *str, int *xext, int *yext, int *xofs, int *yofs) {
    XCharStruct over;
    short dir, asc, des;
	
	if( fontid < 0 || fontid >= _numFontsAvail ) {
        POLKA_complain("text_info","undefined font");
        *xext = *yext = *xofs = *yofs = 0;
	} else if (str) {
		XTextExtents(_font[fontid].hFont, str, strlen(str), &dir, &asc, &des, &over);
		*xext = over.width;
		*yext = over.ascent + over.descent;
		*xofs = 0;
		*yofs = 1;
	} else {
		*xext = *yext = *xofs = *yofs = 0;
	}
}


int 
set_font(int fontid)
   {
   int old = _curFont;

   if (fontid == _curFont) return _curFont;
   if (fontid < 0 || fontid >= _numFontsAvail) {
      POLKA_complain("set_font","undefined font");
      return _curFont;
      }

   _curFont = fontid;
   XSetFont(_gc, (Font)_font[fontid].hFont);

   return old;
   }



void 
initGC() {
   int    i;
   COLOR_MAPPER *gcc;

   /* Init fill styles ... create pixmaps */
   for (i = 0; i < NUMDEFAULTFILLS; i++) {
      _fillPixmap[i] = XCreateBitmapFromData( _fillStyles[i], 8, 8 );
   }

   for ( ; i < MAXFILLS; i++)
      _fillPixmap[i] = None;
   _numFillsAvail = NUMDEFAULTFILLS;

   /* Init colors */
   for (i = 0; i < NUMDEFAULTCOLORS; i++)
      load_color(_defaultName[i]);
   for ( ; i < MAXCOLORS; i++)
      _colors[i] = UNINITIALIZED;
   _numColorsAvail = NUMDEFAULTCOLORS;

   /* Init fonts */
   for (i = 0; i < MAXFONTS; i++) {
      _font[i].name = NULL;
      _font[i].xfs = NULL;
      }
   _numFontsAvail = 0;
 
   /* Create GC */
   _gc = XCreateGC( 0, 0 );
   if( _gc == None ) {
       POLKA_complain( "initGC", "unable to create GC" );
       /* recover somehow...here */
       exit(1);
   }

   /* Init GC - white background, default font, black */
   /*		foreground, solid fill, solid line    */

   XSetBackground( _gc, WhitePixel() );
   _color_list = new(COLOR_MAPPER);  // used for changing objects
   _color_list->pathval = 0.0;   // to different colors
   _color_list->colornum = BLACK;
   strcpy(_color_list->name,"black");
   gcc = new(COLOR_MAPPER);
   gcc->next = NULL;
   gcc->pathval = 0.001;  
   gcc->colornum = WHITE;
   strcpy(gcc->name,"white");
   _color_list->next = gcc;
  
   _curFont = _curColor = _curFill = _curLS = UNINITIALIZED;

   set_font(load_font(DEFAULTFONT));
   fill_style(40);
   set_color(BLACK);
   line_style(SOLID);
}


void cleanup() {
	int i;

	for( i = 0; i < NUMDEFAULTFILLS; i++ ) {
		DeleteObject( (HBITMAP)_fillPixmap[i]->lbHatch );
		delete _fillPixmap[i];
	}

    for( i = 0; i < _numFontsAvail; i++ ) {
		delete _font[i].name;
		delete _font[i].xfs;
		DeleteObject(_font[i].hFont);
    }

	for( i = 0; i < _numColorsAvail; i++ ) {
		free( _colorName[i] );
	}
}
